package org.avoperformance.horse.core.telemetry

/**
 * End-to-end view of the correction path, built only from counters the devices report:
 *
 *   caster ─NTRIP→ phone ─BLE→ chest ─ESP-NOW→ back ─UART→ ZED-F9P (applies them) → RTK state
 *
 * The chest DIAG text (firmware V3.5.0+) carries the chest and back counters; the app adds
 * its own NTRIP / BLE counters. [diagnose] names the FIRST stage where the bytes stop.
 */
data class RtcmChain(
    // phone
    val ntripBytes: Long,             // received from the caster
    val phoneSentBytes: Long,         // written to the chest over BLE
    // chest (DIAG)
    val chestFw: String?,
    val chestRxBytes: Long?,          // rtcm_in
    val chestRejectedUnauth: Long?,   // ble_rtcm_rejected
    val chestSentToBack: Long?,       // rtcm_out
    val chestDropped: Long?,          // rtcm_drop
    val chestNoLink: Long?,           // rtcm_nolink
    val linkKind: String?,            // "espnow" | "uart" | null (old firmware)
    val backPaired: Boolean?,         // now_paired
    val backHeard: Boolean?,          // uart=1: frames from the back in the last 2 s
    val linkTxFail: Long?,            // now_tx_fail
    // back (DIAG, reported by the back over the link)
    val backRxBytes: Long?,           // back_rtcm_rx
    val backToZed: Long?,             // back_rtcm_zed
    val backNotWritten: Long?,        // back_rtcm_nowr
    val zedState: String?,            // zed
    val zedBaud: Long?,
    val zedPort: Int?,
    val zedUsed: Long?,               // zed_used: RXM-RTCM messages applied by the receiver
    val zedFailed: Long?,             // zed_fail
    // receiver
    val rtk: RtkState,
) {
    enum class Stage(val texto: String) {
        CASTER("Caster NTRIP → teléfono"),
        PHONE("Teléfono → pecho (Bluetooth)"),
        CHEST("Pecho"),
        LINK("Pecho → espalda (ESP-NOW)"),
        BACK("Espalda → receptor ZED (UART)"),
        RECEIVER("Receptor: aplica las correcciones"),
        RTK("Solución RTK"),
        OK("Toda la cadena funciona"),
    }

    data class Verdict(val stage: Stage, val ok: Boolean, val texto: String)

    companion object {
        private fun Map<String, String>.long(k: String) = this[k]?.trim()?.toLongOrNull()
        private fun Map<String, String>.int(k: String) = this[k]?.trim()?.toIntOrNull()

        fun from(diag: Map<String, String>?, ntripBytes: Long, phoneSentBytes: Long, rtk: RtkState): RtcmChain {
            val d = diag ?: emptyMap()
            return RtcmChain(
                ntripBytes, phoneSentBytes, d["fw"],
                d.long("rtcm_in"), d.long("ble_rtcm_rejected"), d.long("rtcm_out"), d.long("rtcm_drop"), d.long("rtcm_nolink"),
                d["link"], d.int("now_paired")?.let { it != 0 }, d.int("uart")?.let { it != 0 }, d.long("now_tx_fail"),
                d.long("back_rtcm_rx"), d.long("back_rtcm_zed"), d.long("back_rtcm_nowr"), d["zed"], d.long("zed_baud"),
                d.int("zed_port"), d.long("zed_used"), d.long("zed_fail"), rtk,
            )
        }

        /** Increase of a counter between two readings (null when unknown). */
        private fun inc(now: Long?, before: Long?): Long? = if (now == null) null else now - (before ?: 0L)
    }

    /**
     * Walks the chain in order and returns the verdict for the first broken stage.
     * [prev] is the previous reading (a few seconds earlier) so "is it flowing NOW" can be judged.
     */
    fun diagnose(prev: RtcmChain?): Verdict {
        val ntrip = ntripBytes - (prev?.ntripBytes ?: 0)
        val sent = phoneSentBytes - (prev?.phoneSentBytes ?: 0)
        if (ntrip <= 0) return Verdict(Stage.CASTER, false, "El caster no está enviando correcciones al teléfono (revisa NTRIP: conexión, mountpoint, usuario).")
        if (sent <= 0) return Verdict(Stage.PHONE, false, "El teléfono recibe correcciones pero no las está enviando al pecho (¿pecho conectado y autorizado?).")
        if (chestRxBytes == null) return Verdict(Stage.CHEST, false, "Este firmware del pecho no informa de la cadena de correcciones: instala V3.5.0.")
        val rej = inc(chestRejectedUnauth, prev?.chestRejectedUnauth) ?: 0
        if (rej > 0) return Verdict(Stage.PHONE, false, "El pecho rechaza las correcciones: este teléfono no está autorizado (Bluetooth › Vincular, pulsa BOOT).")
        val chestIn = inc(chestRxBytes, prev?.chestRxBytes) ?: 0
        if (chestIn <= 0) return Verdict(Stage.PHONE, false, "Las correcciones no llegan al pecho por Bluetooth.")
        if (linkKind == "espnow" && backPaired == false)
            return Verdict(Stage.LINK, false, "El pecho no tiene espalda emparejada: Diagnósticos › Emparejar espalda (o mantén PRG 3 s en la espalda).")
        if (backHeard == false)
            return Verdict(Stage.LINK, false, "El pecho no oye a la espalda: ¿espalda encendida, en alcance y con firmware V3.5.0?")
        val toBack = inc(chestSentToBack, prev?.chestSentToBack) ?: 0
        if (toBack <= 0) return Verdict(Stage.LINK, false, "El pecho no está reenviando correcciones a la espalda.")
        if (backRxBytes == null) return Verdict(Stage.BACK, false, "Aún no hay estado de la espalda (espera unos segundos).")
        val backIn = inc(backRxBytes, prev?.backRxBytes) ?: 0
        if (backIn <= 0) return Verdict(Stage.LINK, false, "La espalda no está recibiendo las correcciones que envía el pecho.")
        val zedIn = inc(backToZed, prev?.backToZed) ?: 0
        if (zedIn <= 0) {
            val why = if (zedState != null && zedState != "FUNCIONANDO" && zedState != "SIN_RESPUESTA_UBX") " (estado del receptor: $zedState)" else ""
            return Verdict(Stage.BACK, false, "La espalda no está escribiendo las correcciones en el receptor$why.")
        }
        val used = inc(zedUsed, prev?.zedUsed)
        if (zedState == "SIN_RESPUESTA_UBX")
            return Verdict(Stage.RECEIVER, false, "La espalda escribe correcciones a ${zedBaud ?: "?"} baudios pero el receptor no contesta por UBX: no se puede confirmar que las aplique ni leer la posición. Revisa TX/RX y la configuración del puerto del ZED.")
        if (used != null && used <= 0) {
            val failed = inc(zedFailed, prev?.zedFailed) ?: 0
            return Verdict(Stage.RECEIVER, false, if (failed > 0) "El receptor recibe las correcciones pero las descarta: revisa que el mountpoint envíe MSM de tus constelaciones y esté cerca (< 30 km)."
                else "El receptor no informa de correcciones aplicadas todavía.")
        }
        if (rtk != RtkState.FLOAT && rtk != RtkState.FIX)
            return Verdict(Stage.RTK, false, "El receptor aplica correcciones; falta convergencia (cielo despejado, unos segundos o minutos). Estado: ${rtk.texto}.")
        return Verdict(Stage.OK, true, "Correcciones llegando y aplicadas por el receptor: ${rtk.texto}.")
    }
}
