package org.avoperformance.horse.core

import org.avoperformance.horse.core.ble.DiagParser
import org.avoperformance.horse.core.telemetry.RtcmChain
import org.avoperformance.horse.core.telemetry.RtkState
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/** DIAG text in the exact layout printed by firmware V3.5.0 (ble_service.cpp, DIAG_GET). */
class RtcmChainTest {
    private fun diag(rtcmIn: Long, rejected: Long, out: Long, paired: Int, heard: Int, backRx: Long, backZed: Long, zed: String, used: Long, fail: Long = 0) =
        "fw=3.5.0 src=V3.5.0-ESPNO boot=12 reset=POWERON up=300s heap=150000 psram=7000000 sd=1 rec=IDLE ring=0% drop=0 " +
            "uart=$heard ok=1000 crc=0 lost=0 rtcm_in=$rtcmIn rtcm_out=$out rtcm_drop=0 zed_used=$used " +
            "girth=0 imu=0 gnss_hz=10.0 batt=80% 3950mV time=GNSS safe=0 largest=100000 psram_min=6000000 heap_min=120000 keys=1 auth_fail=0 mtu=247" +
            " link=espnow now_paired=$paired now_pairing=0 now_peer=AA:BB:CC:DD:EE:FF now_tx_ok=500 now_tx_fail=0 now_retry=3 now_rx=900" +
            " now_foreign=0 now_bad=0 now_rssi=-55 rtcm_nolink=0 ble_rtcm_rejected=$rejected back_status_age_ms=400" +
            " back_fw=3.5.0 zed=$zed zed_baud=230400 zed_port=2 zed_cfg=3 nav_hz_cfg=10 back_gnss_hz=10.0" +
            " back_rtcm_rx=$backRx back_rtcm_zed=$backZed back_rtcm_ok=10 back_rtcm_bad=0 back_rtcm_gap=0 back_rtcm_nowr=0" +
            " zed_used=$used zed_fail=$fail ubx=5000 nmea=0 back_tx_fail=0 back_rssi=-58"

    private fun chain(d: String?, ntrip: Long, sent: Long, rtk: RtkState) = RtcmChain.from(d?.let { DiagParser.parse(it) }, ntrip, sent, rtk)

    @Test fun parsesFirmwareDiag() {
        val m = DiagParser.parse(diag(1000, 0, 990, 1, 1, 980, 980, "FUNCIONANDO", 12))
        assertEquals("espnow", m["link"]); assertEquals("AA:BB:CC:DD:EE:FF", m["now_peer"]); assertEquals("FUNCIONANDO", m["zed"])
        assertEquals("230400", m["zed_baud"]); assertEquals("-58", m["back_rssi"]); assertEquals("10.0", m["gnss_hz"])
        val c = chain(diag(1000, 0, 990, 1, 1, 980, 980, "FUNCIONANDO", 12), 5000, 4000, RtkState.FIX)
        assertEquals(1000L, c.chestRxBytes); assertEquals(980L, c.backToZed); assertEquals(12L, c.zedUsed); assertEquals(2, c.zedPort)
    }

    @Test fun findsTheFirstBrokenStage() {
        val p = chain(diag(1000, 0, 1000, 1, 1, 1000, 1000, "FUNCIONANDO", 10), 1000, 1000, RtkState.AUTONOMO)
        // all flowing and FIX
        var v = chain(diag(2000, 0, 2000, 1, 1, 2000, 2000, "FUNCIONANDO", 20), 2000, 2000, RtkState.FIX).diagnose(p)
        assertTrue(v.ok); assertEquals(RtcmChain.Stage.OK, v.stage)
        // caster silent
        assertEquals(RtcmChain.Stage.CASTER, chain(diag(2000, 0, 2000, 1, 1, 2000, 2000, "FUNCIONANDO", 20), 1000, 1000, RtkState.FIX).diagnose(p).stage)
        // phone not authorized: the chest counts rejected writes
        v = chain(diag(1000, 7, 1000, 1, 1, 1000, 1000, "FUNCIONANDO", 10), 2000, 2000, RtkState.AUTONOMO).diagnose(p)
        assertEquals(RtcmChain.Stage.PHONE, v.stage); assertTrue(v.texto.contains("BOOT"))
        // back not paired
        v = chain(diag(2000, 0, 1000, 0, 0, 1000, 1000, "?", 10), 2000, 2000, RtkState.AUTONOMO).diagnose(p)
        assertEquals(RtcmChain.Stage.LINK, v.stage); assertTrue(v.texto.contains("emparejada"))
        // back paired but not heard
        v = chain(diag(2000, 0, 1000, 1, 0, 1000, 1000, "FUNCIONANDO", 10), 2000, 2000, RtkState.AUTONOMO).diagnose(p)
        assertEquals(RtcmChain.Stage.LINK, v.stage)
        // back receives but cannot write (ZED baud still being searched)
        v = chain(diag(2000, 0, 2000, 1, 1, 2000, 1000, "BUSCANDO_BAUDIOS", 10), 2000, 2000, RtkState.AUTONOMO).diagnose(p)
        assertEquals(RtcmChain.Stage.BACK, v.stage); assertTrue(v.texto.contains("BUSCANDO_BAUDIOS"))
        // written but the receiver does not answer UBX (RTCM injected blind)
        v = chain(diag(2000, 0, 2000, 1, 1, 2000, 2000, "SIN_RESPUESTA_UBX", 10), 2000, 2000, RtkState.DESCONOCIDO).diagnose(p)
        assertEquals(RtcmChain.Stage.RECEIVER, v.stage)
        // written, receiver discards them
        v = chain(diag(2000, 0, 2000, 1, 1, 2000, 2000, "FUNCIONANDO", 10, fail = 30), 2000, 2000, RtkState.AUTONOMO).diagnose(p)
        assertEquals(RtcmChain.Stage.RECEIVER, v.stage); assertTrue(v.texto.contains("mountpoint"))
        // applied, not converged yet
        v = chain(diag(2000, 0, 2000, 1, 1, 2000, 2000, "FUNCIONANDO", 20), 2000, 2000, RtkState.DGNSS).diagnose(p)
        assertEquals(RtcmChain.Stage.RTK, v.stage)
        // old chest firmware without the chain counters
        assertEquals(RtcmChain.Stage.CHEST, chain(null, 2000, 2000, RtkState.AUTONOMO).diagnose(p).stage)
    }
}
