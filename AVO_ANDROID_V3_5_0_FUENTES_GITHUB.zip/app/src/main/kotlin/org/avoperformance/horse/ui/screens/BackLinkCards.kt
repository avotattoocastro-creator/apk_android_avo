package org.avoperformance.horse.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.avoperformance.horse.AppContainer
import org.avoperformance.horse.core.ble.BleStatus
import org.avoperformance.horse.core.telemetry.RtcmChain
import org.avoperformance.horse.core.telemetry.RtkDeriver
import org.avoperformance.horse.ui.components.AvoCard
import org.avoperformance.horse.ui.components.ConfirmDialog
import org.avoperformance.horse.ui.components.Fmt
import org.avoperformance.horse.ui.components.KV
import org.avoperformance.horse.ui.components.Note
import org.avoperformance.horse.ui.components.StatusPill
import org.avoperformance.horse.ui.theme.AvoColors

/** Reads the chest DIAG every [periodMs] while the chest is ready. null = not available. */
@Composable
fun rememberDiag(c: AppContainer, periodMs: Long = 3000): Map<String, String>? {
    val link by c.watch.state.collectAsStateWithLifecycle()
    var diag by remember { mutableStateOf<Map<String, String>?>(null) }
    LaunchedEffect(link) {
        while (c.watch.isReady) {
            diag = runCatching { c.watch.client?.diag() }.getOrNull() ?: diag
            delay(periodMs)
        }
    }
    return diag
}

/**
 * The whole correction path with real counters at every hop, and the first hop where
 * the bytes stop. This is what answers "¿por qué no inyecta los RTCM?".
 */
@Composable
fun RtcmChainCard(c: AppContainer, diag: Map<String, String>?) {
    val ntrip by c.ntrip.stats.collectAsStateWithLifecycle()
    val path by c.ntrip.path.collectAsStateWithLifecycle()
    val tel by c.watch.telemetry.collectAsStateWithLifecycle()
    val now = rememberNow()
    val rtk = RtkDeriver.derive(tel?.t, tel?.let { now - it.receivedMs } ?: Long.MAX_VALUE).state
    val chain = RtcmChain.from(diag, ntrip.bytesReceived, path.sentBytes, rtk)
    var prev by remember { mutableStateOf<RtcmChain?>(null) }
    var verdict by remember { mutableStateOf<RtcmChain.Verdict?>(null) }
    LaunchedEffect(diag) {
        if (diag != null) { verdict = chain.diagnose(prev); prev = chain }
    }
    AvoCard("Cadena de correcciones RTCM") {
        verdict?.let {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(it.stage.texto, color = AvoColors.TextDim, modifier = Modifier.weight(1f))
                StatusPill(if (it.ok) "OK" else "Se corta aquí", if (it.ok) AvoColors.Ok else AvoColors.Bad)
            }
            Note(it.texto, if (it.ok) AvoColors.Ok else AvoColors.Warn)
        } ?: Note(if (c.watch.isReady) "Midiendo… (dos lecturas separadas 3 s)" else "Conecta el chaleco para ver la cadena completa.")
        KV("1 · Caster → teléfono", Fmt.bytes(chain.ntripBytes))
        KV("2 · Teléfono → pecho (enviado)", Fmt.bytes(chain.phoneSentBytes))
        KV("3 · Recibido en el pecho", Fmt.bytes(chain.chestRxBytes))
        if ((chain.chestRejectedUnauth ?: 0) > 0) KV("   Rechazado (teléfono sin autorizar)", Fmt.bytes(chain.chestRejectedUnauth), AvoColors.Bad)
        KV("4 · Pecho → espalda", Fmt.bytes(chain.chestSentToBack))
        if ((chain.chestNoLink ?: 0) > 0) KV("   Descartado sin espalda", Fmt.bytes(chain.chestNoLink), AvoColors.Warn)
        KV("5 · Recibido en la espalda", Fmt.bytes(chain.backRxBytes))
        KV("6 · Escrito en el receptor", Fmt.bytes(chain.backToZed))
        KV("7 · Aplicadas por el receptor", chain.zedUsed?.let { "$it mensajes" })
        if ((chain.zedFailed ?: 0) > 0) KV("   Descartadas por el receptor", "${chain.zedFailed} mensajes", AvoColors.Warn)
        KV("8 · Estado RTK (receptor)", rtk.texto, AvoColors.rtk(rtk))
    }
}

@Composable
fun BackLinkCard(c: AppContainer, diag: Map<String, String>?) {
    val scope = rememberCoroutineScope()
    val info by c.watch.info.collectAsStateWithLifecycle()
    var msg by remember { mutableStateOf<String?>(null) }
    var confirmPair by remember { mutableStateOf(false) }
    var confirmForget by remember { mutableStateOf(false) }
    val supported = info?.supportsBackLink == true
    AvoCard("Espalda (enlace ESP-NOW)") {
        if (info != null && !supported) {
            Note("El firmware del pecho (${info?.firmware}) no tiene enlace ESP-NOW con la espalda. Instala V3.5.0 en pecho y espalda.", AvoColors.Warn)
            return@AvoCard
        }
        val d = diag
        val paired = d?.get("now_paired") == "1"
        val heard = d?.get("uart") == "1"
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("Estado", color = AvoColors.TextDim)
            StatusPill(when {
                d == null -> "Sin datos"
                d["now_pairing"] == "1" -> "Emparejando…"
                !paired -> "Sin emparejar"
                heard -> "Conectada"
                else -> "Sin conexión"
            }, when { d == null -> AvoColors.Unknown; paired && heard -> AvoColors.Ok; d["now_pairing"] == "1" -> AvoColors.Warn; else -> AvoColors.Bad })
        }
        KV("Espalda emparejada", d?.get("now_peer")?.takeIf { paired })
        KV("Firmware de la espalda", d?.get("back_fw"))
        KV("Señal (pecho / espalda)", d?.let { "${it["now_rssi"] ?: "?"} / ${it["back_rssi"] ?: "?"} dBm" })
        KV("Paquetes enviados / fallidos", d?.let { "${it["now_tx_ok"] ?: "?"} / ${it["now_tx_fail"] ?: "?"}" })
        KV("Receptor ZED", d?.get("zed"))
        KV("Puerto y baudios del ZED", d?.let { m -> m["zed_port"]?.let { p -> "UART$p · ${m["zed_baud"]} bd" } })
        KV("Posiciones recibidas", d?.get("back_gnss_hz")?.let { "$it Hz" })
        msg?.let { Note(it, AvoColors.Info) }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(enabled = c.watch.isReady, onClick = { confirmPair = true }) { Text("Emparejar espalda") }
            OutlinedButton(enabled = c.watch.isReady && paired, onClick = { confirmForget = true }) { Text("Olvidar espalda") }
        }
        Note("Una espalda nueva o sin pareja se empareja sola. Para cambiar de espalda: «Emparejar espalda» aquí y, si la espalda ya tenía otro pecho, mantén su botón PRG 3 s.")
    }
    if (confirmPair) ConfirmDialog("Emparejar espalda", "El pecho buscará una espalda durante 60 s. Ten la espalda encendida cerca.", "Emparejar",
        onConfirm = { scope.launch { msg = when (runCatching { c.watch.client?.backLink(1) }.getOrNull()) {
            BleStatus.OK -> "Buscando espalda durante 60 s…"; null -> "Sin conexión con el pecho"; else -> "El pecho no aceptó la orden" } } },
        onDismiss = { confirmPair = false })
    if (confirmForget) ConfirmDialog("Olvidar espalda", "El pecho dejará de usar esta espalda y buscará otra. Las correcciones y la posición se cortan hasta emparejar.", "Olvidar", danger = true,
        onConfirm = { scope.launch { msg = if (runCatching { c.watch.client?.backLink(2) }.getOrNull() == BleStatus.OK) "Espalda olvidada; buscando otra" else "No se pudo" } },
        onDismiss = { confirmForget = false })
}
