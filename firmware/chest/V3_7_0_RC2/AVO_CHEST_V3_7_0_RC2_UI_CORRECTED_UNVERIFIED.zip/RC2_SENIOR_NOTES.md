# AVO CHEST V3.7.0 RC2 — Memory-safe UI redraw patch

This revision retains the 7-card Arduino_GFX UI, with rotation 0 and no LVGL or full-screen framebuffer. It adds one 32-bit FNV-style fingerprint per card and redraws only cards whose status text, telemetry or color changed. The screen is fully redrawn only on initialization, wake, and after special screens. This reduces QSPI traffic and avoids visible whole-screen flashing. No sensor values are fabricated.

It is NOT a pixel-exact match to the reference. Fonts and icons are still native primitives. It has passed source tests but has NOT been compiled or hardware-tested. OTA must not be installed before a successful compile and partition verification.
