// Link to the back module + RTCM router.
// V3.5.0: the AVO UART PROTOCOL v1 frames travel over ESP-NOW (default) instead of a
// cable. Build with -DAVO_LINK_UART=1 to use the old UART cable on PIN_LINK_TX/RX.
// ESP-NOW framing and pairing: lib/avo_core/src/avo_espnow_link.h
#include <Arduino.h>
#include <driver/uart.h>
#ifndef AVO_LINK_UART
#define AVO_LINK_UART 0
#endif
#if !AVO_LINK_UART
#include <WiFi.h>
#include <esp_now.h>
#include <esp_wifi.h>
#include <esp_idf_version.h>
#include <esp_random.h>
#include "freertos/semphr.h"
#endif
#include "freertos/FreeRTOS.h"
#include "freertos/message_buffer.h"
#include "freertos/stream_buffer.h"
#include "freertos/task.h"
#include "esp_task_wdt.h"
#include "app_state.h"
#include "board_pins.h"
#include "services.h"
#include "sys_util.h"

using namespace avo;

// =============================================================== RTCM router
namespace rtcm {
static StreamBufferHandle_t s_sb = nullptr;
static portMUX_TYPE s_mux = portMUX_INITIALIZER_UNLOCKED;
static uint32_t s_offset = 0;   // stream offset of the next byte to send
static RtcmObserver s_obs;

bool init(size_t n) {
  s_sb = psram_stream_buffer(n);
  return s_sb != nullptr;
}

size_t free_space() { return s_sb ? xStreamBufferSpacesAvailable(s_sb) : 0; }

size_t push(const uint8_t* d, size_t n) {
  if (!s_sb || !n) return 0;
  // All-or-nothing per BLE message so RTCM frames are never split by a drop.
  size_t acc = 0;
  portENTER_CRITICAL(&s_mux);
  bool room = xStreamBufferSpacesAvailable(s_sb) >= n;
  portEXIT_CRITICAL(&s_mux);
  if (room) acc = xStreamBufferSend(s_sb, d, n, 0);
  s_obs.feed(d, n);  // statistics only; bytes are forwarded unmodified
  appstate::update([&](AppSnapshot& s) {
    s.rtcm.ble_rx_bytes += n;
    s.rtcm.ble_msgs++;
    s.rtcm.last_rx_ms = sys::ms();
    s.rtcm.queued_bytes = (uint32_t)xStreamBufferBytesAvailable(s_sb);
    if (acc != n) s.rtcm.dropped_bytes += (uint32_t)(n - acc);
    s.rtcm.observed = s_obs.stats();
  });
  if (acc) {
    // Keep a copy of the correction stream in the RAW file (shed first under load).
    sink::push(RecType::RTCM_BYTES, 0, d, acc, sink::BULK);
  } else {
    static uint32_t last = 0;
    if (sys::ms() - last > 5000) { last = sys::ms(); bb::log(BbCode::RTCM_OVERFLOW, 1, (uint32_t)n); }
  }
  return acc;
}

size_t take(uint8_t* out, size_t max, uint32_t* off) {
  if (!s_sb) return 0;
  size_t n = xStreamBufferReceive(s_sb, out, max, 0);
  *off = s_offset;
  s_offset += (uint32_t)n;
  return n;
}

void on_sent(size_t n) {
  appstate::update([&](AppSnapshot& s) {
    s.rtcm.sent_to_back_bytes += (uint32_t)n;
    s.rtcm.queued_bytes = (uint32_t)xStreamBufferBytesAvailable(s_sb);
  });
}
}  // namespace rtcm

// =============================================================== link to the back
namespace uartlink {
#if AVO_LINK_UART
static const uart_port_t PORT = UART_NUM_1;
static QueueHandle_t s_evq = nullptr;
#endif
static MessageBufferHandle_t s_hi = nullptr, s_lo = nullptr;
static TaskHandle_t s_tx_task = nullptr;
static UartDecoder* s_dec = nullptr;
static uint16_t s_seq = 0;
static uint32_t s_baud = 0;
static uint16_t s_cmd_id = 0;
static uint32_t s_last_girth_seq[3] = {0, 0, 0};
static bool s_have_girth_seq[3] = {false, false, false};
static uint32_t s_gnss_count = 0, s_gnss_rate_t = 0;

struct Pending { bool used; uint16_t cmd_id; uint8_t tries; uint32_t t; Command c; };
static Pending s_pend[4];
static portMUX_TYPE s_pmux = portMUX_INITIALIZER_UNLOCKED;

#if !AVO_LINK_UART
// ---------------------------------------------------------------- ESP-NOW transport
static const uint8_t kBroadcast[6] = {0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF};
static MessageBufferHandle_t s_rxmb = nullptr;      // [mac 6][rssi 1][packet] from the WiFi task
static SemaphoreHandle_t s_sent_sem = nullptr;
static volatile bool s_sent_ok = false;
static NowPairing s_pair(NowRole::CHEST);
static NowBootGuard s_guard;
static NowPacker s_pk;
static uint32_t s_boot_id = 0;
static uint32_t s_pk_rtcm = 0;                      // RTCM bytes inside the packet being built
static volatile uint32_t s_pair_request_ms = 0;     // set by the BLE task, applied by the TX task
static volatile bool s_forget_request = false;
static volatile uint32_t s_rx_drop = 0;
static char s_dev_id[16] = {0};

#if ESP_IDF_VERSION >= ESP_IDF_VERSION_VAL(5, 5, 0)
static void now_sent_cb(const esp_now_send_info_t*, esp_now_send_status_t st) {
#else
static void now_sent_cb(const uint8_t*, esp_now_send_status_t st) {
#endif
  s_sent_ok = (st == ESP_NOW_SEND_SUCCESS);
  if (s_sent_sem) xSemaphoreGive(s_sent_sem);
}

static void enqueue_rx(const uint8_t* mac, int8_t rssi, const uint8_t* d, int n) {
  if (!s_rxmb || n <= 0 || n > (int)NOW_MAX_PACKET) return;
  uint8_t b[7 + NOW_MAX_PACKET];
  memcpy(b, mac, 6);
  b[6] = (uint8_t)rssi;
  memcpy(b + 7, d, (size_t)n);
  if (xMessageBufferSend(s_rxmb, b, 7 + (size_t)n, 0) == 0) s_rx_drop = s_rx_drop + 1;
}

#if ESP_IDF_VERSION_MAJOR >= 5
static void now_recv_cb(const esp_now_recv_info_t* info, const uint8_t* d, int n) {
  enqueue_rx(info->src_addr, info->rx_ctrl ? (int8_t)info->rx_ctrl->rssi : 0, d, n);
}
#else
static void now_recv_cb(const uint8_t* mac, const uint8_t* d, int n) { enqueue_rx(mac, 0, d, n); }
#endif

// Only the TX task calls this (one packet in flight; waits for the MAC-level result).
static bool radio_send(const uint8_t* mac, const uint8_t* d, size_t n) {
  xSemaphoreTake(s_sent_sem, 0);
  if (esp_now_send(mac, d, n) != ESP_OK) return false;
  if (xSemaphoreTake(s_sent_sem, pdMS_TO_TICKS(80)) != pdTRUE) return false;
  return s_sent_ok;
}

static void add_peer(const uint8_t mac[6]) {
  if (esp_now_is_peer_exist(mac)) return;
  esp_now_peer_info_t p = {};
  memcpy(p.peer_addr, mac, 6);
  p.channel = NOW_CHANNEL_DEFAULT;
  p.ifidx = WIFI_IF_STA;
  p.encrypt = false;
  esp_now_add_peer(&p);
}

static void publish_pairing() {
  NowPeerRecord r = s_pair.peer();
  bool open = s_pair.open_now(sys::ms());
  appstate::update([&](AppSnapshot& s) {
    s.link.now_paired = r.valid;
    s.link.now_pairing = open;
    memcpy(s.link.now_peer, r.mac, 6);
  });
}

static void open_pairing(uint32_t ms) {
  s_pair.open(sys::ms(), ms, esp_random() | 1u, esp_random() | 1u);
  bb::log(BbCode::UART_LOST, 0, ms, 0, "espnow pairing open");
  publish_pairing();
}

static void flush_packet() {
  if (s_pk.empty()) return;
  uint32_t rtcm_in_packet = s_pk_rtcm;
  s_pk_rtcm = 0;
  if (!s_pair.paired()) {
    s_pk.clear();
    if (rtcm_in_packet) appstate::update([&](AppSnapshot& s) { s.rtcm.dropped_bytes += rtcm_in_packet; });
    return;
  }
  NowHeader h;
  h.kind = NowKind::DATA;
  h.pair_id = s_pair.peer().pair_id;
  h.boot_id = s_boot_id;
  uint8_t pkt[NOW_MAX_PACKET];
  size_t n = now_build(h, s_pk.data(), s_pk.size(), pkt, sizeof(pkt));
  s_pk.clear();
  if (!n) return;
  bool ok = false;
  uint32_t retries = 0;
  for (int i = 0; i < 4 && !ok; i++) {
    if (i) retries++;
    ok = radio_send(s_pair.peer().mac, pkt, n);
  }
  appstate::update([&](AppSnapshot& s) {
    s.link.tx_frames++;
    s.link.tx_bytes += (uint32_t)n;
    s.link.now_retries += retries;
    if (ok) s.link.now_tx_ok++;
    else {
      s.link.now_tx_fail++;
      s.rtcm.dropped_bytes += rtcm_in_packet;   // never silent: the app shows it
    }
  });
}

static void emit(const uint8_t* f, size_t n) {
  if (!s_pk.fits(n)) flush_packet();
  s_pk.add(f, n);
}
#endif  // !AVO_LINK_UART

bool send(FrameType t, const uint8_t* p, size_t len, bool hi, uint8_t flags) {
  if (len > AVO_UART_MAX_PAYLOAD || !s_hi) return false;
  uint8_t tmp[2 + AVO_UART_MAX_PAYLOAD];
  tmp[0] = (uint8_t)t;
  tmp[1] = flags | (hi ? FF_PRIO_HIGH : 0);
  if (len) memcpy(tmp + 2, p, len);
  size_t r = xMessageBufferSend(hi ? s_hi : s_lo, tmp, len + 2, 0);
  if (r == 0) {
    appstate::update([&](AppSnapshot& s) { if (hi) s.link.tx_drop_hi++; else s.link.tx_drop_lo++; });
    return false;
  }
  if (s_tx_task) xTaskNotifyGive(s_tx_task);
  return true;
}

bool send_command(BackCmd cmd, const uint8_t* args, uint8_t arg_len) {
  Command c;
  c.cmd = (uint16_t)cmd;
  portENTER_CRITICAL(&s_pmux);
  c.cmd_id = ++s_cmd_id;
  portEXIT_CRITICAL(&s_pmux);
  c.arg_len = arg_len > sizeof(c.args) ? sizeof(c.args) : arg_len;
  if (c.arg_len) memcpy(c.args, args, c.arg_len);
  uint8_t buf[64];
  size_t n = encode_command(c, buf, sizeof(buf));
  bool ok = n && send(FrameType::COMMAND, buf, n, true, FF_ACK_REQ);
  if (ok) {
    portENTER_CRITICAL(&s_pmux);
    for (auto& p : s_pend) if (!p.used) { p.used = true; p.cmd_id = c.cmd_id; p.tries = 1; p.t = sys::ms(); p.c = c; break; }
    portEXIT_CRITICAL(&s_pmux);
  }
  return ok;
}

bool pair_start(uint32_t window_ms) {
#if AVO_LINK_UART
  (void)window_ms;
  return false;
#else
  s_pair_request_ms = window_ms ? window_ms : 60000;
  if (s_tx_task) xTaskNotifyGive(s_tx_task);
  return true;
#endif
}

bool pair_forget() {
#if AVO_LINK_UART
  return false;
#else
  s_forget_request = true;
  if (s_tx_task) xTaskNotifyGive(s_tx_task);
  return true;
#endif
}

static sink::Prio prio_for(FrameType t) {
  switch (t) {
    case FrameType::GNSS_SAMPLE: case FrameType::GNSS_UBX: case FrameType::IMU_SAMPLE:
    case FrameType::EVENT: case FrameType::TIME_SYNC: case FrameType::CAPS:
      return sink::CRITICAL;
    case FrameType::STATUS:
      return sink::NORMAL;
    default:
      return sink::BULK;
  }
}

static void post_gnss(const GnssSample& g, uint32_t now) {
  CtlMsg m = {};
  m.type = CtlType::GNSS;
  m.rx_ms = now;
  m.gnss = g;
  ctl::post(m, 0);
  s_gnss_count++;
}

static void on_frame(const FrameView& f, void*) {
  uint32_t now = sys::ms();
  // 1) RAW first: the verbatim frame goes to the record sink before anything else.
  sink::push(RecType::UART_FRAME, 0, f.raw, f.raw_len, prio_for(f.type));
  // 2) routing
  switch (f.type) {
    case FrameType::GNSS_SAMPLE: {
      GnssSample g;
      if (decode_gnss(f.payload, f.len, &g)) post_gnss(g, now);
      break;
    }
    case FrameType::GNSS_UBX: {
      uint8_t cls, id;
      const uint8_t* pl;
      uint16_t plen;
      if (ubx_check_frame(f.payload, f.len, &cls, &id, &pl, &plen) && cls == UBX_CLS_NAV && id == UBX_ID_NAV_PVT) {
        GnssSample g;
        if (ubx_decode_nav_pvt(pl, plen, &g)) { g.back_rx_ms = f.t_ms; post_gnss(g, now); }
      }
      break;
    }
    case FrameType::IMU_SAMPLE: {
      ImuBatchHeader h;
      if (decode_imu_header(f.payload, f.len, &h)) {
        uint8_t i = h.imu_id < 3 ? h.imu_id : 2;
        uint32_t lost = 0;
        if (s_have_girth_seq[i]) {
          uint32_t d = h.girth_seq - s_last_girth_seq[i];
          if (d > 1 && d < 100000) lost = d - 1;
        }
        s_have_girth_seq[i] = true;
        s_last_girth_seq[i] = h.girth_seq;
        appstate::update([&](AppSnapshot& s) {
          s.girth.batches++;
          s.girth.samples += h.count;
          s.girth.seq_lost += lost;
          uint32_t dt = now - s.girth.last_batch_ms[i];
          if (s.girth.last_batch_ms[i] && dt > 0 && dt < 5000)
            s.girth.rate_hz[i] = 0.9 * s.girth.rate_hz[i] + 0.1 * (h.count * 1000.0 / dt);
          s.girth.last_batch_ms[i] = now;
        });
        CtlMsg m = {};
        m.type = CtlType::IMU_BATCH;
        m.arg8 = h.count;
        m.arg32 = lost;
        ctl::post(m, 0);
      }
      break;
    }
    case FrameType::STATUS: {
      BackStatus b;
      if (decode_status(f.payload, f.len, &b)) {
        appstate::update([&](AppSnapshot& s) {
          s.link.back = b; s.link.status_valid = true; s.link.back_status_ms = now;
          s.girth.connected = b.girth_connected != 0;
        });
      }
      break;
    }
    case FrameType::CAPS: {
      Caps c;
      if (decode_caps(f.payload, f.len, &c)) {
        Caps mine;
        mine.node_type = (uint8_t)NodeId::CHEST;
        uint8_t v = negotiate_version(mine, c);
        appstate::update([&](AppSnapshot& s) { s.link.back_caps = c; s.link.caps_valid = true; s.link.proto_ver = v; });
      }
      break;
    }
    case FrameType::TIME_SYNC: {
      TimeSync t;
      if (decode_timesync(f.payload, f.len, &t))
        appstate::update([&](AppSnapshot& s) { s.link.ts = t; s.link.timesync_valid = (t.flags & 1) != 0; });
      break;
    }
    case FrameType::ACK:
    case FrameType::NACK: {
      Ack a;
      if (decode_ack(f.payload, f.len, &a)) {
        portENTER_CRITICAL(&s_pmux);
        for (auto& p : s_pend) if (p.used && p.cmd_id == a.cmd_id) p.used = false;
        portEXIT_CRITICAL(&s_pmux);
        if (f.type == FrameType::NACK) bb::log(BbCode::UART_LOST, 1, a.cmd_id, a.status, "back NACK");
      }
      break;
    }
    case FrameType::COMMAND: {
      // The back may request CAPS from the chest.
      Command c;
      if (decode_command(f.payload, f.len, &c)) {
        Ack a; a.acked_type = (uint8_t)f.type; a.acked_seq = f.seq; a.cmd_id = c.cmd_id;
        uint8_t b[ACK_V1_LEN];
        if (encode_ack(a, b, sizeof(b))) send(FrameType::ACK, b, ACK_V1_LEN, true);
      }
      break;
    }
    default:
      break;
  }
}

static void send_caps() {
  Caps c;
  c.node_type = (uint8_t)NodeId::CHEST;
  strncpy(c.fw_version, AVO_FW_VERSION, sizeof(c.fw_version) - 1);
  c.caps = CAP_RTCM_IN | CAP_ACK;
  c.uart_baud = s_baud;
#if !AVO_LINK_UART
  c.max_payload = (uint16_t)(NOW_MAX_BODY - AVO_UART_HDR - AVO_UART_TRAILER);
#endif
  uint8_t b[CAPS_V1_LEN];
  size_t n = encode_caps(c, b, sizeof(b));
  if (n) send(FrameType::CAPS, b, n, false);
}

// Connection bookkeeping shared by both transports (every 250 ms).
static void link_housekeeping(uint32_t now, bool* was_connected, uint32_t* last_stats) {
  bool conn;
  appstate::update([&](AppSnapshot& s) {
    s.link.dec = s_dec->stats();
    conn = s.link.last_rx_ms && (now - s.link.last_rx_ms) < 2000;
    s.link.connected = conn;
    if (s_gnss_rate_t == 0) s_gnss_rate_t = now;
    if (now - s_gnss_rate_t >= 2000) {
      s.gnss.rate_hz = s_gnss_count * 1000.0 / (now - s_gnss_rate_t);
      s_gnss_count = 0;
      s_gnss_rate_t = now;
    }
#if !AVO_LINK_UART
    s.link.now_rx_queue_drop = s_rx_drop;
#endif
  });
  if (*was_connected && !conn) bb::log(BbCode::UART_LOST, 2, 0, 0, "back link lost");
  if (!*was_connected && conn) bb::log(BbCode::UART_RESTORED, 0);
  *was_connected = conn;
  if (now - *last_stats >= 10000) {
    *last_stats = now;
    const DecoderStats& d = s_dec->stats();
    uint8_t b[40];
    ByteWriter w(b, sizeof(b));
    w.u32(d.frames_ok); w.u32(d.bytes_in); w.u32(d.resync_bytes); w.u32(d.hdr_crc_err); w.u32(d.len_err);
    w.u32(d.crc_err); w.u32(d.duplicates); w.u32(d.out_of_order); w.u32(d.seq_lost); w.u32(d.unknown_version);
    sink::push(RecType::DECODER_STATS, 0, b, w.size(), sink::NORMAL);
  }
}

static void feed_decoder(const uint8_t* d, size_t n) {
  uint32_t before = s_dec->stats().frames_ok;
  s_dec->feed(d, n);
  if (s_dec->stats().frames_ok != before) appstate::update([&](AppSnapshot& s) { s.link.last_rx_ms = sys::ms(); });
}

#if AVO_LINK_UART
static void rx_task(void*) {
  esp_task_wdt_add(nullptr);
  static uint8_t buf[2048];
  uart_event_t ev;
  bool was_connected = false;
  uint32_t last_check = 0, last_stats = 0;
  for (;;) {
    if (xQueueReceive(s_evq, &ev, pdMS_TO_TICKS(100)) == pdTRUE) {
      if (ev.type == UART_DATA) {
        size_t avail = 0;
        uart_get_buffered_data_len(PORT, &avail);
        while (avail) {
          int n = uart_read_bytes(PORT, buf, avail > sizeof(buf) ? sizeof(buf) : avail, 0);
          if (n <= 0) break;
          feed_decoder(buf, (size_t)n);
          uart_get_buffered_data_len(PORT, &avail);
        }
      } else if (ev.type == UART_FIFO_OVF || ev.type == UART_BUFFER_FULL) {
        uart_flush_input(PORT);
        xQueueReset(s_evq);
        appstate::update([&](AppSnapshot& s) { s.link.rx_overflow++; });
        bb::log(BbCode::BUFFER_SATURATED, 2, 1, 0, "uart rx overflow");
      }
    }
    uint32_t now = sys::ms();
    if (now - last_check >= 250) { last_check = now; link_housekeeping(now, &was_connected, &last_stats); }
    esp_task_wdt_reset();
  }
}
#else
static void rx_task(void*) {
  esp_task_wdt_add(nullptr);
  static uint8_t buf[7 + NOW_MAX_PACKET];
  bool was_connected = false;
  uint32_t last_check = 0, last_stats = 0;
  for (;;) {
    size_t got = xMessageBufferReceive(s_rxmb, buf, sizeof(buf), pdMS_TO_TICKS(100));
    if (got > 7) {
      const uint8_t* mac = buf;
      int8_t rssi = (int8_t)buf[6];
      NowHeader h;
      const uint8_t* body;
      if (!now_parse(buf + 7, got - 7, &h, &body)) {
        appstate::update([&](AppSnapshot& s) { s.link.now_rx_bad++; });
      } else if (h.kind == NowKind::PAIR_ACK) {
        NowPairMsg m;
        if (now_pair_decode(body, h.body_len, &m) && s_pair.chest_on_ack(mac, h, m, sys::ms())) {
          uint8_t rec[NOW_PEER_RECORD_LEN];
          size_t rn = now_peer_serialize(s_pair.peer(), rec, sizeof(rec));
          bool saved = rn && sys::nvs_set_blob("nowpeer", rec, rn);
          add_peer(mac);
          s_guard = NowBootGuard();
          char ms[18];
          now_mac_str(mac, ms);
          Serial.printf("[AVO NOW] paired with back %s (%s fw %s) saved=%d\n", ms, m.dev_id, m.fw, saved);
          bb::log(BbCode::UART_RESTORED, 0, s_pair.peer().pair_id, saved, "espnow paired");
          publish_pairing();
        }
      } else if (h.kind == NowKind::DATA) {
        if (s_pair.accept_data(mac, h.pair_id)) {
          if (s_guard.changed(h.boot_id)) {
            // The back restarted: its frame sequence starts again.
            delete s_dec;
            s_dec = new UartDecoder(on_frame, nullptr);
          }
          appstate::update([&](AppSnapshot& s) { s.link.now_rx_pkts++; s.link.now_rssi = rssi; });
          feed_decoder(body, h.body_len);
        } else {
          appstate::update([&](AppSnapshot& s) { s.link.now_rx_foreign++; });
        }
      }
    }
    uint32_t now = sys::ms();
    if (now - last_check >= 250) { last_check = now; link_housekeeping(now, &was_connected, &last_stats); }
    esp_task_wdt_reset();
  }
}
#endif

static void write_frame(FrameType t, uint8_t flags, const uint8_t* p, size_t len) {
  static uint8_t f[AVO_UART_MAX_FRAME];
  size_t n = uart_encode(t, flags, (uint8_t)NodeId::CHEST, s_seq++, sys::ms(), p, len, f, sizeof(f));
  if (!n) return;
#if AVO_LINK_UART
  uart_write_bytes(PORT, (const char*)f, n);
  appstate::update([&](AppSnapshot& s) { s.link.tx_frames++; s.link.tx_bytes += (uint32_t)n; });
#else
  if (n > NOW_MAX_BODY) {   // only possible for oversized low-priority payloads: never sent over the radio
    appstate::update([&](AppSnapshot& s) { s.link.tx_drop_lo++; });
    return;
  }
  emit(f, n);
#endif
}

static void tx_task(void*) {
  static uint8_t msg[2 + AVO_UART_MAX_PAYLOAD];
#if AVO_LINK_UART
  static const size_t kRtcmChunk = 512;
#else
  static const size_t kRtcmChunk = NOW_RTCM_CHUNK;
#endif
  static uint8_t rt[RTCM_DATA_HDR + 512];
  uint32_t last_hb = 0, last_caps = 0, last_retry = 0;
  for (;;) {
    ulTaskNotifyTake(pdTRUE, pdMS_TO_TICKS(10));
    uint32_t now = sys::ms();
#if !AVO_LINK_UART
    // ---- pairing requests from the app (applied here: single owner of the radio)
    if (s_forget_request) {
      s_forget_request = false;
      if (s_pair.paired() && esp_now_is_peer_exist(s_pair.peer().mac)) esp_now_del_peer(s_pair.peer().mac);
      s_pair.forget();
      { uint8_t z[NOW_PEER_RECORD_LEN] = {0}; sys::nvs_set_blob("nowpeer", z, sizeof(z)); }
      open_pairing(0);
    }
    if (s_pair_request_ms) { uint32_t ms = s_pair_request_ms; s_pair_request_ms = 0; open_pairing(ms); }
    {
      uint8_t body[NOW_PAIR_BODY + 4];
      size_t bl = s_pair.chest_poll(now, s_dev_id, AVO_FW_VERSION, body, sizeof(body));
      if (bl) {
        NowHeader h; h.kind = NowKind::PAIR_REQ; h.pair_id = s_pair.proposed_pair_id(); h.boot_id = s_boot_id;
        uint8_t pkt[NOW_MAX_PACKET];
        size_t pn = now_build(h, body, bl, pkt, sizeof(pkt));
        if (pn) radio_send(kBroadcast, pkt, pn);
        publish_pairing();
      }
    }
    bool link_up;
    appstate::lock(); link_up = appstate::raw().link.connected; appstate::unlock();
#endif
    // 1) RTCM first: corrections are time-critical.
    for (int k = 0; k < 8; k++) {
      uint32_t off;
      size_t n = rtcm::take(rt + RTCM_DATA_HDR, kRtcmChunk, &off);
      if (!n) break;
#if !AVO_LINK_UART
      if (!link_up) {   // no back to deliver to: counted, never silent
        appstate::update([&](AppSnapshot& s) { s.rtcm.dropped_bytes += (uint32_t)n; s.link.rtcm_dropped_nolink += (uint32_t)n; });
        continue;
      }
#endif
      put_u32(rt, off);
      write_frame(FrameType::RTCM_DATA, FF_PRIO_HIGH, rt, n + RTCM_DATA_HDR);
#if !AVO_LINK_UART
      s_pk_rtcm += (uint32_t)n;
      flush_packet();
#endif
      rtcm::on_sent(n);
    }
    // 2) high lane then 3) low lane (bounded so low traffic never starves RTCM)
    size_t n;
    while ((n = xMessageBufferReceive(s_hi, msg, sizeof(msg), 0)) >= 2) write_frame((FrameType)msg[0], msg[1], msg + 2, n - 2);
    for (int k = 0; k < 4 && (n = xMessageBufferReceive(s_lo, msg, sizeof(msg), 0)) >= 2; k++)
      write_frame((FrameType)msg[0], msg[1], msg + 2, n - 2);

    now = sys::ms();
    if (now - last_hb >= 1000) {
      last_hb = now;
      Heartbeat h;
      h.uptime_ms = now;
      h.queue_fill_pct_x10 = (uint16_t)sink::fill_permille();
      uint8_t b[HEARTBEAT_V1_LEN];
      if (encode_heartbeat(h, b, sizeof(b))) send(FrameType::HEARTBEAT, b, HEARTBEAT_V1_LEN, false);
    }
    AppSnapshot* raw = nullptr;
    bool caps_valid;
    appstate::lock(); raw = &appstate::raw(); caps_valid = raw->link.caps_valid; appstate::unlock();
    if (!caps_valid && now - last_caps >= 3000) {
      last_caps = now;
      send_caps();
      send_command(BackCmd::REQ_CAPS, nullptr, 0);
    }
    if (now - last_retry >= 100) {
      last_retry = now;
      Command resend[4];
      int nr = 0;
      portENTER_CRITICAL(&s_pmux);
      for (auto& p : s_pend) {
        if (!p.used || now - p.t < 300) continue;
        if (p.tries >= 3) { p.used = false; continue; }  // give up silently; counted by the back's stats
        p.tries++; p.t = now; resend[nr++] = p.c;
      }
      portEXIT_CRITICAL(&s_pmux);
      for (int i = 0; i < nr; i++) {
        uint8_t b[64];
        size_t len = encode_command(resend[i], b, sizeof(b));
        if (len) send(FrameType::COMMAND, b, len, true, FF_ACK_REQ | FF_RETX);
      }
    }
#if !AVO_LINK_UART
    flush_packet();
    static uint32_t last_pub = 0;
    if (now - last_pub >= 1000) { last_pub = now; publish_pairing(); }
#endif
  }
}

#if !AVO_LINK_UART
static bool now_init() {
  s_rxmb = xMessageBufferCreate(8192);
  s_sent_sem = xSemaphoreCreateBinary();
  if (!s_rxmb || !s_sent_sem) return false;
  s_boot_id = esp_random() | 1u;
  WiFi.mode(WIFI_STA);
  WiFi.disconnect();
  esp_err_t e = esp_wifi_set_channel(NOW_CHANNEL_DEFAULT, WIFI_SECOND_CHAN_NONE);
  if (e != ESP_OK) { Serial.printf("[AVO NOW] set_channel error %d\n", (int)e); return false; }
  e = esp_now_init();
  if (e != ESP_OK) { Serial.printf("[AVO NOW] esp_now_init error %d\n", (int)e); return false; }
  esp_now_register_recv_cb(now_recv_cb);
  esp_now_register_send_cb(now_sent_cb);
  add_peer(kBroadcast);
  uint8_t mac[6];
  esp_wifi_get_mac(WIFI_IF_STA, mac);
  snprintf(s_dev_id, sizeof(s_dev_id), "%02X%02X%02X%02X%02X%02X", mac[0], mac[1], mac[2], mac[3], mac[4], mac[5]);
  uint8_t rec[NOW_PEER_RECORD_LEN];
  size_t rn = sizeof(rec);
  NowPeerRecord r;
  if (sys::nvs_get_blob("nowpeer", rec, &rn) && now_peer_deserialize(rec, rn, &r)) {
    s_pair.load(r);
    add_peer(r.mac);
    char ms[18];
    now_mac_str(r.mac, ms);
    Serial.printf("[AVO NOW] chest %s channel %u, paired back %s\n", s_dev_id, NOW_CHANNEL_DEFAULT, ms);
  } else {
    Serial.printf("[AVO NOW] chest %s channel %u, NOT paired: pairing open until a back answers\n", s_dev_id, NOW_CHANNEL_DEFAULT);
    s_pair.open(sys::ms(), 0, esp_random() | 1u, esp_random() | 1u);
  }
  publish_pairing();
  return true;
}
#endif

bool init(uint32_t baud) {
  s_baud = baud;
  s_hi = psram_message_buffer(8192);
  s_lo = psram_message_buffer(8192);
  if (!s_hi || !s_lo) return false;
  s_dec = new UartDecoder(on_frame, nullptr);
#if AVO_LINK_UART
  uart_config_t c = {};
  c.baud_rate = (int)baud;
  c.data_bits = UART_DATA_8_BITS;
  c.parity = UART_PARITY_DISABLE;
  c.stop_bits = UART_STOP_BITS_1;
  c.flow_ctrl = UART_HW_FLOWCTRL_DISABLE;
  c.source_clk = UART_SCLK_DEFAULT;
  if (uart_driver_install(PORT, 16384, 4096, 32, &s_evq, 0) != ESP_OK) return false;
  if (uart_param_config(PORT, &c) != ESP_OK) return false;
  if (uart_set_pin(PORT, PIN_LINK_TX, PIN_LINK_RX, UART_PIN_NO_CHANGE, UART_PIN_NO_CHANGE) != ESP_OK) return false;
  uart_set_rx_full_threshold(PORT, 64);
  uart_set_rx_timeout(PORT, 4);
  appstate::update([&](AppSnapshot& s) { s.link.baud = baud; s.link.transport = 0; });
#else
  if (!now_init()) return false;
  appstate::update([&](AppSnapshot& s) { s.link.baud = 0; s.link.transport = 1; });
#endif
  xTaskCreatePinnedToCore(rx_task, "link_rx", 8192, nullptr, 18, nullptr, 1);
  xTaskCreatePinnedToCore(tx_task, "link_tx", 8192, nullptr, 17, &s_tx_task, 1);
  return true;
}
}  // namespace uartlink
