// App snapshot, record sink, blackbox and configuration store.
#include <Arduino.h>
#include <esp_heap_caps.h>
#include <esp_partition.h>
#include "freertos/FreeRTOS.h"
#include "freertos/semphr.h"
#include "freertos/queue.h"
#include "freertos/task.h"
#include "app_state.h"
#include "services.h"
#include "sys_util.h"

using namespace avo;

const char* rec_status_str(RecStatus s) {
  switch (s) {
    case RecStatus::IDLE: return "EN ESPERA";
    case RecStatus::RECORDING: return "GRABANDO";
    case RecStatus::TEMP_BUFFER: return "BUFFER TEMPORAL";
    case RecStatus::REC_ERROR: return "ERROR DE GRABACION";
  }
  return "?";
}

// =============================================================== PSRAM-backed buffers
MessageBufferHandle_t psram_message_buffer(size_t bytes) {
  uint8_t* mem = (uint8_t*)heap_caps_malloc(bytes + 1, MALLOC_CAP_SPIRAM);
  StaticMessageBuffer_t* st = (StaticMessageBuffer_t*)heap_caps_malloc(sizeof(StaticMessageBuffer_t), MALLOC_CAP_INTERNAL);
  if (!mem || !st) return nullptr;
  return xMessageBufferCreateStatic(bytes + 1, mem, st);
}
StreamBufferHandle_t psram_stream_buffer(size_t bytes) {
  uint8_t* mem = (uint8_t*)heap_caps_malloc(bytes + 1, MALLOC_CAP_SPIRAM);
  StaticStreamBuffer_t* st = (StaticStreamBuffer_t*)heap_caps_malloc(sizeof(StaticStreamBuffer_t), MALLOC_CAP_INTERNAL);
  if (!mem || !st) return nullptr;
  return xStreamBufferCreateStatic(bytes + 1, 1, mem, st);
}

// =============================================================== appstate
namespace appstate {
static SemaphoreHandle_t s_mtx = nullptr;
static AppSnapshot* s_snap = nullptr;
void init() {
  if (!s_mtx) s_mtx = xSemaphoreCreateMutex();
  if (!s_snap) s_snap = new AppSnapshot();
}
void lock() { xSemaphoreTake(s_mtx, portMAX_DELAY); }
void unlock() { xSemaphoreGive(s_mtx); }
AppSnapshot& raw() { return *s_snap; }
void get(AppSnapshot* out) {
  lock();
  *out = *s_snap;
  unlock();
}
}  // namespace appstate

// =============================================================== record sink
namespace sink {
static RecordRing s_ring;
static SemaphoreHandle_t s_mtx = nullptr;
static uint32_t s_drop_total = 0, s_drop_low = 0, s_drop_crit = 0, s_drop_pending = 0, s_peak = 0;
static TaskHandle_t s_writer = nullptr;

bool init(size_t bytes) {
  uint8_t* mem = (uint8_t*)heap_caps_malloc(bytes, MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
  if (!mem) return false;
  s_ring.init(mem, bytes);
  s_mtx = xSemaphoreCreateMutex();
  return s_mtx != nullptr;
}

void set_writer_task(void* t) { s_writer = (TaskHandle_t)t; }

bool push(RecType type, uint8_t flags, const uint8_t* data, size_t len, Prio p, uint64_t chest_us) {
  if (!s_mtx || len > 0xFFFF) return false;
  RecHdr h;
  h.type = (uint8_t)type;
  h.flags = flags | (p == BULK ? RF_PRIO_LOW : 0);
  h.len = (uint16_t)len;
  h.chest_us = chest_us ? chest_us : sys::us();
  bool ok = false;
  xSemaphoreTake(s_mtx, portMAX_DELAY);
  uint32_t fill = s_ring.fill_permille();
  if ((p == BULK && fill > 750) || (p == NORMAL && fill > 920)) ok = false;
  else ok = s_ring.push(h, data);
  if (!ok) {
    s_drop_total++;
    s_drop_pending++;
    if (p == BULK) s_drop_low++;
    if (p == CRITICAL) s_drop_crit++;
  }
  fill = s_ring.fill_permille();
  if (fill > s_peak) s_peak = fill;
  xSemaphoreGive(s_mtx);
  if (s_writer && fill > 250) xTaskNotifyGive(s_writer);  // wake the writer early under load
  return ok;
}

// The storage task is the only consumer; peek/pop hold the lock only briefly.
// The returned view stays valid until pop() because producers only append.
bool peek(RecView* v) {
  xSemaphoreTake(s_mtx, portMAX_DELAY);
  bool r = s_ring.peek(v);
  xSemaphoreGive(s_mtx);
  return r;
}
void pop() {
  xSemaphoreTake(s_mtx, portMAX_DELAY);
  s_ring.pop();
  xSemaphoreGive(s_mtx);
}
uint32_t fill_permille() { return s_ring.fill_permille(); }
uint32_t peak_permille() { return s_peak; }
uint32_t dropped_total() { return s_drop_total; }
uint32_t dropped_low() { return s_drop_low; }
uint32_t dropped_critical() { return s_drop_crit; }
uint32_t take_dropped_since_last() {
  xSemaphoreTake(s_mtx, portMAX_DELAY);
  uint32_t d = s_drop_pending;
  s_drop_pending = 0;
  xSemaphoreGive(s_mtx);
  return d;
}
size_t capacity() { return s_ring.capacity(); }
}  // namespace sink

// =============================================================== blackbox
namespace bb {
class PartitionIo : public FlashIo {
 public:
  explicit PartitionIo(const esp_partition_t* p) : p_(p) {}
  size_t size() const override { return p_->size; }
  size_t sector_size() const override { return 4096; }
  bool read(size_t off, void* dst, size_t len) override { return esp_partition_read(p_, off, dst, len) == ESP_OK; }
  bool write(size_t off, const void* src, size_t len) override { return esp_partition_write(p_, off, src, len) == ESP_OK; }
  bool erase_sector(size_t off) override { return esp_partition_erase_range(p_, off, 4096) == ESP_OK; }
 private:
  const esp_partition_t* p_;
};

static Blackbox s_bb;
static PartitionIo* s_io = nullptr;
static QueueHandle_t s_q = nullptr;
static SemaphoreHandle_t s_mtx = nullptr;
static uint32_t s_dropped = 0;
static bool s_ok = false;

static void task(void*) {
  BbRecord r;
  for (;;) {
    if (xQueueReceive(s_q, &r, portMAX_DELAY) == pdTRUE) {
      xSemaphoreTake(s_mtx, portMAX_DELAY);
      if (s_ok) s_bb.append(r);
      xSemaphoreGive(s_mtx);
    }
  }
}

bool init() {
  s_q = xQueueCreate(64, sizeof(BbRecord));
  s_mtx = xSemaphoreCreateMutex();
  const esp_partition_t* p = esp_partition_find_first(ESP_PARTITION_TYPE_DATA, ESP_PARTITION_SUBTYPE_ANY, "blackbox");
  if (p) {
    s_io = new PartitionIo(p);
    s_ok = s_bb.init(s_io);
  }
  xTaskCreatePinnedToCore(task, "bb", 3072, nullptr, 4, nullptr, 0);
  return s_ok;
}

void log(BbCode code, uint8_t sev, uint32_t a0, uint32_t a1, const char* text) {
  BbRecord r;
  r.uptime_ms = sys::ms();
  r.rtc_s = (uint32_t)(sys::wall_ms() / 1000);
  r.boot = sys::boot_count();
  r.code = (uint16_t)code;
  r.severity = sev;
  r.arg0 = a0;
  r.arg1 = a1;
  if (!s_q || xQueueSend(s_q, &r, 0) != pdTRUE) s_dropped++;
  // Mirror into the RAW stream (session file or pre-buffer).
  EventMsg e;
  e.code = (uint16_t)code;
  e.severity = sev;
  e.arg0 = a0;
  e.arg1 = a1;
  if (text) strncpy(e.text, text, sizeof(e.text) - 1);
  uint8_t buf[EVENT_V1_LEN];
  size_t n = encode_event(e, buf, sizeof(buf));
  sink::push(RecType::CHEST_EVENT, 0, buf, n, sink::CRITICAL);
}

int read_recent(int n, Visitor v, void* ctx) {
  if (!s_ok) return 0;
  xSemaphoreTake(s_mtx, portMAX_DELAY);
  int k = s_bb.read_recent(n, v, ctx);
  xSemaphoreGive(s_mtx);
  return k;
}
uint32_t dropped() { return s_dropped; }
}  // namespace bb

// =============================================================== configuration store
namespace cfgstore {
static SemaphoreHandle_t s_mtx = nullptr;
static Config* s_cfg = nullptr;
static uint32_t s_gen = 0, s_crc = 0;

static bool load_slot(const char* key, Config* c, uint32_t* gen) {
  size_t cap = config_max_size() + 8;
  uint8_t* b = (uint8_t*)malloc(cap);
  if (!b) return false;
  size_t len = cap;
  bool ok = sys::nvs_get_blob(key, b, &len) && len > 8;
  if (ok) {
    *gen = (uint32_t)b[0] | ((uint32_t)b[1] << 8) | ((uint32_t)b[2] << 16) | ((uint32_t)b[3] << 24);
    ConfigLoad r = config_deserialize(b + 4, len - 4, c);
    ok = (r == ConfigLoad::OK || r == ConfigLoad::MIGRATED || r == ConfigLoad::NEWER_SCHEMA_OK);
  }
  free(b);
  return ok;
}

static bool store(const Config& c, uint32_t gen) {
  size_t cap = config_max_size() + 8;
  uint8_t* b = (uint8_t*)malloc(cap);
  if (!b) return false;
  b[0] = (uint8_t)gen; b[1] = (uint8_t)(gen >> 8); b[2] = (uint8_t)(gen >> 16); b[3] = (uint8_t)(gen >> 24);
  size_t n = config_serialize(c, b + 4, cap - 4);
  bool ok = n > 0 && sys::nvs_set_blob((gen & 1) ? "cfgB" : "cfgA", b, n + 4);
  if (ok) s_crc = crc32(b + 4, n);
  free(b);
  return ok;
}

bool init(bool* was_corrupt) {
  s_mtx = xSemaphoreCreateMutex();
  s_cfg = new Config();
  Config* pa = new Config();
  Config* pb = new Config();
  Config& a = *pa;
  Config& b = *pb;
  uint32_t ga = 0, gb = 0;
  bool oa = load_slot("cfgA", &a, &ga), ob = load_slot("cfgB", &b, &gb);
  *was_corrupt = false;
  if (oa && (!ob || (int32_t)(ga - gb) > 0)) { *s_cfg = a; s_gen = ga; }
  else if (ob) { *s_cfg = b; s_gen = gb; }
  else {
    config_defaults(s_cfg);
    s_gen = 0;
    size_t probe = 4;
    uint8_t tmp[4];
    // A stored but unreadable blob means corruption (not a first boot).
    *was_corrupt = sys::nvs_get_blob("cfgA", tmp, &probe) || sys::nvs_get_blob("cfgB", tmp, &probe);
    store(*s_cfg, ++s_gen);
    delete pa;
    delete pb;
    return false;
  }
  delete pa;
  delete pb;
  if (oa != ob) *was_corrupt = (ga != 0 || gb != 0) && !(oa && ob);  // one copy damaged; the other was used
  size_t cap = config_max_size();
  uint8_t* t = (uint8_t*)malloc(cap);
  if (t) { size_t n = config_serialize(*s_cfg, t, cap); s_crc = crc32(t, n); free(t); }
  return true;
}

void get(Config* out) {
  xSemaphoreTake(s_mtx, portMAX_DELAY);
  *out = *s_cfg;
  xSemaphoreGive(s_mtx);
}

int set(const Config& in) {
  Config* pc = new Config(in);
  Config& c = *pc;
  int fixed = config_validate(&c);
  xSemaphoreTake(s_mtx, portMAX_DELAY);
  uint32_t g = s_gen + 1;
  bool ok = store(c, g);
  if (ok) { *s_cfg = c; s_gen = g; }
  xSemaphoreGive(s_mtx);
  delete pc;
  if (!ok) return -1;
  CtlMsg m = {};
  m.type = CtlType::CONFIG_CHANGED;
  ctl::post(m, 100);
  bb::log(BbCode::CONFIG_CHANGED, 0, g, (uint32_t)fixed);
  return fixed;
}

uint32_t generation() { return s_gen; }
uint32_t crc() { return s_crc; }
}  // namespace cfgstore
