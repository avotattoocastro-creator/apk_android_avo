// OTA update of the chest from Android over BLE, with SHA-256 verification and
// bootloader rollback (CONFIG_BOOTLOADER_APP_ROLLBACK_ENABLE=y in arduino-esp32 3.3.x).
// Image signing (Secure Boot v2) is NOT enabled: it needs eFuse key provisioning
// that cannot be undone; see KNOWN_LIMITATIONS.md.
#include <Arduino.h>
#include <esp_ota_ops.h>
#include <esp_app_format.h>
#include <mbedtls/sha256.h>
#include <mbedtls/pk.h>
#include <mbedtls/base64.h>
#include <cJSON.h>
#include <stdlib.h>
#include "services.h"
#include "sys_util.h"
#include "avo_version.h"

using namespace avo;

// arduino-esp32 marks the running app valid automatically unless this returns true.
extern "C" bool verifyRollbackLater() { return true; }

namespace ota {

static esp_ota_handle_t s_h = 0;
static const esp_partition_t* s_part = nullptr;
static uint32_t s_size = 0, s_written = 0;
static uint8_t s_sha[32];
static mbedtls_sha256_context s_ctx;
static bool s_active = false;
static bool s_authorized = false;
static uint32_t s_auth_size = 0;
static uint8_t s_auth_sha[32];
// Public key only. Private signing key must NEVER be included in the device.
static const char kPublicSpki[] =
  "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEKIADU/bALRoURAxF4ElSbDZkbDRxDxl8cP6YIm0xsmWG3fallhy29ynUhh/oZAOiasc7DAucXj7FrUr8LskriA==";
static void clear_auth() { s_authorized = false; s_auth_size = 0; memset(s_auth_sha, 0, sizeof(s_auth_sha)); }
static bool decode_hex_sha(const char* text, uint8_t out[32]) {
  if (!text || strlen(text) != 64) return false;
  for (int i=0; i<32; ++i) {
    char a=text[2*i], b=text[2*i+1];
    auto nib=[](char c)->int { if(c>='0'&&c<='9') return c-'0'; if(c>='a'&&c<='f') return c-'a'+10; if(c>='A'&&c<='F') return c-'A'+10; return -1; };
    int x=nib(a), y=nib(b); if(x<0||y<0) return false;
    out[i]=(uint8_t)((x<<4)|y);
  }
  return true;
}
static int version_cmp(const char* incoming, const char* current) {
  unsigned a[3]={0}, b[3]={0}; char tailA=0,tailB=0;
  if(sscanf(incoming,"%u.%u.%u%c",&a[0],&a[1],&a[2],&tailA)!=3) return -2;
  if(sscanf(current,"%u.%u.%u%c",&b[0],&b[1],&b[2],&tailB)!=3) return -2;
  for(int i=0;i<3;i++) { if(a[i]>b[i])return 1; if(a[i]<b[i])return -1; }
  return 0;
}

bool authenticate(const uint8_t* manifest, size_t ml, const uint8_t* sig, size_t sl, char* err, size_t el) {
  clear_auth();
  if(s_active) { snprintf(err,el,"ota active"); return false; }
  if(!manifest || !sig || ml<30 || ml>2048 || sl<64 || sl>80) { snprintf(err,el,"bad metadata"); return false; }
  // Verify the EXACT bytes received, not a reconstructed JSON serialization.
  uint8_t der[128]; size_t der_len=0;
  if(mbedtls_base64_decode(der,sizeof(der),&der_len,(const unsigned char*)kPublicSpki,strlen(kPublicSpki))!=0) {
    snprintf(err,el,"bad pinned key"); return false;
  }
  mbedtls_pk_context pk; mbedtls_pk_init(&pk);
  int rc=mbedtls_pk_parse_public_key(&pk,der,der_len);
  uint8_t digest[32];
  if(rc==0) rc=mbedtls_sha256(manifest,ml,digest,0);
  if(rc==0) rc=mbedtls_pk_verify(&pk,MBEDTLS_MD_SHA256,digest,32,sig,sl);
  mbedtls_pk_free(&pk);
  if(rc!=0) { snprintf(err,el,"signature invalid"); return false; }
  char json[2049]; memcpy(json,manifest,ml); json[ml]=0;
  if(memchr(manifest,0,ml)) { snprintf(err,el,"NUL in JSON"); return false; }
  cJSON* j=cJSON_ParseWithLength(json,ml);
  if(!j) { snprintf(err,el,"manifest JSON"); return false; }
  auto str=[&](const char* k)->const char* { cJSON* v=cJSON_GetObjectItemCaseSensitive(j,k); return cJSON_IsString(v)?v->valuestring:nullptr; };
  auto eq=[&](const char* k,const char* v)->bool { const char* x=str(k); return x&&strcmp(x,v)==0; };
  cJSON* sz=cJSON_GetObjectItemCaseSensitive(j,"size");
  const char* ver=str("version");
  uint8_t sha[32];
  bool valid=eq("schema","avo-ota-manifest-v1") && eq("alg","ES256") &&
    eq("kid","AVO_OTA_RECOVERABLE_P256_V1") && eq("firmware","firmware.bin") &&
    eq("target","AVO_CHEST_WAVESHARE_ESP32S3") &&
    cJSON_IsNumber(sz) && sz->valuedouble>=1024 && sz->valuedouble<=6291456 &&
    sz->valuedouble==(double)sz->valueint && ver && version_cmp(ver,AVO_FW_VERSION)>0 &&
    decode_hex_sha(str("sha256"),sha);
  if(valid) { s_auth_size=(uint32_t)sz->valueint; memcpy(s_auth_sha,sha,32); s_authorized=true; }
  cJSON_Delete(j);
  if(!valid) { snprintf(err,el,"target/version/hash invalid"); return false; }
  return true;
}


// Compatibility marker embedded in every AVO chest image. OTA images without it
// (another product, another board) are rejected before the boot partition changes.
static const char kMarker[] = "AVOCHEST-IMG-V1:WS-AMOLED-2.06";
extern "C" __attribute__((used)) const char avo_image_marker[] = "AVOCHEST-IMG-V1:WS-AMOLED-2.06";
static size_t s_match = 0;   // streaming match progress
static bool s_found = false;

static void scan_marker(const uint8_t* d, size_t n) {
  const size_t L = sizeof(kMarker) - 1;
  for (size_t i = 0; i < n && !s_found; i++) {
    if (d[i] == (uint8_t)kMarker[s_match]) {
      if (++s_match == L) s_found = true;
    } else {
      s_match = (d[i] == (uint8_t)kMarker[0]) ? 1 : 0;
    }
  }
}

bool active() { return s_active; }

bool pending_verify() {
  esp_ota_img_states_t st;
  const esp_partition_t* run = esp_ota_get_running_partition();
  return run && esp_ota_get_state_partition(run, &st) == ESP_OK && st == ESP_OTA_IMG_PENDING_VERIFY;
}

void mark_valid_if_healthy(bool healthy) {
  if (!pending_verify()) return;
  if (healthy) {
    const esp_err_t result = esp_ota_mark_app_valid_cancel_rollback();
    if (result == ESP_OK) {
      bb::log(BbCode::OTA, 0, 2, 0, "new image validated");
      Serial.println("[AVO OTA] validated for persistent boot");
    } else {
      Serial.printf("[AVO OTA] validation error: %s\n", esp_err_to_name(result));
      bb::log(BbCode::OTA, 2, 4, (uint32_t)result, "validation failed");
    }
  } else {
    bb::log(BbCode::OTA, 2, 3, 0, "self-test failed: rollback");
    esp_ota_mark_app_invalid_rollback_and_reboot();
  }
}

bool begin(uint32_t size, const uint8_t sha[32], char* err, size_t el) {
  if (s_active) { snprintf(err, el, "ota already active"); return false; }
  if (!s_authorized || size != s_auth_size || memcmp(sha,s_auth_sha,32)!=0) {
    snprintf(err,el,"signed manifest required"); return false;
  }
  if (pending_verify()) { snprintf(err, el, "current image not validated yet"); return false; }
  s_part = esp_ota_get_next_update_partition(nullptr);
  if (!s_part) { snprintf(err, el, "no ota partition"); return false; }
  if (size < sizeof(esp_image_header_t) || size > s_part->size) { snprintf(err, el, "bad size"); return false; }
  if (esp_ota_begin(s_part, size, &s_h) != ESP_OK) { snprintf(err, el, "ota_begin failed"); return false; }
  clear_auth();  // one-use authorization token, consumed on begin
  s_size = size;
  s_written = 0;
  memcpy(s_sha, sha, 32);
  s_match = 0;
  s_found = false;
  mbedtls_sha256_init(&s_ctx);
  mbedtls_sha256_starts(&s_ctx, 0);
  s_active = true;
  bb::log(BbCode::OTA, 0, 0, size, "ota begin");
  return true;
}

bool write(uint32_t off, const uint8_t* d, size_t n, char* err, size_t el) {
  if (!s_active) { snprintf(err, el, "no ota"); return false; }
  if (off != s_written) { snprintf(err, el, "expected offset %lu", (unsigned long)s_written); return false; }  // strictly sequential
  if (s_written + n > s_size) { snprintf(err, el, "overflow"); return false; }
  if (off == 0 && n >= 1 && d[0] != ESP_IMAGE_HEADER_MAGIC) { snprintf(err, el, "not an ESP image"); abort(); return false; }
  if (esp_ota_write(s_h, d, n) != ESP_OK) { snprintf(err, el, "flash write"); abort(); return false; }
  mbedtls_sha256_update(&s_ctx, d, n);
  scan_marker(d, n);
  s_written += (uint32_t)n;
  return true;
}

bool end(char* err, size_t el) {
  if (!s_active) { snprintf(err, el, "no ota"); return false; }
  uint8_t h[32];
  mbedtls_sha256_finish(&s_ctx, h);
  mbedtls_sha256_free(&s_ctx);
  s_active = false;
  if (s_written != s_size) { esp_ota_abort(s_h); snprintf(err, el, "incomplete"); return false; }
  if (memcmp(h, s_sha, 32) != 0) { esp_ota_abort(s_h); snprintf(err, el, "sha256 mismatch"); return false; }
  if (!s_found) { esp_ota_abort(s_h); snprintf(err, el, "not an AVO chest image"); return false; }
  // esp_ota_end also validates the image structure and its appended SHA-256/checksum.
  if (esp_ota_end(s_h) != ESP_OK) { snprintf(err, el, "image validation failed"); return false; }
  if (esp_ota_set_boot_partition(s_part) != ESP_OK) { snprintf(err, el, "set boot failed"); return false; }
  return true;
}

void abort() {
  clear_auth();
  if (s_active) { esp_ota_abort(s_h); mbedtls_sha256_free(&s_ctx); }
  s_active = false;
}

}  // namespace ota
