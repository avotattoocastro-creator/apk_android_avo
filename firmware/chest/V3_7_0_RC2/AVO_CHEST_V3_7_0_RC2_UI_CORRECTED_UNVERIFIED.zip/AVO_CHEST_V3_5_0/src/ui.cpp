// AVO CHEST V3.6.1 CANDIDATE — seven solid AMOLED status bands, no LVGL.
// V3.5.0: band 4 (back) also shows ESP-NOW pairing and a ZED that does not answer.
// V3.4.4: colour constants renamed C_* (Arduino_GFX defines BLACK/RED/... as macros,
// which broke the V3.4.3 build); BLE band shows authorization / 'PULSA BOOT'.
// Arduino_GFX CO5300 QSPI, partial rectangle updates only.
#include <Arduino.h>
#include <Arduino_GFX_Library.h>
#include <esp_heap_caps.h>
#include <new>
#include <cstring>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "app_state.h"
#include "board_pins.h"
#include "services.h"
#include "sys_util.h"

using namespace avo;
extern TaskHandle_t g_task_handles[TID_COUNT];
namespace ui {
static Arduino_DataBus* bus = nullptr;
static Arduino_CO5300* gfx = nullptr;
static volatile bool request_wake = false;
static volatile bool passkey_active = false;
static bool display_on = true;
static uint8_t brightness = 180;
static void invalidate_cards();
static uint32_t old_state[7] = {UINT32_MAX,UINT32_MAX,UINT32_MAX,UINT32_MAX,UINT32_MAX,UINT32_MAX,UINT32_MAX};

static uint32_t last_touch_ms = 0;
static uint32_t touch_start_ms = 0;
static bool dev_latched = false;
static bool developer_mode = false;
static Config config_cache;  // Avoid large config on UI task stack.

// RGB565, no fonts, images, sprites, framebuffers or LVGL.
static constexpr uint16_t C_GREEN = 0x06E6;
static constexpr uint16_t C_BLUE  = 0x241F;
static constexpr uint16_t C_AMBER = 0xFDC0;
static constexpr uint16_t C_RED   = 0xF986;
static constexpr uint16_t C_BLACK = 0x0000;

void show_passkey(uint32_t, bool on) {
  // No numeric passkey can be displayed in four-band mode.
  // Pairing method must be checked in BLE service / Android app.
  passkey_active = on;
  request_wake = true;
}
void wake() { request_wake = true; }
void next_screen() { request_wake = true; } // No extra screens.
void home_screen() { request_wake = true; }

static void screen_power(bool on) {
  if (on == display_on) return;
  display_on = on;
  if (on) {
    gfx->displayOn();
    gfx->setBrightness(brightness);
    for (auto &p : old_state) p = UINT32_MAX;
    invalidate_cards();
  } else gfx->displayOff();
  appstate::update([on](AppSnapshot& a) { a.sys.display_on = on; });
}
// Small built-in 5x7 font, scaled 2x. No LVGL, fonts on SD, or framebuffer.
struct Band { uint16_t color; const char* state; };
static bool old_blink[7] = {false,false,false,false,false,false,false};
static bool shutdown_drawn = false;
// AVO_UI_SEVEN_BANDS_V361: real snapshot data; stale samples never show OK.
// RC2: seven rounded dashboard cards, designed for native 410x502 portrait AMOLED.
// Native Arduino_GFX primitives: no external font assets or heap framebuffer.
static constexpr uint16_t C_WHITE=0xFFFF;
static constexpr uint16_t C_CYAN=0x05FF;
static constexpr uint16_t C_YELLOW=0xFFE0;
static uint32_t last_dashboard_refresh=0;
// One small hash per card; avoids full-screen refresh and large framebuffers.
static uint32_t card_cache[7]={0,0,0,0,0,0,0};
static bool cards_invalid=true;
static uint32_t card_hash_byte(uint32_t h,uint8_t b){return (h^b)*16777619UL;}
static uint32_t card_hash_text(uint32_t h,const char* s){
  if(s)while(*s)h=card_hash_byte(h,(uint8_t)*s++);
  return card_hash_byte(h,0xff);
}
static void invalidate_cards(){cards_invalid=true;}

static void label(int x,int y,const char* t,int scale=1,uint16_t ink=C_BLACK,uint16_t bg=C_GREEN){
  gfx->setTextColor(ink,bg);gfx->setTextSize(scale);gfx->setCursor(x,y);gfx->print(t);
}
static void glyph(int id,int x,int y,uint16_t ink){
  // Distinct high-contrast icons, all drawn at runtime from native primitives.
  switch(id){
    case 0: // Bluetooth rune
      gfx->drawLine(x+12,y+2,x+12,y+39,ink);gfx->drawLine(x+12,y+2,x+29,y+12,ink);
      gfx->drawLine(x+29,y+12,x+5,y+31,ink);gfx->drawLine(x+5,y+11,x+29,y+31,ink);
      gfx->drawLine(x+29,y+31,x+12,y+40,ink);break;
    case 1: // vest
      gfx->drawRoundRect(x+4,y+4,29,35,5,ink);gfx->drawLine(x+10,y+4,x+16,y+13,ink);
      gfx->drawLine(x+27,y+4,x+20,y+13,ink);gfx->drawFastHLine(x+8,y+27,21,ink);break;
    case 2: // wireless
      gfx->fillCircle(x+18,y+24,5,ink);
      gfx->drawCircle(x+18,y+24,12,ink);gfx->drawCircle(x+18,y+24,18,ink);break;
    case 3: // three IMU axes
      gfx->fillCircle(x+17,y+24,5,ink);gfx->drawLine(x+17,y+24,x+17,y+4,ink);
      gfx->drawLine(x+17,y+24,x+34,y+35,ink);gfx->drawLine(x+17,y+24,x+2,y+35,ink);
      gfx->fillCircle(x+17,y+4,3,ink);gfx->fillCircle(x+34,y+35,3,ink);gfx->fillCircle(x+2,y+35,3,ink);break;
    case 4: // satellite and radio waves
      gfx->fillRect(x+5,y+8,22,15,ink);gfx->drawLine(x+14,y+23,x+28,y+37,ink);
      gfx->drawCircle(x+29,y+29,9,ink);break;
    case 5: // SD
      gfx->fillRoundRect(x+6,y+3,26,38,3,ink);
      gfx->fillRect(x+11,y+3,3,9,C_YELLOW);gfx->fillRect(x+18,y+3,3,9,C_YELLOW);
      gfx->fillRect(x+25,y+3,3,9,C_YELLOW);break;
    case 6: // battery
      gfx->drawRoundRect(x+3,y+10,29,25,3,ink);gfx->fillRect(x+32,y+17,4,11,ink);
      gfx->fillRect(x+7,y+14,20,17,ink);break;
  }
}
static void card(int i,uint16_t color,const char* title,const char* state,const char* right1,const char* right2,bool good){
  uint32_t sig=2166136261UL;
  sig=card_hash_byte(sig,(uint8_t)(color>>8));sig=card_hash_byte(sig,(uint8_t)color);
  sig=card_hash_byte(sig,(uint8_t)good);
  sig=card_hash_text(sig,title);sig=card_hash_text(sig,state);
  sig=card_hash_text(sig,right1);sig=card_hash_text(sig,right2);
  if(!cards_invalid && card_cache[i]==sig)return;
  card_cache[i]=sig;
  const int top=4+i*71; const int h=65;
  gfx->fillRoundRect(5,top,LCD_WIDTH-10,h,15,color);
  glyph(i,13,top+11,C_BLACK);
  gfx->drawFastVLine(59,top+12,40,C_BLACK);
  label(68,top+9,title,2,C_BLACK,color);
  label(69,top+38,state,1,C_BLACK,color);
  // Right telemetry is limited to 21 monospace characters at 1x.
  // Lower right field leaves the heading and status unobstructed.
  if(right1 && *right1)label(267,top+37,right1,1,C_BLACK,color);
  if(right2 && *right2)label(267,top+49,right2,1,C_BLACK,color);
  gfx->fillCircle(LCD_WIDTH-21,top+17,11,C_BLACK);
  if(good){gfx->drawLine(LCD_WIDTH-28,top+17,LCD_WIDTH-23,top+22,color);
           gfx->drawLine(LCD_WIDTH-23,top+22,LCD_WIDTH-14,top+12,color);}
  else {gfx->drawLine(LCD_WIDTH-26,top+12,LCD_WIDTH-16,top+22,color);
        gfx->drawLine(LCD_WIDTH-16,top+12,LCD_WIDTH-26,top+22,color);}
}
static void render(const AppSnapshot& s,uint32_t now){
  // Redraw once per second: real-time state, no invented readings.
  if(last_dashboard_refresh && now-last_dashboard_refresh<1000 && old_state[0]!=UINT32_MAX)return;
  old_state[0]=0;
  last_dashboard_refresh=now;
  const bool ble=s.ble.connected&&s.ble.authorized;
  const bool back=s.link.connected&&s.link.last_rx_ms&&now-s.link.last_rx_ms<2000;
  const bool sd=s.storage.mounted&&!s.storage.write_errors&&s.storage.rec!=RecStatus::REC_ERROR;
  const bool imu=s.girth.connected&&s.girth.last_batch_ms[0]&&s.girth.last_batch_ms[1]&&s.girth.last_batch_ms[2]&&
    now-s.girth.last_batch_ms[0]<3000&&now-s.girth.last_batch_ms[1]<3000&&now-s.girth.last_batch_ms[2]<3000;
  const bool gps=s.gnss.have&&now-s.gnss.rx_ms<3000&&s.gnss.s.gnss_fix_ok();
  const bool rec=s.storage.rec==RecStatus::RECORDING||s.storage.rec==RecStatus::TEMP_BUFFER;
  const int pct=s.power.pmu.batt_pct;
  char version[24];snprintf(version,sizeof(version),"V3.7.0 RC2");
  char rssi[24];if(back)snprintf(rssi,sizeof(rssi),"RSSI %d dBm",(int)s.link.now_rssi);else snprintf(rssi,sizeof(rssi),"SIN SENAL");
  char gnssdetail[24];if(gps)snprintf(gnssdetail,sizeof(gnssdetail),"SAT %u",(unsigned)s.gnss.s.num_sv);else snprintf(gnssdetail,sizeof(gnssdetail),"SIN DATOS");
  char sdinfo[24];if(rec)snprintf(sdinfo,sizeof(sdinfo),"%02lu:%02lu",(unsigned long)(s.session.metrics.active_ms/60000),(unsigned long)((s.session.metrics.active_ms/1000)%60));else snprintf(sdinfo,sizeof(sdinfo),"LISTA");
  char bat[24];if(pct>=0&&pct<=100)snprintf(bat,sizeof(bat),"%d%%",pct);else snprintf(bat,sizeof(bat),"--%%");
  if(cards_invalid)gfx->fillScreen(C_BLACK);
  card(0,ble?C_GREEN:C_RED,"BLUETOOTH",ble?"Conectado":s.ble.claim_pending?"PULSA BOOT":"Sin enlace","AVO APP",nullptr,ble);
  card(1,back&&sd?C_GREEN:C_RED,"CHALECO",back&&sd?"Sistema OK":"Revisar",version,nullptr,back&&sd);
  card(2,back?C_GREEN:C_RED,"ESPALDA",back?"Conectada":"Sin enlace",rssi,nullptr,back);
  card(3,imu?C_GREEN:C_RED,"CINCHA IMU",imu?"Conectada":"Sin datos",imu?"3 IMU OK":"SIN IMU",nullptr,imu);
  card(4,gps?C_CYAN:C_RED,"GPS / RTK",!gps?"Sin GPS":s.gnss.s.carr_soln()==2?"RTK FIX":s.gnss.s.carr_soln()==1?"RTK FLOAT":s.gnss.s.diff_soln()?"DGNSS":"GNSS",gnssdetail,nullptr,gps);
  card(5,!sd?C_RED:rec?C_YELLOW:C_GREEN,"TARJETA SD",!sd?"ERROR":rec?"Grabando...":"Disponible",sdinfo,nullptr,sd);
  card(6,pct>=0&&pct<=20?C_RED:C_GREEN,"BATERIA",s.power.pmu.vbus?"Cargando...":"En uso",bat,nullptr,pct>20);
  cards_invalid=false;
}
// Charging UI: PMIC VBUS detection; no guessed battery percentages.
// Radios remain available for OTA and data safety; see release notes.
static bool charge_screen = false;
static uint32_t charge_last_draw = 0;
// Snapshot the display state at the USB insertion edge, not during charging.
static bool usb_was_connected = false;
static bool display_before_usb = true;
static bool display_preference_during_usb = true;
static bool charging_forced_screen = false;
static void render_charging(const AppSnapshot& s, uint32_t now) {
  static int last_charge_pct = -999;
  const int current_pct = s.power.pmu.batt_pct;
  if (charge_screen && current_pct == last_charge_pct &&
      (uint32_t)(now - charge_last_draw) < 10000) return;
  last_charge_pct = current_pct;
  charge_last_draw = now;
  gfx->fillScreen(C_BLACK);
  gfx->setTextColor(0xFFFF, C_BLACK);
  gfx->setTextSize(3);
  const int pct = s.power.pmu.batt_pct;
  char value[16];
  if (pct >= 0 && pct <= 100) snprintf(value, sizeof(value), "%d%%", pct);
  else snprintf(value, sizeof(value), "--%%");
  const int cx = LCD_WIDTH / 2, cy = LCD_HEIGHT / 2 - 18;
  const int radius = (LCD_WIDTH < LCD_HEIGHT ? LCD_WIDTH : LCD_HEIGHT) / 2 - 54;
  for(int t=0;t<7;t++) gfx->drawCircle(cx,cy,radius-t,0x39E7);
  if (pct >= 0 && pct <= 100) {
    // Progress ring, green arc. Angle starts at 12 o'clock.
    const int steps = pct * 72 / 100;
    for (int i = 0; i < steps; ++i) {
      const float a = (i * 5.0f - 90.0f) * 0.01745329252f;
      const float b = ((i+1) * 5.0f - 90.0f) * 0.01745329252f;
      for(int t=0;t<7;t++) gfx->drawLine(cx + (int)((radius-t)*cosf(a)), cy + (int)((radius-t)*sinf(a)),
                    cx + (int)((radius-t)*cosf(b)), cy + (int)((radius-t)*sinf(b)), C_GREEN);
    }
  }
  gfx->setCursor(cx - (int)strlen(value)*9, cy - 18);
  gfx->print(value);
  gfx->setTextSize(3);
  const char* charging_label = pct == 100 ? "COMPLETA" : "CARGANDO...";
  gfx->setCursor(cx - (int)strlen(charging_label)*9, cy + radius + 12);
  gfx->print(charging_label);
}
static bool pair_latched = false;
static void task(void*) {
  auto* snap = static_cast<AppSnapshot*>(heap_caps_malloc(sizeof(AppSnapshot), MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT));
  if (!snap) {
    Serial.println("[AVO LITE] ERROR: no PSRAM for UI snapshot");
    vTaskDelete(nullptr);
    return;
  }
  new (snap) AppSnapshot();
  uint32_t last_update = 0;
  bool special_screen = false;
  for (;;) {
    const uint32_t now = sys::ms();
    if (request_wake) { request_wake = false; screen_power(true); }
    if (now - last_touch_ms >= 60) {
      last_touch_ms = now;
      bool pressed = false;
      int16_t x=0,y=0;
      if (board::touch_read(&pressed,&x,&y) && pressed) {
        if (!touch_start_ms) { touch_start_ms = now; pair_latched = false; }
        // V3.5.0: touch held 5 s anywhere = look for a back for 60 s (harmless if the own back is
        // alive: it simply answers again). Developer mode stays at 20 s.
        if (!pair_latched && now - touch_start_ms >= 5000) {
          pair_latched = true;
          uartlink::pair_start(60000);
          Serial.println("[AVO LITE] ESP-NOW pairing requested from the touch screen (60 s)");
        }
        if (!dev_latched && now - touch_start_ms >= 20000) {
          dev_latched = true;
          developer_mode = !developer_mode;
          appstate::update([](AppSnapshot& a) { a.sys.dev_mode = developer_mode; });
          Serial.printf("[AVO LITE] developer flag=%d (configuration via Android)\n", developer_mode);
        }
      } else { touch_start_ms = 0; dev_latched = false; }
    }
    if (now - last_update >= 250) {
      last_update = now;
      appstate::get(snap);
      cfgstore::get(&config_cache);
      uint8_t wanted = config_cache.brightness;
      if (config_cache.dim_on_low_batt && snap->power.level == PowerLevel::LOWBAT && wanted > 60) wanted = 60;
      const bool charging_usb = snap->power.pmu.online && snap->power.pmu.vbus;
      if (charging_usb && wanted > 25) wanted = 25;
      if (wanted != brightness) { brightness = wanted; if (display_on) gfx->setBrightness(brightness); }
      // USB insertion: remember whether the user was in normal or power-save
      // display mode. Wake for the charging screen without overwriting that
      // preference. Avoid treating the forced wake as a new user preference.
      if (charging_usb && !usb_was_connected) {
        display_before_usb = snap->sys.display_on;
        display_preference_during_usb = display_before_usb;
        charging_forced_screen = !display_before_usb;
        usb_was_connected = true;
        charge_last_draw = 0;
        screen_power(true);
        Serial.printf("[AVO UI] USB connected; previous display=%s\n",
                      display_before_usb ? "ON" : "SLEEP");
      } else if (!charging_usb && usb_was_connected) {
        usb_was_connected = false;
        // Restore only the display preference. Do not touch BLE, SD or recording.
        const bool restore_on = display_preference_during_usb;
        charging_forced_screen = false;
        charge_screen = false;
        screen_power(restore_on);
        Serial.printf("[AVO UI] USB removed; restored display=%s\n",
                      restore_on ? "ON" : "SLEEP");
      }
      if (!charging_usb) {
        if (!snap->sys.display_on && display_on && !snap->power.shutdown_requested && !passkey_active) screen_power(false);
        if (snap->sys.display_on && !display_on) screen_power(true);
      } else if (!display_on) {
        screen_power(true);
      }
      if (display_on) {
        const bool ota_notice = snap->ble.ota_display_status>=2 && snap->ble.ota_display_since_ms && (uint32_t)(now-snap->ble.ota_display_since_ms)<6000;
        const bool special_now = snap->ble.ota_active || ota_notice || snap->power.shutdown_requested;
        if(special_screen && !special_now) {
          gfx->fillScreen(C_BLACK);
          for(auto &v:old_state)v=UINT32_MAX;
          invalidate_cards();
          shutdown_drawn = false; // reset after a failed/cancelled shutdown
          charge_screen = false;
        }
        special_screen=special_now;
        // AVO_UI_OTA_PROGRESS_V361: OTA overrides USB display; real confirmed bytes.
        if (snap->ble.ota_active) {
          static uint32_t last_ota_draw=0;
          if(now-last_ota_draw>=200 || !last_ota_draw){
            last_ota_draw=now;
            gfx->fillScreen(C_BLACK);
            gfx->setTextColor(0xFFFF,C_BLACK);
            gfx->setTextSize(2);
            gfx->setCursor(12,LCD_HEIGHT/2-100);
            gfx->print("ACTUALIZANDO...");
            uint32_t pct=snap->ble.ota_total ?
              (uint32_t)((uint64_t)snap->ble.ota_bytes*99/snap->ble.ota_total):0;
            if(pct>99)pct=99;
            const int x=24,y=LCD_HEIGHT/2-12,w=LCD_WIDTH-48;
            gfx->fillRect(x,y,w,22,0x3186);
            gfx->fillRect(x,y,w*pct/100,22,0x07F0);
            gfx->setTextSize(5);
            char ota_percent[8];
            snprintf(ota_percent,sizeof(ota_percent),"%lu%%",(unsigned long)pct);
            gfx->setCursor((LCD_WIDTH-(int)strlen(ota_percent)*30)/2,y+42);
            gfx->print(ota_percent);
          }
          charge_screen=false;
          for(auto &v:old_state)v=UINT32_MAX;
          invalidate_cards();
        } else if (ota_notice && !snap->power.shutdown_requested) {
          // "VERIFICADA" means OTA image validated, not that new firmware has booted.
          // Redraw the notification when entering from the OTA progress screen.
          static uint32_t notice_last_draw = 0;
          static uint8_t last_notice_status = 0;
          if (!notice_last_draw || last_notice_status != snap->ble.ota_display_status ||
              (uint32_t)(now-notice_last_draw)>=1000) {
            last_notice_status = snap->ble.ota_display_status;
            notice_last_draw=now;
            gfx->fillScreen(C_BLACK);
            gfx->setTextColor(snap->ble.ota_display_status==2?C_GREEN:C_RED,C_BLACK);
            gfx->setTextSize(2);
            gfx->setCursor(12,LCD_HEIGHT/2-25);
            gfx->print(snap->ble.ota_display_status==2?"OTA VERIFICADA":"ERROR OTA");
            gfx->setCursor(12,LCD_HEIGHT/2+10);
            gfx->print(snap->ble.ota_display_status==2?"ESPERA REINICIO":"REVISA APP");
          }
          for(auto &v:old_state)v=UINT32_MAX;
          invalidate_cards();
        } else if (snap->power.shutdown_requested) {
          // AVO_UI_SAFE_SHUTDOWN_V361: one redraw per shutdown edge.
          if (!shutdown_drawn) {
          shutdown_drawn=true;
          gfx->fillScreen(C_BLACK);
          gfx->setTextColor(0xFFFF,C_BLACK);
          gfx->setTextSize(3);
          gfx->setCursor(20,LCD_HEIGHT/2-45);
          gfx->print("APAGANDO...");
          gfx->setTextSize(2);
          gfx->setCursor(20,LCD_HEIGHT/2+15);
          gfx->print("Guardando datos");
          }
        } else {
          if (charge_screen) { for (auto &p : old_state) p = UINT32_MAX; gfx->fillScreen(C_BLACK); invalidate_cards(); }
          charge_screen = false;
          render(*snap,now);
        }
      }
    }
    vTaskDelay(pdMS_TO_TICKS(25));
  }
}
bool init() {
  bus = new Arduino_ESP32QSPI(PIN_LCD_CS,PIN_LCD_SCLK,PIN_LCD_SDIO0,PIN_LCD_SDIO1,PIN_LCD_SDIO2,PIN_LCD_SDIO3);
  gfx = new Arduino_CO5300(bus,PIN_LCD_RESET,0,LCD_WIDTH,LCD_HEIGHT,LCD_COL_OFFSET,0,0,0);
  if (!gfx || !gfx->begin()) return false;
  // AVO_UI_ROTATE_180_V361: RC2 portrait orientation confirmed by user; keep rotation 0.
  gfx->setRotation(0);  // RC2 portrait; verify panel physical orientation on device
  gfx->fillScreen(C_BLACK);
  cfgstore::get(&config_cache);
  brightness = config_cache.brightness;
  gfx->setBrightness(brightness);
  board::touch_init();
  BaseType_t ok = xTaskCreatePinnedToCore(task,"ui_lite",4096,nullptr,2,&g_task_handles[TID_UI],0);
  Serial.printf("[AVO MEM] UI LITE task=%s internal=%u largest=%u psram=%u\n",ok==pdPASS?"OK":"FAIL",
    (unsigned)heap_caps_get_free_size(MALLOC_CAP_INTERNAL | MALLOC_CAP_8BIT),
    (unsigned)heap_caps_get_largest_free_block(MALLOC_CAP_INTERNAL | MALLOC_CAP_8BIT),
    (unsigned)ESP.getFreePsram());
  return ok == pdPASS;
}
} // namespace ui
