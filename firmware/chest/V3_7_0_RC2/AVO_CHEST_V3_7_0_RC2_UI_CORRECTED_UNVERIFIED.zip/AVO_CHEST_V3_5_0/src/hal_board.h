// Board peripherals on the shared I2C bus: AXP2101 PMIC, PCF85063 RTC, FT3168 touch.
// All bus access goes through one mutex (the bus is shared by several tasks).
#pragma once
#include <stdint.h>

namespace board {

bool i2c_init();
bool i2c_lock(uint32_t timeout_ms = 50);
void i2c_unlock();
uint32_t i2c_errors();

// ---------------- PMIC (AXP2101 through XPowersLib)
struct PmuStatus {
  bool online = false;
  bool batt_present = false;
  bool vbus = false;
  bool charging = false;
  int batt_pct = -1;        // -1 unknown
  uint16_t batt_mv = 0;
  uint16_t vbus_mv = 0;
  uint16_t sys_mv = 0;
  float die_temp_c = 0;
  uint8_t charger_state = 0;
  bool pkey_short = false;  // AXP short-press IRQ seen since last read
  bool pkey_long = false;   // AXP long-press IRQ seen since last read
};
bool pmu_init();
bool pmu_read(PmuStatus* s);
// Hardware forced power-off on a long PWR press: 10 s (maximum), so the firmware's
// own 3 s "controlled shutdown" always happens first.
bool pmu_configure_power_key();
// Final step of a controlled shutdown: AXP2101 cuts all rails.
void pmu_power_off();

// ---------------- RTC (PCF85063)
bool rtc_read_unix(uint64_t* unix_s, bool* valid);   // valid=false if oscillator stopped
bool rtc_write_unix(uint64_t unix_s);

// ---------------- Touch (FT3168)
bool touch_init();
// Returns true when the read succeeded; *touched tells whether a finger is down.
bool touch_read(bool* touched, int16_t* x, int16_t* y);
uint32_t touch_errors();

}  // namespace board
