#include "sys_util.h"
#include <Arduino.h>
#include <esp_timer.h>
#include <esp_mac.h>
#include <esp_system.h>
#include <nvs.h>
#include <nvs_flash.h>
#include <stdio.h>
#include "freertos/FreeRTOS.h"
#include "freertos/semphr.h"

namespace sys {

static portMUX_TYPE s_mux = portMUX_INITIALIZER_UNLOCKED;
static uint64_t s_base_unix = 0, s_base_us = 0;
static TimeSource s_src = TimeSource::NONE;
static char s_devhex[13] = "000000000000";
static uint16_t s_dev16 = 0;
static uint32_t s_boot = 0;
static uint16_t s_sess = 0;
static nvs_handle_t s_nvs = 0;
static bool s_nvs_ok = false;

uint32_t ms() { return (uint32_t)(esp_timer_get_time() / 1000); }
uint64_t us() { return (uint64_t)esp_timer_get_time(); }

void wall_set(uint64_t unix_ms, TimeSource src) {
  portENTER_CRITICAL(&s_mux);
  // A lower-quality source never overrides a better one already set.
  if ((uint8_t)src >= (uint8_t)s_src) {
    s_base_unix = unix_ms;
    s_base_us = us();
    s_src = src;
  }
  portEXIT_CRITICAL(&s_mux);
}
bool wall_valid() { return s_src != TimeSource::NONE; }
uint64_t wall_ms() {
  portENTER_CRITICAL(&s_mux);
  uint64_t b = s_base_unix, bu = s_base_us;
  TimeSource s = s_src;
  portEXIT_CRITICAL(&s_mux);
  if (s == TimeSource::NONE) return 0;
  return b + (us() - bu) / 1000;
}
TimeSource wall_source() { return s_src; }
const char* time_source_str(TimeSource s) {
  switch (s) {
    case TimeSource::RTC: return "RTC";
    case TimeSource::PHONE: return "PHONE";
    case TimeSource::GNSS: return "GNSS";
    default: return "NONE";
  }
}

static bool nvs_open_once() {
  if (s_nvs_ok) return true;
  esp_err_t e = nvs_flash_init();
  if (e == ESP_ERR_NVS_NO_FREE_PAGES || e == ESP_ERR_NVS_NEW_VERSION_FOUND) {
    // Partition layout changed or full: erasing NVS loses config + counters,
    // which then fall back to defaults (reported as CONFIG_CORRUPT on boot).
    nvs_flash_erase();
    e = nvs_flash_init();
  }
  if (e != ESP_OK) return false;
  s_nvs_ok = nvs_open("avo_sys", NVS_READWRITE, &s_nvs) == ESP_OK;
  return s_nvs_ok;
}

bool nvs_get_blob(const char* key, void* buf, size_t* len) {
  if (!nvs_open_once()) return false;
  return ::nvs_get_blob(s_nvs, key, buf, len) == ESP_OK;
}
bool nvs_set_blob(const char* key, const void* buf, size_t len) {
  if (!nvs_open_once()) return false;
  if (::nvs_set_blob(s_nvs, key, buf, len) != ESP_OK) return false;
  return nvs_commit(s_nvs) == ESP_OK;
}
bool nvs_get_u32(const char* key, uint32_t* v) {
  if (!nvs_open_once()) return false;
  return ::nvs_get_u32(s_nvs, key, v) == ESP_OK;
}
bool nvs_set_u32(const char* key, uint32_t v) {
  if (!nvs_open_once()) return false;
  if (::nvs_set_u32(s_nvs, key, v) != ESP_OK) return false;
  return nvs_commit(s_nvs) == ESP_OK;
}
bool nvs_erase(const char* key) {
  if (!nvs_open_once()) return false;
  esp_err_t e = nvs_erase_key(s_nvs, key);
  if (e != ESP_OK && e != ESP_ERR_NVS_NOT_FOUND) return false;
  return nvs_commit(s_nvs) == ESP_OK;
}

void identity_init() {
  uint8_t mac[6] = {0};
  esp_read_mac(mac, ESP_MAC_WIFI_STA);
  snprintf(s_devhex, sizeof(s_devhex), "%02X%02X%02X%02X%02X%02X", mac[0], mac[1], mac[2], mac[3], mac[4], mac[5]);
  s_dev16 = (uint16_t)((mac[4] << 8) | mac[5]);
  uint32_t b = 0;
  nvs_get_u32("boot", &b);
  s_boot = b + 1;
  nvs_set_u32("boot", s_boot);
}

const char* device_id_hex() { return s_devhex; }
uint16_t device_id16() { return s_dev16; }
uint32_t boot_count() { return s_boot; }
uint16_t next_session_counter() { return ++s_sess; }

int reset_reason_code() { return (int)esp_reset_reason(); }
const char* reset_reason_str() {
  switch (esp_reset_reason()) {
    case ESP_RST_POWERON: return "POWERON";
    case ESP_RST_EXT: return "EXT";
    case ESP_RST_SW: return "SW";
    case ESP_RST_PANIC: return "PANIC";
    case ESP_RST_INT_WDT: return "INT_WDT";
    case ESP_RST_TASK_WDT: return "TASK_WDT";
    case ESP_RST_WDT: return "WDT";
    case ESP_RST_DEEPSLEEP: return "DEEPSLEEP";
    case ESP_RST_BROWNOUT: return "BROWNOUT";
    case ESP_RST_SDIO: return "SDIO";
    default: return "UNKNOWN";
  }
}

}  // namespace sys
