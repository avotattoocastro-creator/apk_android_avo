#include "hal_board.h"
#include "board_pins.h"
#include <Arduino.h>
#include <Wire.h>
#include <time.h>
#include <atomic>
#define XPOWERS_CHIP_AXP2101
#include <XPowersLib.h>
#include "freertos/FreeRTOS.h"
#include "freertos/semphr.h"

namespace board {

static SemaphoreHandle_t s_i2c = nullptr;
static std::atomic<uint32_t> s_i2c_err{0};
static std::atomic<uint32_t> s_touch_err{0};
static XPowersPMU s_pmu;
static bool s_pmu_ok = false;

bool i2c_init() {
  if (!s_i2c) s_i2c = xSemaphoreCreateRecursiveMutex();
  return Wire.begin(PIN_I2C_SDA, PIN_I2C_SCL, I2C_FREQ_HZ);
}
bool i2c_lock(uint32_t t) { return s_i2c && xSemaphoreTakeRecursive(s_i2c, pdMS_TO_TICKS(t)) == pdTRUE; }
void i2c_unlock() { if (s_i2c) xSemaphoreGiveRecursive(s_i2c); }
uint32_t i2c_errors() { return s_i2c_err; }

// Raw register access (caller holds the bus lock).
static int reg_read(uint8_t dev, uint8_t reg, uint8_t* data, uint8_t len) {
  Wire.beginTransmission(dev);
  Wire.write(reg);
  if (Wire.endTransmission(false) != 0) { s_i2c_err++; return -1; }
  if (Wire.requestFrom((uint16_t)dev, (size_t)len, true) != len) { s_i2c_err++; return -1; }
  for (uint8_t i = 0; i < len; i++) data[i] = (uint8_t)Wire.read();
  return 0;
}
static int reg_write(uint8_t dev, uint8_t reg, uint8_t* data, uint8_t len) {
  Wire.beginTransmission(dev);
  Wire.write(reg);
  Wire.write(data, len);
  if (Wire.endTransmission(true) != 0) { s_i2c_err++; return -1; }
  return 0;
}

// ------------------------------------------------------------------ PMU
bool pmu_init() {
  if (!i2c_lock(200)) return false;
  s_pmu_ok = s_pmu.begin(I2C_ADDR_AXP2101, reg_read, reg_write);
  if (s_pmu_ok) {
    // Same charger settings as the Waveshare factory firmware (system_status.cpp).
    // Power rails are NOT touched: the OTP defaults power the AMOLED, SD, etc.
    s_pmu.disableTSPinMeasure();
    s_pmu.setPrechargeCurr(XPOWERS_AXP2101_PRECHARGE_50MA);
    s_pmu.setChargerConstantCurr(XPOWERS_AXP2101_CHG_CUR_400MA);
    s_pmu.setChargerTerminationCurr(XPOWERS_AXP2101_CHG_ITERM_25MA);
    s_pmu.setChargeTargetVoltage(XPOWERS_AXP2101_CHG_VOL_4V2);
    s_pmu.enableBattDetection();
    s_pmu.enableVbusVoltageMeasure();
    s_pmu.enableBattVoltageMeasure();
    s_pmu.enableSystemVoltageMeasure();
    s_pmu.enableTemperatureMeasure();
    s_pmu.disableIRQ(XPOWERS_AXP2101_ALL_IRQ);
    s_pmu.clearIrqStatus();
    s_pmu.enableIRQ(XPOWERS_AXP2101_PKEY_SHORT_IRQ | XPOWERS_AXP2101_PKEY_LONG_IRQ);
  }
  i2c_unlock();
  return s_pmu_ok;
}

bool pmu_configure_power_key() {
  if (!s_pmu_ok || !i2c_lock(200)) return false;
  bool ok = s_pmu.setPowerKeyPressOffTime(XPOWERS_POWEROFF_10S);
  i2c_unlock();
  return ok;
}

bool pmu_read(PmuStatus* s) {
  *s = PmuStatus();
  if (!s_pmu_ok || !i2c_lock(100)) return false;
  s->online = true;
  s->batt_present = s_pmu.isBatteryConnect();
  s->vbus = s_pmu.isVbusIn();
  s->charging = s_pmu.isCharging();
  s->batt_mv = s_pmu.getBattVoltage();
  s->batt_pct = s->batt_present ? s_pmu.getBatteryPercent() : -1;
  s->vbus_mv = s->vbus ? s_pmu.getVbusVoltage() : 0;
  s->sys_mv = s_pmu.getSystemVoltage();
  s->die_temp_c = s_pmu.getTemperature();
  s->charger_state = (uint8_t)s_pmu.getChargerStatus();
  s_pmu.getIrqStatus();
  s->pkey_short = s_pmu.isPekeyShortPressIrq();
  s->pkey_long = s_pmu.isPekeyLongPressIrq();
  s_pmu.clearIrqStatus();
  i2c_unlock();
  if (s->batt_pct > 100) s->batt_pct = 100;
  return true;
}

void pmu_power_off() {
  if (!s_pmu_ok) return;
  if (i2c_lock(500)) {
    s_pmu.shutdown();
    i2c_unlock();
  }
}

// ------------------------------------------------------------------ RTC (PCF85063)
static uint8_t bcd2bin(uint8_t v) { return (uint8_t)((v >> 4) * 10 + (v & 0x0F)); }
static uint8_t bin2bcd(uint8_t v) { return (uint8_t)(((v / 10) << 4) | (v % 10)); }

static int64_t days_from_civil(int y, unsigned m, unsigned d) {
  y -= m <= 2;
  const int era = (y >= 0 ? y : y - 399) / 400;
  const unsigned yoe = (unsigned)(y - era * 400);
  const unsigned doy = (153 * (m + (m > 2 ? -3 : 9)) + 2) / 5 + d - 1;
  const unsigned doe = yoe * 365 + yoe / 4 - yoe / 100 + doy;
  return (int64_t)era * 146097 + (int64_t)doe - 719468;
}

bool rtc_read_unix(uint64_t* unix_s, bool* valid) {
  uint8_t r[7];
  if (!i2c_lock(100)) return false;
  int rc = reg_read(I2C_ADDR_PCF85063, 0x04, r, 7);
  i2c_unlock();
  if (rc != 0) return false;
  *valid = !(r[0] & 0x80);  // OS flag: oscillator stopped => time not trustworthy
  int sec = bcd2bin(r[0] & 0x7F), min = bcd2bin(r[1] & 0x7F), hour = bcd2bin(r[2] & 0x3F);
  int day = bcd2bin(r[3] & 0x3F), mon = bcd2bin(r[5] & 0x1F), year = 2000 + bcd2bin(r[6]);
  if (mon < 1 || mon > 12 || day < 1 || day > 31 || hour > 23 || min > 59 || sec > 59 || year < 2024) *valid = false;
  int64_t days = days_from_civil(year, (unsigned)mon, (unsigned)day);
  *unix_s = (uint64_t)(days * 86400 + hour * 3600 + min * 60 + sec);
  return true;
}

bool rtc_write_unix(uint64_t unix_s) {
  time_t t = (time_t)unix_s;
  struct tm tmv;
  gmtime_r(&t, &tmv);
  uint8_t r[7];
  r[0] = bin2bcd((uint8_t)tmv.tm_sec);  // clears OS flag
  r[1] = bin2bcd((uint8_t)tmv.tm_min);
  r[2] = bin2bcd((uint8_t)tmv.tm_hour);
  r[3] = bin2bcd((uint8_t)tmv.tm_mday);
  r[4] = (uint8_t)tmv.tm_wday;
  r[5] = bin2bcd((uint8_t)(tmv.tm_mon + 1));
  r[6] = bin2bcd((uint8_t)(tmv.tm_year % 100));
  if (!i2c_lock(100)) return false;
  int rc = reg_write(I2C_ADDR_PCF85063, 0x04, r, 7);
  i2c_unlock();
  return rc == 0;
}

// ------------------------------------------------------------------ Touch (FT3168)
bool touch_init() {
  pinMode(PIN_TP_RESET, OUTPUT);
  digitalWrite(PIN_TP_RESET, LOW);
  delay(10);
  digitalWrite(PIN_TP_RESET, HIGH);
  delay(150);
  pinMode(PIN_TP_INT, INPUT_PULLUP);
  if (!i2c_lock(200)) return false;
  uint8_t id = 0;
  bool ok = reg_read(I2C_ADDR_FT3168, 0xA0, &id, 1) == 0;  // device id register
  if (ok) {
    uint8_t mode = 0x01;  // 0xA5 power mode = monitor (same value as Waveshare's FT3x68 init sequence)
    reg_write(I2C_ADDR_FT3168, 0xA5, &mode, 1);
  }
  i2c_unlock();
  return ok;
}

bool touch_read(bool* touched, int16_t* x, int16_t* y) {
  uint8_t b[5];
  if (!i2c_lock(20)) return false;
  int rc = reg_read(I2C_ADDR_FT3168, 0x02, b, 5);  // finger count, X1H, X1L, Y1H, Y1L
  i2c_unlock();
  if (rc != 0) { s_touch_err++; return false; }
  uint8_t n = b[0] & 0x0F;
  *touched = n >= 1 && n <= 2;
  *x = (int16_t)(((b[1] & 0x0F) << 8) | b[2]);
  *y = (int16_t)(((b[3] & 0x0F) << 8) | b[4]);
  return true;
}

uint32_t touch_errors() { return s_touch_err; }

}  // namespace board
