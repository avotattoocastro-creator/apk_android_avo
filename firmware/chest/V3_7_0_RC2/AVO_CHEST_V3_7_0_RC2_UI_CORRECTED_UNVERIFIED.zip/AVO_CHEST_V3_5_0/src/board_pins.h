// Waveshare ESP32-S3-Touch-AMOLED-2.06 — pin map.
// Every value below was checked against:
//   [S] hardware/schematic/ESP32-S3-Touch-AMOLED-2.06-Schematic-V1.0.pdf (GPIO table + KEYS + SD-CARD + test pads)
//   [B] factory_firmware/components/waveshare__esp32_s3_touch_amoled_2_06 (official BSP)
//   [A] examples/arduino/libraries/board_config/pin_config.h (official Arduino examples)
// Repository: github.com/waveshareteam/ESP32-S3-Touch-AMOLED-2.06 @ f855653f672d
#pragma once

// AMOLED CO5300, QSPI                                  [S][B][A]
#define PIN_LCD_SDIO0 4
#define PIN_LCD_SDIO1 5
#define PIN_LCD_SDIO2 6
#define PIN_LCD_SDIO3 7
#define PIN_LCD_SCLK 11
#define PIN_LCD_CS 12
#define PIN_LCD_RESET 8
#define PIN_LCD_TE 13            // [S] LCD_TE (not used by this firmware)
#define LCD_WIDTH 410
#define LCD_HEIGHT 502
#define LCD_COL_OFFSET 22        // [A] Arduino_CO5300(..., col_offset1 = 22)

// Shared I2C bus: FT3168 touch (0x38), AXP2101 (0x34), PCF85063 RTC (0x51),
// QMI8658 IMU, ES8311 codec.                            [S][B][A]
// NOTE: the back-of-PCB pads labelled "IO14/IO15" (TP5/TP7) ARE THIS BUS
// (ESP32_SCL/ESP32_SDA). They must not be used as GPIO outputs (e.g. Pololu ON
// or PPS): doing so breaks touch, PMIC and RTC access.
#define PIN_I2C_SDA 15
#define PIN_I2C_SCL 14
#define I2C_FREQ_HZ 400000
#define I2C_ADDR_FT3168 0x38
#define I2C_ADDR_AXP2101 0x34
#define I2C_ADDR_PCF85063 0x51

// Touch                                                 [S][B][A]
#define PIN_TP_INT 38
#define PIN_TP_RESET 9

// MicroSD in SDMMC 1-bit mode (as the official BSP)     [S][B][A]
// D3/CS (GPIO17) has a 10k pull-up and is left untouched. No card-detect line.
#define PIN_SD_CLK 2
#define PIN_SD_CMD 1
#define PIN_SD_D0 3

// Buttons                                               [S]
#define PIN_BOOT_BTN 0           // active low, external 10k pull-up
#define PIN_PWR_SENSE 10         // SYS_OUT: PWRON -> BSS138 inverter; HIGH while PWR is pressed
                                 // [B] ButtonTest.cpp uses GPIO10, input without pull-up

// Link to the back module (Heltec) — UART0 pins on test pads  [S]
// TP13 = U0TXD (GPIO43), TP6 = U0RXD (GPIO44), TP4 = GND.
// The firmware drives them with the UART1 peripheral through the GPIO matrix so
// that IDF/ROM console output on UART0 never mixes into the protocol stream.
// The ROM bootloader still prints its banner on GPIO43 at 115200 baud during
// reset (hardware behaviour, not configurable without burning eFuses); the
// back's decoder discards it (no valid AVO frame).
#define PIN_LINK_TX 43
#define PIN_LINK_RX 44

// Pins intentionally NOT used: 16,40,41,42,45 (I2S audio), 46 (PA_CTRL, strapping),
// 18 (motor), 21 (QMI INT1), 39 (RTC INT), 19/20 (USB).
