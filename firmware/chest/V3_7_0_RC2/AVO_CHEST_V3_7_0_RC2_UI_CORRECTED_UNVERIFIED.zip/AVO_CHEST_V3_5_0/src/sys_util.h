// System utilities: monotonic clocks, wall-clock model, identity, NVS counters.
#pragma once
#include <stdint.h>
#include <stddef.h>

namespace sys {

uint32_t ms();         // monotonic ms since boot (wraps after 49 days)
uint64_t us();         // monotonic µs since boot

// Wall-clock model: unix ms = base_unix + (us() - base_us)/1000.
enum class TimeSource : uint8_t { NONE = 0, RTC = 1, PHONE = 2, GNSS = 3 };
void wall_set(uint64_t unix_ms, TimeSource src);
bool wall_valid();
uint64_t wall_ms();          // 0 when unknown
TimeSource wall_source();
const char* time_source_str(TimeSource s);

// Identity
void identity_init();        // reads MAC
const char* device_id_hex(); // 12 hex chars of the base MAC
uint16_t device_id16();      // short id used in session ids
uint32_t boot_count();       // incremented once per boot (NVS)
uint16_t next_session_counter();  // per boot, starts at 1
const char* reset_reason_str();
int reset_reason_code();

// Persistent small values (NVS namespace "avo_sys")
bool nvs_get_blob(const char* key, void* buf, size_t* len);
bool nvs_set_blob(const char* key, const void* buf, size_t len);
bool nvs_get_u32(const char* key, uint32_t* v);
bool nvs_set_u32(const char* key, uint32_t v);
bool nvs_erase(const char* key);

}  // namespace sys
