#pragma once
void app_setup();
void app_loop();
extern bool g_safe_mode;
