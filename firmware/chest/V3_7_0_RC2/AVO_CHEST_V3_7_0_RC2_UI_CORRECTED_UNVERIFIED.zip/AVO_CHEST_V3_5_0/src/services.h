// Inter-task interfaces of the chest firmware.
#pragma once
#include <stdint.h>
#include <stddef.h>
#include "avo_core.h"
#include "freertos/FreeRTOS.h"
#include "freertos/message_buffer.h"
#include "freertos/stream_buffer.h"

// Large FreeRTOS buffers live in PSRAM (internal RAM is reserved for stacks,
// DMA and the BLE controller).
MessageBufferHandle_t psram_message_buffer(size_t bytes);
StreamBufferHandle_t psram_stream_buffer(size_t bytes);

// ------------------------------------------------------------ record sink (RAW first)
namespace sink {
enum Prio : uint8_t { CRITICAL = 0, NORMAL = 1, BULK = 2 };
bool init(size_t bytes);  // PSRAM ring
// Thread-safe. LOW records are shed above 75 % fill, NORMAL above 92 %,
// CRITICAL only when physically full. Every rejected record is counted.
bool push(avo::RecType type, uint8_t flags, const uint8_t* data, size_t len, Prio p, uint64_t chest_us = 0);
// Storage task side
bool peek(avo::RecView* v);
void pop();
uint32_t fill_permille();
uint32_t peak_permille();
uint32_t dropped_total();
uint32_t dropped_low();
uint32_t dropped_critical();
uint32_t take_dropped_since_last();   // for LOSS records
size_t capacity();
void set_writer_task(void* task_handle);
}  // namespace sink

// ------------------------------------------------------------ blackbox
namespace bb {
bool init();   // flash partition "blackbox" + writer task
// Non-blocking; also mirrored into the RAW stream as CHEST_EVENT.
void log(avo::BbCode code, uint8_t severity, uint32_t a0 = 0, uint32_t a1 = 0, const char* text = nullptr);
typedef void (*Visitor)(const avo::BbRecord& r, void* ctx);
int read_recent(int n, Visitor v, void* ctx);
uint32_t dropped();
}  // namespace bb

// ------------------------------------------------------------ configuration
namespace cfgstore {
// Loads A/B copies from NVS; returns false if defaults had to be used.
bool init(bool* was_corrupt);
void get(avo::Config* out);
// Validates, stores (A/B) and publishes. Returns number of corrected fields or -1 on I/O error.
int set(const avo::Config& c);
uint32_t generation();
uint32_t crc();
}  // namespace cfgstore

// ------------------------------------------------------------ UART link to the back
namespace uartlink {
bool init(uint32_t baud);
// hi = high-priority lane (commands, ACK). Returns false if the lane is full.
bool send(avo::FrameType t, const uint8_t* payload, size_t len, bool hi, uint8_t flags = 0);
bool send_command(avo::BackCmd cmd, const uint8_t* args, uint8_t arg_len);
// V3.5.0 ESP-NOW: opens pairing with a back for window_ms (the back answers if it is
// unpaired, in PRG pairing mode, or orphaned for >= 60 s). forget = drop the paired back.
bool pair_start(uint32_t window_ms);
bool pair_forget();
}  // namespace uartlink

// ------------------------------------------------------------ RTCM router
namespace rtcm {
bool init(size_t buf_bytes);
// Called from the BLE stack. Bytes are copied unmodified. Returns accepted bytes.
size_t push(const uint8_t* d, size_t n);
size_t free_space();
// UART TX task: takes up to max bytes for one RTCM_DATA frame.
size_t take(uint8_t* out, size_t max, uint32_t* stream_offset);
void on_sent(size_t n);
}  // namespace rtcm

// ------------------------------------------------------------ controller
enum class CmdSource : uint8_t { BUTTON = 0, APP = 1, DEV = 2, POWER = 3, SYSTEM = 4 };
enum class CtlType : uint8_t {
  GNSS = 1, IMU_BATCH, SESSION_CMD, CONFIG_CHANGED, STORAGE_STARTED, STORAGE_FAILED, TIME_SET, SHUTDOWN, MARKER,
  RESUME_SESSION,
};
struct CtlMsg {
  CtlType type;
  CmdSource src;
  uint8_t arg8;
  uint32_t arg32;
  uint32_t rx_ms;
  uint64_t arg64;
  avo::GnssSample gnss;
};
namespace ctl {
bool init();
bool post(const CtlMsg& m, uint32_t timeout_ms = 0);
bool session_cmd(avo::SessionCmd c, CmdSource src);
}  // namespace ctl

// ------------------------------------------------------------ storage
namespace storage {
struct StartParams {
  char session_id[24];
  avo::RawFileMeta meta;
  bool resumed = false;
  uint16_t resume_segment = 0;
  uint32_t resume_block_seq = 0;
  uint32_t prior_active_ms = 0;
};
struct RecoveryInfo {
  bool found = false;          // an OPEN session existed at boot
  bool resumable = false;      // within the resume window
  char session_id[24] = {0};
  uint16_t segments = 0;
  uint32_t last_block_seq = 0;
  uint32_t active_ms = 0;
  uint8_t start_reason = 0;
  uint8_t manual = 0;
  uint32_t truncated_bytes = 0;
};
bool init();                         // mounts the card, scans for interrupted sessions
bool recovery_info(RecoveryInfo* out);  // valid after init
// Asynchronous requests (executed by the storage task, in order).
bool start_session(const StartParams& p);
bool stop_session(const avo::SessionMetrics& m, bool clean);
bool close_recovered(const char* session_id);  // marks an interrupted session as recovered/closed
bool flush_now();
bool shutdown(uint32_t timeout_ms);  // final flush + close, blocks until done or timeout
bool session_active();

// File services used by BLE (responses are delivered through the callback).
enum class FileOp : uint8_t { LIST = 1, READ, SHA256, MARK_UPLOADED, DELETE_PREPARE, DELETE_COMMIT };
struct FileReq {
  FileOp op;
  uint16_t msg_id;
  char session_id[24];
  uint16_t segment;
  uint32_t offset;
  uint32_t length;
  uint16_t page;
  uint32_t token;
  uint8_t force;
  uint8_t sha256[32];
};
typedef void (*FileRespCb)(const FileReq& req, uint8_t status, const uint8_t* data, size_t len, bool last);
void set_file_callback(FileRespCb cb);
bool file_request(const FileReq& r);
}  // namespace storage

// ------------------------------------------------------------ BLE
namespace ble {
bool init(const char* name);
// V3.4.4: BOOT short press while a phone is asking to be authorized.
bool claim_pending();
bool claim_confirm();
void tick();  // called by its own TX task
bool notify_event(uint16_t code, const char* text);
}  // namespace ble

// ------------------------------------------------------------ OTA
namespace ota {
bool authenticate(const uint8_t* manifest, size_t manifest_len, const uint8_t* sig, size_t sig_len, char* err, size_t errlen);
bool begin(uint32_t size, const uint8_t sha256[32], char* err, size_t errlen);
bool write(uint32_t offset, const uint8_t* d, size_t n, char* err, size_t errlen);
bool end(char* err, size_t errlen);   // verifies SHA-256, sets boot partition
void abort();
bool active();
void mark_valid_if_healthy(bool healthy);  // rollback support
bool pending_verify();
}  // namespace ota

// ------------------------------------------------------------ UI
namespace ui {
bool init();
void show_passkey(uint32_t key, bool on);
void wake();          // turn the display on (any button / touch)
void next_screen();
void home_screen();
}  // namespace ui
