// Controller task: geofence state machine, session lifecycle, metrics,
// buttons, power policy and controlled shutdown.
#include <Arduino.h>
#include <esp_heap_caps.h>
#include <esp_sleep.h>
#include "freertos/FreeRTOS.h"
#include "freertos/queue.h"
#include "freertos/task.h"
#include "esp_task_wdt.h"
#include "app_state.h"
#include "board_pins.h"
#include "services.h"
#include "sys_util.h"

using namespace avo;

extern TaskHandle_t g_task_handles[TID_COUNT];
extern bool g_safe_mode;

namespace ctl {

static QueueHandle_t s_q = nullptr;
static StaticQueue_t s_q_meta;
static uint8_t* s_q_storage = nullptr;
static Config* s_cfg = nullptr;
static FenceSet* s_fences = nullptr;
static GeofenceFsm* s_fsm = nullptr;
static SessionLifecycle s_life;
static SessionMetricsCalc* s_metrics = nullptr;
static PowerPolicy s_power;
static BootButton s_boot;
static PowerKey s_pwr(3000);
static bool s_fences_ok = false;
static bool s_confirm_stop = false;
static uint32_t s_confirm_until = 0;
static uint8_t s_last_carr = 0xFF;
static bool s_have_carr = false;
static uint32_t s_uart_lost_base = 0;
static uint32_t s_girth_lost_acc = 0;
static uint32_t s_last_rtc_sync = 0;
static bool s_shutting_down = false;
static bool s_rtcm_flowing = false;
static StorageState s_prev_storage;
static uint8_t s_fence_for_session = 0;
static bool s_summary_valid = false;

bool post(const CtlMsg& m, uint32_t to) {
  return s_q && xQueueSend(s_q, &m, pdMS_TO_TICKS(to)) == pdTRUE;
}

bool session_cmd(SessionCmd c, CmdSource src) {
  CtlMsg m = {};
  m.type = CtlType::SESSION_CMD;
  m.src = src;
  m.arg8 = (uint8_t)c;
  return post(m, 50);
}

static void reload_config(uint32_t now) {
  cfgstore::get(s_cfg);
  int n = s_fences->build(s_cfg->fences, s_cfg->fence_count, s_cfg->active_mask);
  s_fences_ok = n > 0;
  s_fsm->configure(*s_cfg, s_fences_ok, now);
  s_power.configure(s_cfg->low_batt_pct, s_cfg->critical_batt_pct, s_cfg->critical_batt_mv);
}

static void fill_meta(RawFileMeta* m, StartReason r) {
  AppSnapshot* snap = new AppSnapshot();
  appstate::get(snap);
  strncpy(m->chest_fw, AVO_FW_VERSION, sizeof(m->chest_fw) - 1);
  if (snap->link.caps_valid) strncpy(m->back_fw, snap->link.back_caps.fw_version, sizeof(m->back_fw) - 1);
  strncpy(m->chest_dev, sys::device_id_hex(), sizeof(m->chest_dev) - 1);
  m->boot_count = sys::boot_count();
  m->horse_id = s_cfg->horse_id;
  strncpy(m->horse_name, s_cfg->horse_name, sizeof(m->horse_name) - 1);
  m->rider_id = s_cfg->rider_id;
  strncpy(m->rider_name, s_cfg->rider_name, sizeof(m->rider_name) - 1);
  m->fence_id = s_fence_for_session;
  m->start_reason = (uint8_t)r;
  m->exit_action = (uint8_t)s_cfg->exit_action;
  m->pre_s = s_cfg->pre_s;
  m->post_s = s_cfg->post_s;
  m->config_crc = cfgstore::crc();
  m->gnss_rate_hz = snap->link.caps_valid ? snap->link.back_caps.gnss_rate_hz : 0;
  m->constellations = snap->link.caps_valid ? snap->link.back_caps.gnss_constellations : 0;
  m->imu_rate_hz = snap->link.caps_valid ? snap->link.back_caps.imu_rate_hz : 0;
  m->uart_baud = s_cfg->uart_baud;
  delete snap;
}

static StartReason reason_for(CmdSource s, bool manual) {
  if (!manual) return StartReason::GEOFENCE;
  switch (s) {
    case CmdSource::APP: return StartReason::MANUAL_APP;
    case CmdSource::DEV: return StartReason::MANUAL_DEV;
    default: return StartReason::MANUAL_BUTTON;
  }
}

static CmdSource s_last_src = CmdSource::BUTTON;

static void do_start(uint32_t now, StartReason r) {
  if (!s_life.start(now, r)) return;
  s_metrics->reset(*s_cfg);
  s_metrics->m().uart_frames_lost = 0;
  AppSnapshot* snap = new AppSnapshot();
  appstate::get(snap);
  s_uart_lost_base = snap->link.dec.seq_lost;
  delete snap;
  s_girth_lost_acc = 0;
  s_summary_valid = false;
  storage::StartParams p = {};
  make_session_id(sys::device_id16(), sys::boot_count(), sys::next_session_counter(), p.session_id);
  strncpy(p.meta.session_id, p.session_id, sizeof(p.meta.session_id) - 1);
  fill_meta(&p.meta, r);
  if (!storage::start_session(p)) bb::log(BbCode::SD_ERROR, 2, 0, 0, "start queue full");
  bb::log(BbCode::SESSION_START, 0, (uint32_t)r, s_fence_for_session, p.session_id);
}

static void do_stop(uint32_t now, bool clean) {
  if (!s_life.stop(now)) return;
  s_metrics->set_time(s_life.active_ms(now), s_life.wall_ms(now));
  SessionMetrics m = s_metrics->m();
  m.girth_pkts_lost = s_girth_lost_acc;
  storage::stop_session(m, clean);
  s_summary_valid = true;
  bb::log(BbCode::SESSION_STOP, 0, m.active_ms, (uint32_t)m.distance_m);
}

static void apply_actions(uint32_t now) {
  GfAction a;
  while (s_fsm->poll(&a)) {
    switch (a.type) {
      case GfActionType::START:
        if (!a.manual) s_fence_for_session = (uint8_t)a.arg;
        do_start(now, reason_for(s_last_src, a.manual));
        break;
      case GfActionType::STOP:
        do_stop(now, true);
        break;
      case GfActionType::PAUSE:
        if (s_life.pause(now)) {
          uint8_t b = a.manual ? 1 : 0;
          sink::push(RecType::PAUSE, 0, &b, 1, sink::CRITICAL);
          s_metrics->on_pause_gap();
          bb::log(BbCode::SESSION_PAUSE, 0, a.manual);
        }
        break;
      case GfActionType::RESUME:
        if (s_life.resume(now)) {
          uint8_t b = a.manual ? 1 : 0;
          sink::push(RecType::RESUME, 0, &b, 1, sink::CRITICAL);
          bb::log(BbCode::SESSION_RESUME, 0, a.manual);
        }
        break;
      case GfActionType::EVENT:
        bb::log(BbCode::GEOFENCE, 0, (uint32_t)a.event, (uint32_t)a.arg);
        if (a.event == GfEvent::GNSS_LOST) bb::log(BbCode::GNSS_LOST, 1);
        if (a.event == GfEvent::GNSS_RECOVERED) bb::log(BbCode::GNSS_RECOVERED, 0);
        break;
      case GfActionType::NONE:
        break;
    }
  }
}

static uint64_t gnss_unix_ms(const GnssSample& g, bool* ok) {
  *ok = (g.valid & 0x07) == 0x07 && g.tacc_ns < 100000000u && g.year >= 2024;
  if (!*ok) return 0;
  int y = g.year;
  unsigned m = g.month, d = g.day;
  y -= m <= 2;
  int era = (y >= 0 ? y : y - 399) / 400;
  unsigned yoe = (unsigned)(y - era * 400);
  unsigned doy = (153 * (m + (m > 2 ? -3 : 9)) + 2) / 5 + d - 1;
  unsigned doe = yoe * 365 + yoe / 4 - yoe / 100 + doy;
  int64_t days = (int64_t)era * 146097 + (int64_t)doe - 719468;
  int64_t s = days * 86400 + g.hour * 3600 + g.min * 60 + g.sec;
  return (uint64_t)(s * 1000 + g.nano / 1000000);
}

static void on_gnss(const CtlMsg& msg) {
  const GnssSample& g = msg.gnss;
  uint32_t now = msg.rx_ms;
  bool q = gnss_quality_ok(g, s_cfg->hacc_max_cm);
  FixInput in;
  in.valid = q;
  in.hacc_m = g.hacc_mm / 1000.0;
  double sd = 0;
  uint8_t fid = 0;
  if (q && s_fences_ok && s_fences->signed_distance(g.lat_e7, g.lon_e7, &sd, &fid)) { in.sd_m = sd; in.fence_id = fid; }
  else if (q && !s_fences_ok) in.valid = false;  // no fence: geofence input not evaluable (manual still works)
  s_fsm->on_fix(in, now);
  if (s_life.state() == SessionState::RECORDING) s_metrics->on_gnss(g, now);

  // RTK state change events
  uint8_t carr = g.gnss_fix_ok() ? g.carr_soln() : 0;
  if (s_have_carr && carr != s_last_carr) bb::log(BbCode::RTK_CHANGE, 0, s_last_carr, carr);
  s_last_carr = carr;
  s_have_carr = true;

  // Wall clock from GNSS (best source); RTC refreshed every 10 min.
  bool tok;
  uint64_t ums = gnss_unix_ms(g, &tok);
  if (tok) {
    sys::wall_set(ums, sys::TimeSource::GNSS);
    if (s_last_rtc_sync == 0 || now - s_last_rtc_sync > 600000) {
      s_last_rtc_sync = now;
      board::rtc_write_unix(ums / 1000);
    }
  }
  appstate::update([&](AppSnapshot& s) {
    s.gnss.have = true;
    s.gnss.s = g;
    s.gnss.rx_ms = now;
    s.gnss.quality_ok = q;
  });
}

static void handle_cmd(SessionCmd c, CmdSource src, uint32_t now) {
  s_last_src = src;
  switch (c) {
    case SessionCmd::START: s_fsm->manual_start(now); break;
    case SessionCmd::STOP: s_fsm->manual_stop(now); break;
    case SessionCmd::PAUSE: s_fsm->manual_pause(now); break;
    case SessionCmd::RESUME: s_fsm->manual_resume(now); break;
    case SessionCmd::REARM: s_fsm->manual_rearm(now); break;
    case SessionCmd::MARKER: {
      if (s_life.active()) {
        s_metrics->on_marker(now);
        uint8_t b[5];
        b[0] = (uint8_t)src;
        put_u32(b + 1, s_metrics->m().markers);
        sink::push(RecType::MARKER, 0, b, 5, sink::CRITICAL);
      }
      break;
    }
  }
  apply_actions(now);
}

static void controlled_shutdown(const char* why) {
  if (s_shutting_down) return;
  // Never cut power during an OTA flash write or validation.
  AppSnapshot current;
  appstate::get(&current);
  if (current.ble.ota_active) {
    bb::log(BbCode::SHUTDOWN, 2, 0, 0, "blocked: OTA active");
    return;
  }
  s_shutting_down = true;
  appstate::update([&](AppSnapshot& s) { s.power.shutdown_requested = true; s.sys.display_on = true; });
  uint32_t now = sys::ms();
  bb::log(BbCode::SHUTDOWN, 0, 0, 0, why);
  if (s_life.active()) { s_fsm->manual_stop(now); apply_actions(now); }
  bool ok = storage::shutdown(8000);
  vTaskDelay(pdMS_TO_TICKS(400));  // let the blackbox writer finish
  if(!ok) {
    bb::log(BbCode::SHUTDOWN, 1, 0, 0, "SD close failed; power kept on");
    appstate::update([](AppSnapshot& s) { s.power.shutdown_requested = false; });
    s_shutting_down = false;
    return;
  }
  board::pmu_power_off();
  // If the PMIC did not cut power (e.g. the AXP2101 refused), sleep until BOOT is pressed.
  vTaskDelay(pdMS_TO_TICKS(1000));
  esp_sleep_enable_ext0_wakeup((gpio_num_t)PIN_BOOT_BTN, 0);
  esp_deep_sleep_start();
}

static void poll_inputs(uint32_t now) {
  bool boot = digitalRead(PIN_BOOT_BTN) == LOW;
  bool pwr = digitalRead(PIN_PWR_SENSE) == HIGH;
  BootButton::Event e = s_boot.update(boot, now);
  if (boot || pwr) ui::wake();
  if (s_confirm_stop && (int32_t)(now - s_confirm_until) > 0) s_confirm_stop = false;
  switch (e) {
    case BootButton::SHORT:
      if (s_confirm_stop) { s_confirm_stop = false; handle_cmd(SessionCmd::STOP, CmdSource::BUTTON, now); }
      else if (ble::claim_pending()) { if (ble::claim_confirm()) bb::log(BbCode::BLE_CONNECT, 0, 0xC1A1, 0, "phone authorized (BOOT)"); }
      else ui::next_screen();
      break;
    case BootButton::DOUBLE:
      s_confirm_stop = false;
      ui::home_screen();
      break;
    case BootButton::LONG:
      if (s_life.active()) { s_confirm_stop = true; s_confirm_until = now + 5000; }
      else handle_cmd(SessionCmd::START, CmdSource::BUTTON, now);
      break;
    default:
      break;
  }
  if (s_pwr.update(pwr, now)) controlled_shutdown("PWR long press");
  if (s_pwr.short_press()) {
    appstate::update([&](AppSnapshot& s) { s.sys.display_on = !s.sys.display_on; });
  }
  uint16_t bh = s_boot.hold_permille(now), ph = s_pwr.hold_permille(now);
  appstate::update([&](AppSnapshot& s) { s.sys.boot_hold_permille = bh; s.power.pwr_hold_permille = ph; });
}

static void poll_power(uint32_t now) {
  board::PmuStatus p;
  bool ok = board::pmu_read(&p);
  PowerLevel prev = s_power.level();
  PowerLevel lvl = ok ? s_power.update(p.batt_pct, p.batt_mv, p.vbus, now) : PowerLevel::UNKNOWN;
  if (lvl != prev) {
    if (lvl == PowerLevel::LOWBAT) bb::log(BbCode::BATT_LOW, 1, (uint32_t)p.batt_pct, p.batt_mv);
    if (lvl == PowerLevel::CRITICAL) bb::log(BbCode::BATT_CRITICAL, 2, (uint32_t)p.batt_pct, p.batt_mv);
  }
  appstate::update([&](AppSnapshot& s) { s.power.pmu = p; s.power.level = lvl; });
  if (lvl == PowerLevel::CRITICAL) controlled_shutdown("battery critical");
}

static void publish(uint32_t now) {
  s_metrics->set_time(s_life.active_ms(now), s_life.wall_ms(now));
  appstate::update([&](AppSnapshot& s) {
    s.session.st = s_life.state();
    s.session.gf = s_fsm->state();
    s.session.manual = s_fsm->manual_session();
    s.session.inhibited = s_fsm->inhibited();
    s.session.gnss_lost = s_fsm->gnss_lost();
    s.session.pending_ms = s_fsm->pending_remaining_ms(now);
    s.session.sd_m = s_fsm->last_sd();
    s.session.zone = s_fsm->last_zone();
    s.session.reason = s_life.reason();
    s.session.confirm_stop = s_confirm_stop;
    s.session.confirm_until_ms = s_confirm_until;
    s.session.summary_valid = s_summary_valid;
    if (s_life.active()) {
      s_metrics->m().uart_frames_lost = s.link.dec.seq_lost - s_uart_lost_base;
      s_metrics->m().girth_pkts_lost = s_girth_lost_acc;
      s_metrics->m().records_dropped = s.storage.dropped_records;
      s.session.metrics = s_metrics->m();
    }
    s.sys.uptime_ms = now;
    s.sys.wall_valid = sys::wall_valid();
    s.sys.wall_ms = sys::wall_ms();
    s.sys.time_source = (uint8_t)sys::wall_source();
    s.rtcm.flowing = s.rtcm.last_rx_ms && now - s.rtcm.last_rx_ms < 5000;
  });
}

static void periodic_records(uint32_t now) {
  AppSnapshot* s = new AppSnapshot();
  appstate::get(s);
  uint8_t b[64];
  ByteWriter w(b, sizeof(b));
  w.u32(now); w.u8((uint8_t)s->session.st); w.u8((uint8_t)s->session.gf); w.u8((uint8_t)s->storage.rec);
  w.i8((int8_t)s->power.pmu.batt_pct); w.u16(s->power.pmu.batt_mv); w.u8(s->power.pmu.vbus); w.u8(s->power.pmu.charging);
  w.u16((uint16_t)s->storage.ring_fill_permille); w.u32(s->storage.dropped_records); w.u8(s->ble.connected);
  w.u8(s->link.connected); w.u32(s->sys.heap_free); w.u32(s->sys.psram_free); w.u64(s->sys.wall_ms);
  sink::push(RecType::CHEST_STATUS, 0, b, w.size(), sink::NORMAL);
  bool flowing = s->rtcm.flowing;
  if (flowing != s_rtcm_flowing) bb::log(flowing ? BbCode::RTCM_RESTORED : BbCode::RTCM_LOST, flowing ? 0 : 1);
  s_rtcm_flowing = flowing;
  if (s->storage.dropped_records != s_prev_storage.dropped_records)
    bb::log(BbCode::RECORDS_DROPPED, 2, s->storage.dropped_records - s_prev_storage.dropped_records, s->storage.dropped_records);
  s_prev_storage = s->storage;
  delete s;
}

static void periodic_rtcm_record() {
  AppSnapshot* s = new AppSnapshot();
  appstate::get(s);
  uint8_t b[48];
  ByteWriter w(b, sizeof(b));
  w.u32(s->rtcm.ble_rx_bytes); w.u32(s->rtcm.ble_msgs); w.u32(s->rtcm.sent_to_back_bytes); w.u32(s->rtcm.dropped_bytes);
  w.u32(s->rtcm.observed.frames_ok); w.u32(s->rtcm.observed.frames_bad_crc); w.u16(s->rtcm.observed.last_msg_type);
  w.u32(s->link.back.rtcm_to_zed_bytes); w.u32(s->link.back.rxm_rtcm_used); w.u32(s->link.back.rxm_rtcm_failed);
  sink::push(RecType::RTCM_STATS, 0, b, w.size(), sink::NORMAL);
  delete s;
}

static void sys_stats() {
  uint32_t hf = (uint32_t)heap_caps_get_free_size(MALLOC_CAP_INTERNAL);
  uint32_t hm = (uint32_t)heap_caps_get_minimum_free_size(MALLOC_CAP_INTERNAL);
  uint32_t pf = (uint32_t)heap_caps_get_free_size(MALLOC_CAP_SPIRAM);
  uint32_t pm = (uint32_t)heap_caps_get_minimum_free_size(MALLOC_CAP_SPIRAM);
  float t = temperatureRead();
  uint32_t marks[TID_COUNT];
  for (int i = 0; i < TID_COUNT; i++) marks[i] = g_task_handles[i] ? uxTaskGetStackHighWaterMark(g_task_handles[i]) : 0;
  appstate::update([&](AppSnapshot& s) {
    s.sys.heap_free = hf; s.sys.heap_min = hm; s.sys.psram_free = pf; s.sys.psram_min = pm; s.sys.cpu_temp_c = t;
    s.sys.i2c_errors = board::i2c_errors();
    for (int i = 0; i < TID_COUNT; i++) s.sys.task_stack_min[i] = marks[i];
  });
}

static void task(void*) {
  esp_task_wdt_add(nullptr);
  CtlMsg* m = new CtlMsg();
  uint32_t last_in = 0, last_pow = 0, last_pub = 0, last_rec = 0, last_rtcm = 0, last_sys = 0;

  for (;;) {
    while (xQueueReceive(s_q, m, pdMS_TO_TICKS(10)) == pdTRUE) {
      uint32_t now = sys::ms();
      switch (m->type) {
        case CtlType::GNSS: on_gnss(*m); break;
        case CtlType::IMU_BATCH:
          if (s_life.state() == SessionState::RECORDING) { s_metrics->on_imu_batch(m->arg8); s_girth_lost_acc += m->arg32; }
          break;
        case CtlType::SESSION_CMD: handle_cmd((SessionCmd)m->arg8, m->src, now); break;
        case CtlType::CONFIG_CHANGED: reload_config(now); break;
        case CtlType::TIME_SET:
          sys::wall_set(m->arg64, sys::TimeSource::PHONE);
          if (sys::wall_source() == sys::TimeSource::PHONE) board::rtc_write_unix(m->arg64 / 1000);
          break;
        case CtlType::SHUTDOWN: controlled_shutdown("requested"); break;
        default: break;
      }
      apply_actions(now);
      if (uxQueueMessagesWaiting(s_q) == 0) break;
    }
    uint32_t now = sys::ms();
    s_fsm->tick(now);
    apply_actions(now);
    if (now - last_in >= 20) { last_in = now; poll_inputs(now); }
    if (now - last_pow >= 1000) { last_pow = now; poll_power(now); }
    if (now - last_pub >= 200) { last_pub = now; publish(now); }
    if (now - last_rec >= 1000) { last_rec = now; periodic_records(now); }
    if (now - last_rtcm >= 5000) { last_rtcm = now; periodic_rtcm_record(); }
    if (now - last_sys >= 2000) { last_sys = now; sys_stats(); }
    esp_task_wdt_reset();
  }
}

bool init() {
  // V3.3.5: the geofence/control queue payload is in PSRAM.
  s_q_storage = (uint8_t*)heap_caps_malloc(96 * sizeof(CtlMsg), MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
  s_q = s_q_storage ? xQueueCreateStatic(96, sizeof(CtlMsg), s_q_storage, &s_q_meta) : nullptr;
  Serial.printf("[AVO MEM] control queue PSRAM=%s bytes=%u\n", s_q ? "OK" : "FAIL", (unsigned)(96 * sizeof(CtlMsg)));
  s_cfg = new Config();
  s_fences = new FenceSet();
  s_fsm = new GeofenceFsm();
  s_metrics = new SessionMetricsCalc();
  if (!s_q || !s_cfg || !s_fences || !s_fsm || !s_metrics) return false;
  pinMode(PIN_BOOT_BTN, INPUT);       // external 10k pull-up
  pinMode(PIN_PWR_SENSE, INPUT);      // driven by the BSS138 inverter (official BSP: no internal pull)
  uint32_t now = sys::ms();
  reload_config(now);
  s_metrics->reset(*s_cfg);
  s_life.arm(s_cfg->auto_enabled);

  // Interrupted session at boot (power loss, crash, watchdog).
  storage::RecoveryInfo ri;
  if (storage::recovery_info(&ri)) {
    if (ri.resumable && !g_safe_mode) {
      storage::StartParams p = {};
      strncpy(p.session_id, ri.session_id, sizeof(p.session_id) - 1);
      strncpy(p.meta.session_id, ri.session_id, sizeof(p.meta.session_id) - 1);
      fill_meta(&p.meta, StartReason::RESUME_AFTER_REBOOT);
      p.meta.flags = 1;
      p.resumed = true;
      p.resume_segment = ri.segments;
      p.resume_block_seq = ri.last_block_seq;
      p.prior_active_ms = ri.active_ms;
      s_life.restore(now, ri.active_ms, StartReason::RESUME_AFTER_REBOOT);
      s_metrics->reset(*s_cfg);
      s_fsm->resume_after_reboot(ri.manual != 0, now);
      storage::start_session(p);
      bb::log(BbCode::SESSION_RESUMED_AFTER_REBOOT, 1, ri.segments, ri.truncated_bytes, ri.session_id);
    } else {
      storage::close_recovered(ri.session_id);
    }
  }
  BaseType_t created = xTaskCreatePinnedToCore(task, "ctl", 8192, nullptr, 8, &g_task_handles[TID_CTRL], 1);
  Serial.printf("[AVO MEM] control task=%s internal=%u largest=%u\n",
                created == pdPASS ? "OK" : "FAIL",
                (unsigned)heap_caps_get_free_size(MALLOC_CAP_INTERNAL | MALLOC_CAP_8BIT),
                (unsigned)heap_caps_get_largest_free_block(MALLOC_CAP_INTERNAL | MALLOC_CAP_8BIT));
  return created == pdPASS;
}

}  // namespace ctl
