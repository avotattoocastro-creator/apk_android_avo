// AVO PERFORMANCE HORSE — CHEST V3.5.0 (enlace ESP-NOW con la espalda)
// Target: Waveshare ESP32-S3-Touch-AMOLED-2.06. Build: see INSTALLATION.md
// All logic lives in src/ and lib/avo_core; this file only hands control over.
#include "src/app_main.h"

void setup() { app_setup(); }
void loop() { app_loop(); }
