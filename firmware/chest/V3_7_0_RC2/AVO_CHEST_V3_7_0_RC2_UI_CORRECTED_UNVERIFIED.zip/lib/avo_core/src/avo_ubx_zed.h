// u-blox ZED-F9P helpers for the back module (portable, host-testable):
//  - UbxStream: extracts complete UBX frames from a mixed UBX/NMEA/RTCM byte stream.
//  - ubx_valset_*: UBX-CFG-VALSET builder (RAM layer only: a power cycle restores
//    the receiver's own configuration; nothing is written to its flash/BBR).
//  - ZedManager: finds the UART baud rate, finds which ZED port (UART1/UART2) is
//    wired to the back, enables UBX + RTCM3 input and NAV-PVT + RXM-RTCM output,
//    sets the navigation rate and keeps watching the receiver.
// Key IDs: u-blox ZED-F9P HPG Interface Description (CFG-UARTx, CFG-MSGOUT, CFG-RATE).
#pragma once
#include <stdint.h>
#include <stddef.h>
#include "avo_payloads.h"

namespace avo {

// ---- configuration keys (value size is encoded in bits 28..30 of the key)
namespace zedkey {
static const uint32_t RATE_MEAS = 0x30210001;          // U2 ms
static const uint32_t UART1_BAUDRATE = 0x40520001;     // U4
static const uint32_t UART2_BAUDRATE = 0x40530001;     // U4
static const uint32_t UART1INPROT_UBX = 0x10730001, UART1INPROT_NMEA = 0x10730002, UART1INPROT_RTCM3X = 0x10730004;
static const uint32_t UART1OUTPROT_UBX = 0x10740001, UART1OUTPROT_NMEA = 0x10740002, UART1OUTPROT_RTCM3X = 0x10740004;
static const uint32_t UART2INPROT_UBX = 0x10750001, UART2INPROT_NMEA = 0x10750002, UART2INPROT_RTCM3X = 0x10750004;
static const uint32_t UART2OUTPROT_UBX = 0x10760001, UART2OUTPROT_NMEA = 0x10760002, UART2OUTPROT_RTCM3X = 0x10760004;
static const uint32_t MSGOUT_NAV_PVT_UART1 = 0x20910007, MSGOUT_NAV_PVT_UART2 = 0x20910008;
static const uint32_t MSGOUT_RXM_RTCM_UART1 = 0x20910269, MSGOUT_RXM_RTCM_UART2 = 0x2091026A;
}  // namespace zedkey

static const uint8_t UBX_CLS_ACK = 0x05, UBX_ID_ACK_ACK = 0x01, UBX_ID_ACK_NAK = 0x00;
static const uint8_t UBX_CLS_CFG = 0x06, UBX_ID_CFG_VALSET = 0x8A;
static const uint8_t UBX_CLS_MON = 0x0A, UBX_ID_MON_VER = 0x04;
static const uint8_t UBX_CLS_RXM = 0x02, UBX_ID_RXM_RTCM = 0x32;

// Size in bytes of a key's value (from the key's size bits). 0 = unknown.
size_t zed_key_value_size(uint32_t key);

struct ZedKV { uint32_t key; uint32_t value; };
// Builds a complete UBX-CFG-VALSET frame (version 0, layers = RAM). Returns length or 0.
size_t ubx_valset_ram(const ZedKV* kv, size_t n, uint8_t* out, size_t cap);
// Builds a poll frame (empty payload).
size_t ubx_poll(uint8_t cls, uint8_t id, uint8_t* out, size_t cap);

// RXM-RTCM report
struct RxmRtcm { bool crc_failed = false; uint8_t msg_used = 0; uint16_t msg_type = 0; uint16_t ref_station = 0; };
bool ubx_decode_rxm_rtcm(const uint8_t* pl, size_t n, RxmRtcm* r);

// ------------------------------------------------------------------ UbxStream
class UbxStream {
 public:
  typedef void (*FrameCb)(const uint8_t* frame, size_t len, void* ctx);
  UbxStream(FrameCb cb, void* ctx) : cb_(cb), ctx_(ctx) {}
  void feed(const uint8_t* d, size_t n);
  uint32_t frames() const { return frames_; }
  uint32_t bad_checksum() const { return bad_; }
  uint32_t nmea_sentences() const { return nmea_; }   // valid "$..*hh" sentences seen
 private:
  void byte(uint8_t b);
  void nmea_byte(uint8_t b);
  FrameCb cb_;
  void* ctx_;
  uint8_t buf_[1100];
  size_t have_ = 0, need_ = 0;
  uint32_t frames_ = 0, bad_ = 0, nmea_ = 0;
  char nm_[96];
  size_t nm_len_ = 0;
  bool nm_on_ = false;
};

// ------------------------------------------------------------------ ZedManager
class ZedIo {
 public:
  virtual ~ZedIo() {}
  virtual void zed_set_baud(uint32_t baud) = 0;
  virtual void zed_write(const uint8_t* d, size_t n) = 0;
};

class ZedManager {
 public:
  enum State : uint8_t { DETECT = 0, PROBE_PORT = 1, CONFIGURE = 2, RUNNING = 3, NO_RESPONSE = 4 };
  ZedManager(ZedIo* io, uint8_t nav_rate_hz, uint32_t target_baud = 230400);
  void begin(uint32_t now_ms);
  void tick(uint32_t now_ms);
  // Feed every byte read from the ZED UART. Complete UBX frames are reported to on_ubx.
  void feed(const uint8_t* d, size_t n, uint32_t now_ms);
  // Callback for every valid UBX frame (NAV-PVT, RXM-RTCM, ...).
  typedef void (*UbxCb)(uint8_t cls, uint8_t id, const uint8_t* pl, uint16_t plen, void* ctx);
  void set_ubx_cb(UbxCb cb, void* ctx) { ucb_ = cb; uctx_ = ctx; }
  // RTCM may be written only when the baud rate is known (or in the default fallback).
  bool rtcm_write_ok() const { return st_ == RUNNING || st_ == NO_RESPONSE; }
  void set_nav_rate(uint8_t hz, uint32_t now_ms);
  State state() const { return st_; }
  uint32_t baud() const { return baud_; }
  uint8_t port() const { return port_; }      // 1 UART1, 2 UART2, 0 unknown
  bool config_acked() const { return cfg_ok_; }
  bool rate_applied() const { return rate_ok_; }
  uint8_t nav_rate() const { return rate_; }
  uint32_t detect_cycles() const { return cycles_; }
  const UbxStream& stream() const { return ubx_; }
  // 0 not detected, 1 configuring, 2 running, 3 error (BackStatus.zed_state)
  uint8_t status_code() const;
  static const char* state_name(State s);

 private:
  static void on_frame(const uint8_t* f, size_t n, void* ctx);
  void handle(const uint8_t* f, size_t n);
  void go(State s, uint32_t now_ms);
  void poll_ver();
  void send_baud(uint8_t port, uint32_t baud);
  void send_config(bool with_rate);
  ZedIo* io_;
  UbxStream ubx_;
  UbxCb ucb_ = nullptr;
  void* uctx_ = nullptr;
  State st_ = DETECT;
  uint8_t rate_;
  uint32_t target_;
  uint32_t baud_ = 38400, found_ = 0;
  uint8_t port_ = 0;
  uint8_t step_ = 0, cand_ = 0, tries_ = 0;
  uint32_t t0_ = 0, last_ubx_ms_ = 0, last_nmea_count_ = 0;
  bool got_ubx_ = false, got_nmea_ = false;
  bool cfg_ok_ = false, rate_ok_ = false, cfg_with_rate_ = true;
  uint8_t ack_ = 0;          // 0 waiting, 1 ACK, 2 NAK
  uint32_t cycles_ = 0;
  uint32_t now_ = 0;
};

}  // namespace avo
