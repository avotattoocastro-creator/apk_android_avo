// AVO Chest firmware identity. Bumped for every release.
#pragma once
#define AVO_FW_NAME "AVO-CHEST"
#define AVO_FW_VERSION "3.7.0-rc2"
#define AVO_FW_VERSION_NUM 0x030700
#define AVO_HW_TARGET "Waveshare ESP32-S3-Touch-AMOLED-2.06 (schematic V1.0)"
