from pathlib import Path
s=(Path(__file__).resolve().parents[1]/"AVO_CHEST_V3_5_0/src/ble_service.cpp").read_text()
case=s.split("case BleMsg::OTA_END:",1)[1].split("case BleMsg::OTA_ABORT:",1)[0]
assert case.index("ota::end(") < case.index("storage::shutdown(5000)") < case.index("respond(type, id, BleStatus::OK)") < case.index("esp_restart()")
assert "BleStatus::IO_ERROR" in case and "reboot cancelled" in case
assert "ota_display_status=2" in case and "ota_display_status=3" in case
print("PASS: OTA_END ACK follows SD shutdown (static ordering check)")
