from pathlib import Path
p=Path(__file__).resolve().parents[1]/"AVO_CHEST_V3_5_0"/"src"
ui=(p/"ui.cpp").read_text()
ble=(p/"ble_service.cpp").read_text()
state=(p/"app_state.h").read_text()
assert 'ota_display_status' in state
assert 'ota_display_status=2' in ble and 'ota_display_status=3' in ble
assert 'ota_display_status=3' in ble
assert 'uint64_t)snap->ble.ota_bytes*99' in ui
assert 'snprintf(ota_percent' in ui
assert 'ESPERA REINICIO' in ui
assert 'OTA VERIFICADA' in ui
assert 'AVO_UI_SEVEN_BANDS_V361' in ui
assert 'AVO_UI_ROTATE_180_V361' in ui
assert 'AVO_UI_SAFE_SHUTDOWN_V361' in ui
assert 'old_state[7]' in ui
assert 'last_batch_ms[2]' in ui
for name,text in [('ui',ui),('ble',ble),('state',state)]:
    assert text.count('{')==text.count('}'),name
print("PASS: static UI/OTA regression checks (not a C++ compilation)")
