from pathlib import Path
s=(Path(__file__).resolve().parents[1]/'AVO_CHEST_V3_5_0/src/storage.cpp').read_text()
assert 'scan_ok = raw_recover(' in s
assert 's_recovery.resumable = scan_ok &&' in s
assert 'RAW recovery scan failed; resume disabled' in s
assert s.count('{') == s.count('}')
print('PASS: RAW recovery fail-closed source checks (not hardware test)')
