from pathlib import Path
s=(Path(__file__).resolve().parents[1]/'AVO_CHEST_V3_5_0/src/storage.cpp').read_text()
assert 's_shutdown_ok = !s_error_mode && !s_closing && !s_session && !s_opened && !s_w.is_open();' in s
assert 'if (!session_meta_write(s_dir, &s_meta)) {' in s
assert 'enter_error("close metadata");' in s
assert '|| s_mounted' not in s[s.index('case CmdType::SHUTDOWN:'):s.index('case CmdType::FILE:')]
print('PASS strict SD shutdown static invariants')
