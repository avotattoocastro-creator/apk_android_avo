from pathlib import Path
s=(Path(__file__).resolve().parents[1]/"AVO_CHEST_V3_5_0/src/ble_service.cpp").read_text()
assert "if (!storage::shutdown(5000))" in s
assert "OTA verified but SD shutdown failed; reboot cancelled" in s
assert s.index("if (!storage::shutdown(5000))") < s.index("esp_restart();", s.index("if (!storage::shutdown(5000))"))
print("PASS: OTA reboot SD interlock static check")
