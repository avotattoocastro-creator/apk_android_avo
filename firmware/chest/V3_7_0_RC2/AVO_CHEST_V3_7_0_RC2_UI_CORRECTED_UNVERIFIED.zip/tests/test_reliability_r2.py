from pathlib import Path
src=Path(__file__).resolve().parents[1]/"AVO_CHEST_V3_5_0/src"
u=(src/"ui.cpp").read_text()
assert "last_charge_pct" in u
assert "current_pct == last_charge_pct" in u
assert "ota_notice && !snap->power.shutdown_requested" in u
assert "AVO_UI_SEVEN_BANDS_V361" in u
assert "AVO_UI_ROTATE_180_V361" in u
assert "AVO_UI_OTA_PROGRESS_V361" in u
assert u.count("{")==u.count("}")
print("PASS: UI reliability static regression tests (not C++ compile)")
