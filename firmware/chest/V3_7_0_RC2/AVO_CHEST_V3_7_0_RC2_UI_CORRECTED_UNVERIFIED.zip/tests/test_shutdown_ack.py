from pathlib import Path
s=(Path(__file__).resolve().parents[1]/'AVO_CHEST_V3_5_0/src/storage.cpp').read_text()
assert 'static bool s_shutdown_ok = false' in s
assert 'if (s_w.is_open() && !s_w.flush(true, rtc_ms(), sys::ms())) enter_error("shutdown flush")' in s
assert 's_shutdown_ok = !s_error_mode && !s_closing' in s
assert 'return s_shutdown_ok;' in s
print('PASS: shutdown success ACK source assertions (static)')
