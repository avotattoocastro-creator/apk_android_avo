from pathlib import Path
p=Path("AVO_CHEST_V3_5_0/src")
u=(p/"ui.cpp").read_text();b=(p/"ble_service.cpp").read_text();a=(p/"app_state.h").read_text()
for x in ("AVO_UI_SEVEN_BANDS_V361","AVO_UI_OTA_PROGRESS_V361","AVO_UI_ROTATE_180_V361","AVO_UI_SAFE_SHUTDOWN_V361","OTA VERIFICADA","ERROR OTA"): assert x in u,x
for x in ("ota_display_status=1","ota_display_status=2","ota_display_status=3"): assert x in b,x
assert "ota_display_since_ms" in a
for x in (u,b,a): assert x.count("{")==x.count("}"),"unbalanced braces"
print("PASS: static checks only; not compiled")
