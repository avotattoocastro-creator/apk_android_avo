#!/usr/bin/env bash
# Build AVO Chest V3.5.0 (arduino-cli).
# Pinned: arduino-esp32 3.3.12 · NimBLE-Arduino 2.5.1 (h2zero) · Waveshare libs @ f855653f672d (Arduino_GFX 1.6.0, XPowersLib 0.3.0)
# Usage: ./build.sh [output_dir]   env: ARDUINO_CLI, ARDUINO_CONFIG, FQBN_VENDOR (esp32 for Board-Manager installs)
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
OUT="${1:-$HERE/firmware_chest}"
CLI="${ARDUINO_CLI:-arduino-cli}"
CFG="${ARDUINO_CONFIG:-}"
DEPS="$HERE/.deps"
LIBS="$HERE/.build_libs_chest"
FQBN="${FQBN_VENDOR:-espressif}:esp32:esp32s3:FlashSize=16M,PSRAM=opi,PartitionScheme=custom,CDCOnBoot=cdc,USBMode=hwcdc,FlashMode=qio,CPUFreq=240"
mkdir -p "$DEPS"
[ -d "$DEPS/ws" ] || { git clone https://github.com/waveshareteam/ESP32-S3-Touch-AMOLED-2.06 "$DEPS/ws" && git -C "$DEPS/ws" checkout f855653f672d9c88f219027d2115d8276dc7c224; }
[ -d "$DEPS/NimBLE-Arduino" ] || git clone --depth 1 -b 2.5.1 https://github.com/h2zero/NimBLE-Arduino.git "$DEPS/NimBLE-Arduino"
rm -rf "$LIBS" && mkdir -p "$LIBS"
cp -r "$DEPS/ws/examples/arduino/libraries/Arduino_GFX" "$DEPS/ws/examples/arduino/libraries/XPowersLib" "$DEPS/NimBLE-Arduino" "$LIBS/"
cp -r "$HERE/lib/avo_core" "$LIBS/"
export SOURCE_DATE_EPOCH="${SOURCE_DATE_EPOCH:-1792368000}"
BP="$HERE/.arduino_build_chest"; rm -rf "$BP"
PMAP="-ffile-prefix-map=$HERE=AVO -ffile-prefix-map=$BP=AVOBUILD"
ARGS=(compile -b "$FQBN" --libraries "$LIBS" --build-path "$BP" --output-dir "$OUT" --warnings all --jobs 0
      --build-property "compiler.c.extra_flags=$PMAP" --build-property "compiler.cpp.extra_flags=$PMAP")
[ -n "$CFG" ] && ARGS=(--config-file "$CFG" "${ARGS[@]}")
mkdir -p "$OUT"
"$CLI" "${ARGS[@]}" "$HERE/AVO_CHEST_V3_5_0" 2>&1 | tee "$OUT/build.log"
