from pathlib import Path
p=Path(__file__).resolve().parent/'AVO_CHEST_V3_5_0/src'
c=(p/'controller.cpp').read_text(); b=(p/'ble_service.cpp').read_text()
assert 'if (current.ble.ota_active)' in c
assert 'if (current.power.shutdown_requested || current.ble.ota_active)' in b
assert c.index('if (current.ble.ota_active)') < c.index('s_shutting_down = true;',c.index('static void controlled_shutdown'))
assert b.index('if (current.power.shutdown_requested || current.ble.ota_active)') < b.index('bool ok = ota::begin(size, sha')
print('PASS: static OTA/power interlock assertions (not compilation)')
