AVO CHEST 3.7.0 RC2 DISPLAY REDESIGN — UNVERIFIED
Native portrait 410x502; seven rounded cards and icon primitives.
Original reference is a conceptual mockup; physical screen may differ due to font/shape limitations.
No new hardware testing, BLE/OTA/SD guarantees. Verify on Waveshare before deployment.
