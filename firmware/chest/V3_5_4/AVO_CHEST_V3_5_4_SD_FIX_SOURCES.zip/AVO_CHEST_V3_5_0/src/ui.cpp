// AVO CHEST V3.5.0 LITE — four solid AMOLED status bands, no LVGL.
// V3.5.0: band 4 (back) also shows ESP-NOW pairing and a ZED that does not answer.
// V3.4.4: colour constants renamed C_* (Arduino_GFX defines BLACK/RED/... as macros,
// which broke the V3.4.3 build); BLE band shows authorization / 'PULSA BOOT'.
// Arduino_GFX CO5300 QSPI, partial rectangle updates only.
#include <Arduino.h>
#include <Arduino_GFX_Library.h>
#include <esp_heap_caps.h>
#include <new>
#include <cstring>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "app_state.h"
#include "board_pins.h"
#include "services.h"
#include "sys_util.h"

using namespace avo;
extern TaskHandle_t g_task_handles[TID_COUNT];
namespace ui {
static Arduino_DataBus* bus = nullptr;
static Arduino_CO5300* gfx = nullptr;
static volatile bool request_wake = false;
static volatile bool passkey_active = false;
static bool display_on = true;
static uint8_t brightness = 180;
static uint8_t old_state[4] = {255,255,255,255};

static uint32_t last_touch_ms = 0;
static uint32_t touch_start_ms = 0;
static bool dev_latched = false;
static bool developer_mode = false;
static Config config_cache;  // Avoid large config on UI task stack.

// RGB565, no fonts, images, sprites, framebuffers or LVGL.
static constexpr uint16_t C_GREEN = 0x06E6;
static constexpr uint16_t C_BLUE  = 0x241F;
static constexpr uint16_t C_AMBER = 0xFDC0;
static constexpr uint16_t C_RED   = 0xF986;
static constexpr uint16_t C_BLACK = 0x0000;

void show_passkey(uint32_t, bool on) {
  // No numeric passkey can be displayed in four-band mode.
  // Pairing method must be checked in BLE service / Android app.
  passkey_active = on;
  request_wake = true;
}
void wake() { request_wake = true; }
void next_screen() { request_wake = true; } // No extra screens.
void home_screen() { request_wake = true; }

static void screen_power(bool on) {
  if (on == display_on) return;
  display_on = on;
  if (on) {
    gfx->displayOn();
    gfx->setBrightness(brightness);
    for (auto &p : old_state) p = 255;
  } else gfx->displayOff();
  appstate::update([on](AppSnapshot& a) { a.sys.display_on = on; });
}
// Small built-in 5x7 font, scaled 2x. No LVGL, fonts on SD, or framebuffer.
struct Band { uint16_t color; const char* state; };
static bool old_blink[4] = {false,false,false,false};
static void draw_band(int i, uint16_t color, const char* title, const char* state) {
  const int y0 = (LCD_HEIGHT * i) / 4;
  const int y1 = (LCD_HEIGHT * (i + 1)) / 4;
  const int top = y0 & ~1;
  const int bottom = (y1 + 1) & ~1;
  gfx->fillRect(0, top, LCD_WIDTH, bottom - top, color);
  // Built-in Arduino_GFX font: 6x8 pixels at size 2.
  const uint8_t font_scale = 2;
  const uint16_t fg = (color == C_GREEN || color == C_AMBER) ? C_BLACK : 0xFFFF;
  gfx->setTextSize(font_scale);
  gfx->setTextColor(fg, color);
  int tx = (LCD_WIDTH - int(strlen(title)) * 6 * font_scale) / 2;
  int sx = (LCD_WIDTH - int(strlen(state)) * 6 * font_scale) / 2;
  gfx->setCursor(tx > 0 ? tx : 0, top + (bottom-top)/2 - 26);
  gfx->print(title);
  gfx->setCursor(sx > 0 ? sx : 0, top + (bottom-top)/2 + 6);
  gfx->print(state);
}
static void render(const AppSnapshot& s, uint32_t now) {
  // Keep each label independent of the current background color.
  Band b[4];
  uint8_t states[4];
  const char* titles[4] = {"GPS RTK", "BLUETOOTH", "MICROSD", "PECHO / ESPALDA"};
  if (!s.gnss.have || now - s.gnss.rx_ms > 3000 || !s.gnss.s.gnss_fix_ok()) {
    b[0] = {C_RED, "SIN GPS"}; states[0] = 0;
  } else if (s.gnss.s.carr_soln() == 2) {
    b[0] = {C_GREEN, "RTK FIX"}; states[0] = 1;
  } else if (s.gnss.s.carr_soln() == 1) {
    b[0] = {C_AMBER, "RTK FLOAT"}; states[0] = 2;
  } else if (s.gnss.s.diff_soln()) {
    b[0] = {C_AMBER, "DGNSS"}; states[0] = 3;
  } else {
    b[0] = {C_BLUE, "GPS SIN RTK"}; states[0] = 4;
  }
  if (s.ble.claim_pending) { b[1] = Band{C_AMBER,"PULSA BOOT"}; states[1] = 2; }
  else if (!s.ble.connected) { b[1] = Band{C_RED,"SIN CONEXION"}; states[1] = 0; }
  else if (!s.ble.authorized) { b[1] = Band{C_AMBER,"SIN AUTORIZAR"}; states[1] = 3; }
  else { b[1] = Band{C_BLUE,"CONECTADO"}; states[1] = 1; }
  if (!s.storage.mounted || s.storage.rec == RecStatus::REC_ERROR || s.storage.write_errors) {
    b[2] = {C_RED,"ERROR"}; states[2] = 0;
  } else if (s.storage.rec == RecStatus::RECORDING || s.storage.rec == RecStatus::TEMP_BUFFER) {
    b[2] = {C_AMBER,"GRABANDO"}; states[2] = 2;
  } else {
    b[2] = {C_GREEN,"OK"}; states[2] = 1;
  }
  if (s.link.transport == 1 && s.link.now_pairing) {
    b[3] = {C_AMBER,"EMPAREJANDO"}; states[3] = 3;
  } else if (s.link.transport == 1 && !s.link.now_paired) {
    b[3] = {C_RED,"SIN EMPAREJAR"}; states[3] = 4;
  } else if (!s.link.connected) {
    b[3] = {C_RED,"SIN CONEXION"}; states[3] = 0;
  } else if (s.link.status_valid && s.link.back.zed_state == 3) {
    b[3] = {C_AMBER,"GPS NO RESPONDE"}; states[3] = 5;
  } else if (now - s.link.last_rx_ms > 1000) {
    b[3] = {C_AMBER,"INTERMITENTE"}; states[3] = 2;
  } else {
    b[3] = {C_GREEN,"CONECTADO"}; states[3] = 1;
  }
  const bool blink_off = ((now / 500) % 2) != 0;
  for (int i=0; i<4; ++i) {
    const bool fault_blink = b[i].color == C_RED && blink_off;
    if (old_state[i] == states[i] && old_blink[i] == fault_blink) continue;
    draw_band(i, fault_blink ? C_BLACK : b[i].color, titles[i], b[i].state);
    old_state[i] = states[i];
    old_blink[i] = fault_blink;
  }
}
static bool pair_latched = false;
static void task(void*) {
  auto* snap = static_cast<AppSnapshot*>(heap_caps_malloc(sizeof(AppSnapshot), MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT));
  if (!snap) {
    Serial.println("[AVO LITE] ERROR: no PSRAM for UI snapshot");
    vTaskDelete(nullptr);
    return;
  }
  new (snap) AppSnapshot();
  uint32_t last_update = 0;
  for (;;) {
    const uint32_t now = sys::ms();
    if (request_wake) { request_wake = false; screen_power(true); }
    if (now - last_touch_ms >= 60) {
      last_touch_ms = now;
      bool pressed = false;
      int16_t x=0,y=0;
      if (board::touch_read(&pressed,&x,&y) && pressed) {
        if (!touch_start_ms) { touch_start_ms = now; pair_latched = false; }
        // V3.5.0: touch held 5 s anywhere = look for a back for 60 s (harmless if the own back is
        // alive: it simply answers again). Developer mode stays at 20 s.
        if (!pair_latched && now - touch_start_ms >= 5000) {
          pair_latched = true;
          uartlink::pair_start(60000);
          Serial.println("[AVO LITE] ESP-NOW pairing requested from the touch screen (60 s)");
        }
        if (!dev_latched && now - touch_start_ms >= 20000) {
          dev_latched = true;
          developer_mode = !developer_mode;
          appstate::update([](AppSnapshot& a) { a.sys.dev_mode = developer_mode; });
          Serial.printf("[AVO LITE] developer flag=%d (configuration via Android)\n", developer_mode);
        }
      } else { touch_start_ms = 0; dev_latched = false; }
    }
    if (now - last_update >= 250) {
      last_update = now;
      appstate::get(snap);
      cfgstore::get(&config_cache);
      uint8_t wanted = config_cache.brightness;
      if (config_cache.dim_on_low_batt && snap->power.level == PowerLevel::LOWBAT && wanted > 60) wanted = 60;
      if (wanted != brightness) { brightness = wanted; if (display_on) gfx->setBrightness(brightness); }
      if (!snap->sys.display_on && display_on && !snap->power.shutdown_requested && !passkey_active) screen_power(false);
      if (snap->sys.display_on && !display_on) screen_power(true);
      if (display_on) render(*snap,now);
    }
    vTaskDelay(pdMS_TO_TICKS(25));
  }
}
bool init() {
  bus = new Arduino_ESP32QSPI(PIN_LCD_CS,PIN_LCD_SCLK,PIN_LCD_SDIO0,PIN_LCD_SDIO1,PIN_LCD_SDIO2,PIN_LCD_SDIO3);
  gfx = new Arduino_CO5300(bus,PIN_LCD_RESET,0,LCD_WIDTH,LCD_HEIGHT,LCD_COL_OFFSET,0,0,0);
  if (!gfx || !gfx->begin()) return false;
  gfx->fillScreen(C_BLACK);
  cfgstore::get(&config_cache);
  brightness = config_cache.brightness;
  gfx->setBrightness(brightness);
  board::touch_init();
  BaseType_t ok = xTaskCreatePinnedToCore(task,"ui_lite",4096,nullptr,2,&g_task_handles[TID_UI],0);
  Serial.printf("[AVO MEM] UI LITE task=%s internal=%u largest=%u psram=%u\n",ok==pdPASS?"OK":"FAIL",
    (unsigned)heap_caps_get_free_size(MALLOC_CAP_INTERNAL | MALLOC_CAP_8BIT),
    (unsigned)heap_caps_get_largest_free_block(MALLOC_CAP_INTERNAL | MALLOC_CAP_8BIT),
    (unsigned)ESP.getFreePsram());
  return ok == pdPASS;
}
} // namespace ui
