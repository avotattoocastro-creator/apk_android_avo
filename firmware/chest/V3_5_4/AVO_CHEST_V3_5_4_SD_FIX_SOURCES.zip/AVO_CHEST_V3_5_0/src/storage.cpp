// Storage task — the ONLY code that touches the MicroSD card.
// RAW-first pipeline: record sink (PSRAM) -> pre-buffer (no session) or
// RawWriter blocks (session) -> FATFS. File services for BLE are executed
// here too, interleaved with writing, so there is never concurrent card access.
#include <Arduino.h>
#include <SD_MMC.h>
#include <dirent.h>
#include <sys/stat.h>
#include <unistd.h>
#include <esp_heap_caps.h>
#include <esp_random.h>
#include <esp_vfs_fat.h>
#include <mbedtls/sha256.h>
#include "freertos/FreeRTOS.h"
#include "freertos/queue.h"
#include "freertos/semphr.h"
#include "freertos/task.h"
#include "esp_task_wdt.h"
#include "app_state.h"
#include "board_pins.h"
#include "services.h"
#include "sys_util.h"

using namespace avo;

namespace storage {

#ifndef AVO_SD_MOUNT
#define AVO_SD_MOUNT "/sdcard"   // the host test harness overrides this with a temp dir
#endif
static const char* ROOT = AVO_SD_MOUNT "/AVO";
static const size_t BLOCK_PAYLOAD = 32 * 1024;
static const size_t SCAN_BUF = RAW_BLOCK_HDR + RAW_MAX_BLOCK_PAYLOAD;

enum class CmdType : uint8_t { START = 1, STOP, CLOSE_RECOVERED, FLUSH, SHUTDOWN, FILE };
struct Cmd {
  CmdType type;
  StartParams start;
  SessionMetrics metrics;
  bool clean;
  FileReq file;
};

static QueueHandle_t s_q = nullptr;
static SemaphoreHandle_t s_done = nullptr;
static TaskHandle_t s_task = nullptr;
static FileRespCb s_file_cb = nullptr;
static RecoveryInfo s_recovery;
static volatile bool s_session = false;

// --------------------------------------------------------------- task-local state
static bool s_mounted = false;
static RawWriter s_w;
static uint8_t* s_block = nullptr;
static uint8_t* s_scan = nullptr;
static RecordRing s_pre;
static uint8_t* s_pre_mem = nullptr;
static size_t s_pre_cap = 0;
static uint8_t s_pre_s = 0;
static StartParams s_sp;
static char s_dir[96];
static uint16_t s_seg = 0;
static bool s_opened = false;          // session files exist on the card
static bool s_closing = false;         // STOP requested, waiting for the card
static SessionMetrics s_close_metrics;
static bool s_close_clean = true;
static SessionMetaFile s_meta;
static uint32_t s_last_flush = 0, s_last_sync = 0, s_last_meta = 0, s_last_mount_try = 0, s_last_status = 0;
static uint32_t s_write_err = 0, s_remounts = 0, s_max_write = 0, s_last_write_ok = 0;
static bool s_error_mode = false;
static Config s_cfg;
static uint32_t s_del_token = 0, s_del_until = 0;
static char s_del_id[24] = {0};

// SHA job (runs in slices between writes)
struct ShaJob { bool active; FileReq req; uint16_t seg; uint64_t off; mbedtls_sha256_context ctx; bool for_upload; };
static ShaJob s_sha = {};

static uint64_t rtc_ms() { return sys::wall_ms(); }

static bool mount() {
  SD_MMC.end();
  if (!SD_MMC.setPins(PIN_SD_CLK, PIN_SD_CMD, PIN_SD_D0)) return false;
  if (!SD_MMC.begin(AVO_SD_MOUNT, true, false, SDMMC_FREQ_DEFAULT, 6)) return false;
  if (SD_MMC.cardType() == CARD_NONE) return false;
  mkdir(ROOT, 0777);
  struct stat st;
  return stat(ROOT, &st) == 0;
}

static void update_card_space() {
  uint64_t total = 0, freeb = 0;
  if (s_mounted && esp_vfs_fat_info(AVO_SD_MOUNT, &total, &freeb) == ESP_OK) {
    appstate::update([&](AppSnapshot& s) { s.storage.card_bytes = total; s.storage.free_bytes = freeb; });
  }
}

static void seg_path(const char* dir, uint16_t seg, char* out, size_t cap) {
  snprintf(out, cap, "%s/P%03u.avr", dir, (unsigned)seg);
}

static bool alloc_prebuffer() {
  s_pre_s = s_cfg.pre_s;
  size_t want = (size_t)s_cfg.pre_s * s_cfg.nominal_rate_bps * 5 / 4;
  if (want == 0) { s_pre_cap = 0; return true; }
  size_t max_by_heap = heap_caps_get_free_size(MALLOC_CAP_SPIRAM);
  max_by_heap = max_by_heap > (1536u * 1024u) ? max_by_heap - 1536u * 1024u : 0;  // keep 1.5 MB of PSRAM for others
  size_t cap = want;
  if (cap > 6u * 1024u * 1024u) cap = 6u * 1024u * 1024u;
  if (cap > max_by_heap) cap = max_by_heap;
  while (cap >= 64 * 1024 && !(s_pre_mem = (uint8_t*)heap_caps_malloc(cap, MALLOC_CAP_SPIRAM))) cap -= 64 * 1024;
  if (!s_pre_mem) { s_pre_cap = 0; bb::log(BbCode::PREBUFFER_REDUCED, 2, (uint32_t)want, 0, "prebuffer alloc failed"); return false; }
  s_pre.init(s_pre_mem, cap);
  s_pre_cap = cap;
  if (cap < want) bb::log(BbCode::PREBUFFER_REDUCED, 1, (uint32_t)want, (uint32_t)cap, "prebuffer reduced");
  return true;
}

// ---------------------------------------------------------------- session files
static void drain(uint32_t budget_bytes);
static void append_or_fail(RecType t, uint8_t flags, const uint8_t* d, size_t n);

static bool open_segment(uint16_t seg, uint32_t first_seq, uint16_t extra_flags) {
  char path[128];
  seg_path(s_dir, seg, path, sizeof(path));
  RawFileMeta m = s_sp.meta;
  m.segment = seg;
  m.created_rtc_ms = rtc_ms();
  m.created_uptime_ms = sys::ms();
  if (!s_w.open(path, m, first_seq)) return false;
  s_seg = seg;
  if (extra_flags) s_w.set_block_flags(extra_flags);
  s_meta.segments = seg;
  session_meta_write(s_dir, &s_meta);
  return true;
}

static bool s_dir_created = false;   // this session's directory was created by us

static uint16_t next_free_segment() {
  char path[128];
  for (uint16_t sgm = 1; sgm < 1000; sgm++) {
    seg_path(s_dir, sgm, path, sizeof(path));
    struct stat st;
    if (stat(path, &st) != 0) return sgm;
  }
  return 0;
}

static bool open_session_files() {
  snprintf(s_dir, sizeof(s_dir), "%s/%s", ROOT, s_sp.session_id);
  if (!s_sp.resumed) {
    if (!s_dir_created) {
      struct stat st;
      if (stat(s_dir, &st) == 0) {
        // Never reuse/overwrite another session's directory.
        bb::log(BbCode::SD_ERROR, 2, 0, 0, "session dir exists");
        return false;
      }
      if (mkdir(s_dir, 0777) != 0) return false;
      s_dir_created = true;
      s_meta = SessionMetaFile();
      strncpy(s_meta.session_id, s_sp.session_id, sizeof(s_meta.session_id) - 1);
      s_meta.state = SessionFileState::OPEN;
      s_meta.start_reason = s_sp.meta.start_reason;
      s_meta.manual = s_sp.meta.start_reason != (uint8_t)StartReason::GEOFENCE;
      s_meta.start_rtc_ms = rtc_ms();
    }
    uint16_t seg = next_free_segment();  // > 1 only when an earlier attempt failed
    if (!seg || !open_segment(seg, seg == 1 ? 0 : s_w.next_block_seq(), seg > 1 ? BF_AFTER_ERROR : 0)) return false;
  } else {
    if (!session_meta_read(s_dir, &s_meta)) { s_meta = SessionMetaFile(); strncpy(s_meta.session_id, s_sp.session_id, 23); }
    s_meta.state = SessionFileState::OPEN;
    s_meta.reboots++;
    uint16_t seg = next_free_segment();
    if (!seg || !open_segment(seg, s_sp.resume_block_seq + 1, BF_AFTER_RECOVERY)) return false;
  }
  s_opened = true;
  s_last_flush = s_last_sync = s_last_meta = sys::ms();
  // session start record
  uint8_t b[64];
  ByteWriter w(b, sizeof(b));
  w.str(s_sp.session_id, 24); w.u8(s_sp.meta.start_reason); w.u8(s_sp.resumed ? 1 : 0); w.u8(s_sp.meta.fence_id);
  w.u8(s_sp.meta.exit_action); w.u32(s_sp.prior_active_ms); w.u64(rtc_ms()); w.u8((uint8_t)sys::wall_source());
  append_or_fail(RecType::SESSION_START, 0, b, w.size());
  // configuration snapshot
  size_t cap = config_max_size();
  uint8_t* cb = (uint8_t*)malloc(cap);
  if (cb) {
    size_t n = config_serialize(s_cfg, cb, cap);
    if (n) append_or_fail(RecType::CONFIG_SNAPSHOT, 0, cb, n);
    free(cb);
  }
  // pre-buffer (original records, original timestamps, flagged)
  uint64_t t0 = 0, t1 = 0;
  uint32_t nrec = s_pre.count();
  s_pre.oldest_time(&t0);
  s_pre.newest_time(&t1);
  uint8_t pi[32];
  ByteWriter pw(pi, sizeof(pi));
  pw.u32(nrec); pw.u64(t0); pw.u64(t1); pw.u8(s_pre_s); pw.u32((uint32_t)s_pre_cap);
  append_or_fail(RecType::PREBUFFER_INFO, 0, pi, pw.size());
  RecView v;
  while (!s_error_mode && s_pre.peek(&v)) {
    RecHdr h = v.hdr;
    h.flags |= RF_PREBUFFER;
    if (!s_w.append(h, v.data, rtc_ms(), sys::ms())) { s_error_mode = true; break; }
    s_pre.pop();
  }
  return !s_error_mode;
}

static void enter_error(const char* why) {
  if (!s_error_mode) {
    s_write_err++;
    bb::log(BbCode::SD_ERROR, 2, s_write_err, 0, why);
  }
  s_error_mode = true;
  s_w.abandon();     // pending block stays in RAM and is rewritten to the next segment
}

static void append_or_fail(RecType t, uint8_t flags, const uint8_t* d, size_t n) {
  RecHdr h;
  h.type = (uint8_t)t;
  h.flags = flags;
  h.len = (uint16_t)n;
  h.chest_us = sys::us();
  if (!s_w.append(h, d, rtc_ms(), sys::ms())) enter_error("append");
}

static void try_recover_card() {
  uint32_t now = sys::ms();
  if (now - s_last_mount_try < 2000) return;
  s_last_mount_try = now;
  s_mounted = mount();
  if (!s_mounted) return;
  s_remounts++;
  bb::log(BbCode::SD_REMOUNT, 1, s_remounts);
  update_card_space();
  s_error_mode = false;
  if (!s_session && !s_closing) return;
  bool ok;
  if (!s_opened) ok = open_session_files();
  else {
    uint16_t seg = next_free_segment();
    ok = seg && open_segment(seg, s_w.next_block_seq(), BF_AFTER_ERROR);
  }
  if (!ok) enter_error("reopen");
}

static void write_close_record(const SessionMetrics& m, bool clean) {
  uint8_t b[160];
  ByteWriter w(b, sizeof(b));
  w.u8(clean ? 1 : 0); w.u32(m.active_ms); w.u32(m.wall_ms); w.u32((uint32_t)(m.distance_m * 100));
  w.u32((uint32_t)(m.max_speed_mps * 1000)); w.u32((uint32_t)(m.mean_speed_mps() * 1000));
  w.u32((uint32_t)(m.max_accel_mps2 * 1000)); w.u32((uint32_t)(m.max_decel_mps2 * 1000));
  w.u32(m.gnss_samples); w.u32(m.gnss_valid); w.u32(m.imu_batches); w.u32(m.imu_samples);
  w.u32(m.uart_frames_lost); w.u32(m.girth_pkts_lost); w.u32(sink::dropped_total());
  w.u32(m.t_fix_ms); w.u32(m.t_float_ms); w.u32(m.t_gnss_ms); w.u32(m.t_nofix_ms);
  for (int i = 0; i < AVO_N_SPLITS; i++) w.u32(m.split_ms[i]);
  w.u32(m.markers); w.u32(m.laps); w.u32(m.best_lap_ms); w.u32(m.series); w.u32(m.series_total_ms);
  w.u64(rtc_ms());
  append_or_fail(RecType::SESSION_CLOSE, 0, b, w.size());
}

static bool s_close_rec_done = false;
static void finish_close() {
  drain(UINT32_MAX);
  if (s_error_mode) return;
  if (!s_close_rec_done) { write_close_record(s_close_metrics, s_close_clean); s_close_rec_done = true; }
  if (s_error_mode) return;  // retried when the card is back (record kept in the pending block)
  if (!s_w.close(true, rtc_ms(), sys::ms())) { enter_error("close"); return; }
  s_meta.state = SessionFileState::CLOSED;
  s_meta.last_block_seq = s_w.next_block_seq() - 1;
  s_meta.last_rtc_ms = rtc_ms();
  s_meta.active_ms = s_close_metrics.active_ms;
  s_meta.total_bytes += s_w.file_bytes();
  session_meta_write(s_dir, &s_meta);
  s_closing = false;
  s_session = false;
  s_opened = false;
  appstate::update([&](AppSnapshot& s) { s.storage.rec = RecStatus::IDLE; });
}

// ---------------------------------------------------------------- draining
static void drain(uint32_t budget_bytes) {
  uint32_t moved = 0;
  RecView v;
  if ((s_session || s_closing) && s_opened && !s_error_mode) {
    uint32_t lost = sink::take_dropped_since_last();
    if (lost) {
      uint8_t b[8];
      put_u32(b, lost); put_u32(b + 4, sink::dropped_total());
      append_or_fail(RecType::LOSS, 0, b, 8);
    }
  }
  while (moved < budget_bytes && sink::peek(&v)) {
    if (s_session || s_closing) {
      if (!s_opened || s_error_mode) return;  // keep data in the sink (BUFFER TEMPORAL)
      if (!s_w.append(v.hdr, v.data, rtc_ms(), sys::ms())) { enter_error("write"); return; }
    } else if (s_pre_cap) {
      uint64_t min_us = sys::us() > (uint64_t)s_pre_s * 1000000ull ? sys::us() - (uint64_t)s_pre_s * 1000000ull : 0;
      s_pre.push_evict(v.hdr, v.data, min_us, nullptr);
    }
    moved += REC_HDR + v.hdr.len;
    sink::pop();
    if ((moved & 0xFFFF) < (uint32_t)(REC_HDR + v.hdr.len)) esp_task_wdt_reset();  // long drains (closing, after a stall)
  }
}

static void periodic_flush() {
  if (!(s_session || s_closing) || !s_opened || s_error_mode) return;
  uint32_t now = sys::ms();
  if (now - s_last_flush < s_cfg.flush_ms && s_w.pending_bytes() < BLOCK_PAYLOAD / 2) return;
  bool sync = now - s_last_sync >= s_cfg.fsync_ms;
  uint32_t t0 = sys::ms();
  if (!s_w.flush(sync, rtc_ms(), now)) { enter_error("flush"); return; }
  uint32_t dt = sys::ms() - t0;
  if (dt > s_max_write) s_max_write = dt;
  s_last_flush = now;
  s_last_write_ok = now;
  if (sync) s_last_sync = now;
  // segment rotation
  if (s_w.file_bytes() >= (uint64_t)s_cfg.segment_mb * 1024ull * 1024ull) {
    s_meta.total_bytes += s_w.file_bytes();
    uint32_t next = s_w.next_block_seq();
    s_w.close(false, rtc_ms(), now);
    if (!open_segment((uint16_t)(s_seg + 1), next, 0)) enter_error("rotate");
  }
  if (now - s_last_meta >= 10000) {
    s_last_meta = now;
    s_meta.last_block_seq = s_w.next_block_seq() - 1;
    s_meta.last_rtc_ms = rtc_ms();
    session_meta_write(s_dir, &s_meta);
  }
}

// ---------------------------------------------------------------- recovery scan
static void scan_interrupted() {
  s_recovery = RecoveryInfo();
  DIR* d = opendir(ROOT);
  if (!d) return;
  uint32_t sessions = 0;
  struct dirent* e;
  while ((e = readdir(d)) != nullptr) {
    if (e->d_name[0] != 'S' || strlen(e->d_name) > 23) continue;  // not an AVO session directory
    sessions++;
    char dir[96];
    snprintf(dir, sizeof(dir), "%s/%.23s", ROOT, e->d_name);
    SessionMetaFile m;
    if (!session_meta_read(dir, &m) || m.state != SessionFileState::OPEN) continue;
    // find the last existing segment
    uint16_t last = 0;
    char path[128];
    for (uint16_t sgm = 1; sgm < 1000; sgm++) {
      seg_path(dir, sgm, path, sizeof(path));
      struct stat st;
      if (stat(path, &st) != 0) break;
      last = sgm;
    }
    RawScanResult r;
    bool trunc = false;
    uint32_t cut = 0;
    if (last) {
      seg_path(dir, last, path, sizeof(path));
      if (raw_recover(path, s_scan, SCAN_BUF, &r, &trunc)) {
        cut = (uint32_t)(r.file_size - r.valid_end);
        m.last_block_seq = r.blocks ? r.last_block_seq : m.last_block_seq;
        if (r.last_rtc_ms) m.last_rtc_ms = r.last_rtc_ms;
      }
    }
    bb::log(BbCode::SESSION_RECOVERED, 1, cut, last, e->d_name);
    // The most recent interrupted session is a resume candidate; older ones are closed.
    if (!s_recovery.found || strcmp(e->d_name, s_recovery.session_id) > 0) {
      if (s_recovery.found) close_recovered(s_recovery.session_id);
      s_recovery.found = true;
      strncpy(s_recovery.session_id, e->d_name, sizeof(s_recovery.session_id) - 1);
      s_recovery.segments = last;
      s_recovery.last_block_seq = m.last_block_seq;
      s_recovery.active_ms = m.active_ms;
      s_recovery.start_reason = m.start_reason;
      s_recovery.manual = m.manual;
      s_recovery.truncated_bytes = cut;
      uint64_t now = sys::wall_ms();
      s_recovery.resumable = now && m.last_rtc_ms && now >= m.last_rtc_ms &&
                             (now - m.last_rtc_ms) <= (uint64_t)s_cfg.resume_window_s * 1000ull && last > 0;
      session_meta_write(dir, &m);
    } else {
      m.state = SessionFileState::CLOSED_RECOVERED;
      session_meta_write(dir, &m);
    }
  }
  closedir(d);
  appstate::update([&](AppSnapshot& s) {
    s.storage.sessions_on_card = sessions;
    s.storage.recovered_sessions += s_recovery.found ? 1 : 0;
  });
}

// ---------------------------------------------------------------- file services
static void reply(const FileReq& r, BleStatus st, const uint8_t* d, size_t n, bool last) {
  if (s_file_cb) s_file_cb(r, (uint8_t)st, d, n, last);
}

static bool session_dir(const char* id, char* out, size_t cap) {
  if (!id[0] || strchr(id, '/') || strstr(id, "..")) return false;
  snprintf(out, cap, "%s/%s", ROOT, id);
  struct stat st;
  return stat(out, &st) == 0;
}

static void op_list(const FileReq& r) {
  DIR* d = opendir(ROOT);
  if (!d) { reply(r, BleStatus::IO_ERROR, nullptr, 0, true); return; }
  static uint8_t out[1800];
  ByteWriter w(out, sizeof(out));
  w.u16(r.page);
  size_t count_at = w.size();
  w.u8(0);
  uint8_t n = 0;
  int idx = 0;
  bool more = false;
  struct dirent* e;
  while ((e = readdir(d)) != nullptr) {
    if (e->d_name[0] != 'S' || strlen(e->d_name) > 23) continue;
    if (idx++ < r.page * 20) continue;
    if (n >= 20) { more = true; break; }
    char dir[96];
    snprintf(dir, sizeof(dir), "%s/%.23s", ROOT, e->d_name);
    SessionMetaFile m;
    bool ok = session_meta_read(dir, &m);
    w.str(e->d_name, 24);
    w.u8(ok ? (uint8_t)m.state : 0);
    w.u16(ok ? m.segments : 0);
    w.u64(ok ? m.total_bytes : 0);
    w.u64(ok ? m.start_rtc_ms : 0);
    w.u32(ok ? m.active_ms : 0);
    w.u8(s_session && strcmp(e->d_name, s_sp.session_id) == 0 ? 1 : 0);
    n++;
  }
  closedir(d);
  out[count_at] = n;
  w.u8(more ? 1 : 0);
  reply(r, BleStatus::OK, out, w.size(), true);
}

static void op_read(const FileReq& r) {
  char dir[96], path[128];
  if (!session_dir(r.session_id, dir, sizeof(dir))) { reply(r, BleStatus::NOT_FOUND, nullptr, 0, true); return; }
  seg_path(dir, r.segment ? r.segment : 1, path, sizeof(path));
  FILE* f = fopen(path, "rb");
  if (!f) { reply(r, BleStatus::NOT_FOUND, nullptr, 0, true); return; }
  fseek(f, 0, SEEK_END);
  long size = ftell(f);
  if ((long)r.offset > size) { fclose(f); reply(r, BleStatus::BAD_FORMAT, nullptr, 0, true); return; }
  fseek(f, (long)r.offset, SEEK_SET);
  // V3.5.4 SD FIX: keep a response below the BLE notification burst limit.
  // Android advances by the received data length and keeps CRC/offset resume.
  static uint8_t buf[2048 + 12];
  uint32_t len = r.length > 2048 ? 2048 : r.length;
  size_t got = fread(buf + 12, 1, len, f);
  fclose(f);
  put_u32(buf, r.offset);
  put_u32(buf + 4, (uint32_t)size);
  put_u32(buf + 8, crc32(buf + 12, got));
  bool eof = (long)(r.offset + got) >= size;
  reply(r, BleStatus::OK, buf, got + 12, eof);
}

static void sha_start(const FileReq& r, bool for_upload) {
  char dir[96];
  if (!session_dir(r.session_id, dir, sizeof(dir))) { reply(r, BleStatus::NOT_FOUND, nullptr, 0, true); return; }
  if (s_session && strcmp(r.session_id, s_sp.session_id) == 0) { reply(r, BleStatus::STATE_CONFLICT, nullptr, 0, true); return; }
  if (s_sha.active) { reply(r, BleStatus::BUSY, nullptr, 0, true); return; }
  s_sha.active = true;
  s_sha.req = r;
  s_sha.seg = 1;
  s_sha.off = 0;
  s_sha.for_upload = for_upload;
  mbedtls_sha256_init(&s_sha.ctx);
  mbedtls_sha256_starts(&s_sha.ctx, 0);
}

// Hashes up to 64 KB per call (keeps the writer responsive).
static void sha_step() {
  if (!s_sha.active) return;
  char dir[96], path[128];
  snprintf(dir, sizeof(dir), "%s/%s", ROOT, s_sha.req.session_id);
  seg_path(dir, s_sha.seg, path, sizeof(path));
  FILE* f = fopen(path, "rb");
  if (!f) {
    // past the last segment: done
    uint8_t h[32];
    mbedtls_sha256_finish(&s_sha.ctx, h);
    mbedtls_sha256_free(&s_sha.ctx);
    s_sha.active = false;
    if (!s_sha.for_upload) { reply(s_sha.req, BleStatus::OK, h, 32, true); return; }
    if (memcmp(h, s_sha.req.sha256, 32) != 0) { reply(s_sha.req, BleStatus::VERIFY_FAILED, h, 32, true); return; }
    SessionMetaFile m;
    if (!session_meta_read(dir, &m)) { reply(s_sha.req, BleStatus::IO_ERROR, nullptr, 0, true); return; }
    m.state = SessionFileState::UPLOADED;
    memcpy(m.sha256, h, 32);
    bool ok = session_meta_write(dir, &m);
    reply(s_sha.req, ok ? BleStatus::OK : BleStatus::IO_ERROR, h, 32, true);
    return;
  }
  fseek(f, (long)s_sha.off, SEEK_SET);
  size_t n = fread(s_scan, 1, 64 * 1024, f);
  fclose(f);
  if (n) mbedtls_sha256_update(&s_sha.ctx, s_scan, n);
  if (n < 64 * 1024) { s_sha.seg++; s_sha.off = 0; } else { s_sha.off += n; }
}

static int rm_tree(const char* dir) {
  DIR* d = opendir(dir);
  if (!d) return -1;
  struct dirent* e;
  char p[384];
  int fails = 0;
  while ((e = readdir(d)) != nullptr) {
    if (!strcmp(e->d_name, ".") || !strcmp(e->d_name, "..")) continue;
    snprintf(p, sizeof(p), "%.96s/%.255s", dir, e->d_name);
    if (unlink(p) != 0) fails++;
  }
  closedir(d);
  if (rmdir(dir) != 0) fails++;
  return fails;
}

static void handle_file(const FileReq& r) {
  if (!s_mounted) { reply(r, BleStatus::IO_ERROR, nullptr, 0, true); return; }
  switch (r.op) {
    case FileOp::LIST: op_list(r); break;
    case FileOp::READ: op_read(r); break;
    case FileOp::SHA256: sha_start(r, false); break;
    case FileOp::MARK_UPLOADED: sha_start(r, true); break;
    case FileOp::DELETE_PREPARE: {
      char dir[96];
      if (!session_dir(r.session_id, dir, sizeof(dir))) { reply(r, BleStatus::NOT_FOUND, nullptr, 0, true); break; }
      s_del_token = esp_random() | 1u;
      s_del_until = sys::ms() + 60000;
      strncpy(s_del_id, r.session_id, sizeof(s_del_id) - 1);
      uint8_t b[4];
      put_u32(b, s_del_token);
      reply(r, BleStatus::OK, b, 4, true);
      break;
    }
    case FileOp::DELETE_COMMIT: {
      char dir[96];
      if (!session_dir(r.session_id, dir, sizeof(dir))) { reply(r, BleStatus::NOT_FOUND, nullptr, 0, true); break; }
      if (r.token == 0 || r.token != s_del_token || strcmp(s_del_id, r.session_id) != 0 || (int32_t)(sys::ms() - s_del_until) > 0) {
        reply(r, BleStatus::NOT_ALLOWED, nullptr, 0, true); break;
      }
      if ((s_session || s_closing) && strcmp(r.session_id, s_sp.session_id) == 0) { reply(r, BleStatus::STATE_CONFLICT, nullptr, 0, true); break; }
      SessionMetaFile m;
      bool uploaded = session_meta_read(dir, &m) && m.state == SessionFileState::UPLOADED;
      if (!uploaded && !r.force) { reply(r, BleStatus::NOT_ALLOWED, nullptr, 0, true); break; }  // protect not-uploaded data
      s_del_token = 0;
      int fails = rm_tree(dir);
      reply(r, fails ? BleStatus::IO_ERROR : BleStatus::OK, nullptr, 0, true);
      break;
    }
  }
}

// ---------------------------------------------------------------- task
static void publish_status() {
  RecStatus rs = RecStatus::IDLE;
  uint32_t fill = sink::fill_permille();
  if (s_session || s_closing) {
    if (!s_mounted || s_error_mode || !s_opened) rs = fill > 900 ? RecStatus::REC_ERROR : RecStatus::TEMP_BUFFER;
    else if (sys::ms() - s_last_write_ok > (uint32_t)s_cfg.flush_ms * 4 + 3000) rs = RecStatus::TEMP_BUFFER;
    else rs = RecStatus::RECORDING;
  }
  uint64_t t0 = 0, t1 = 0;
  s_pre.oldest_time(&t0);
  s_pre.newest_time(&t1);
  appstate::update([&](AppSnapshot& s) {
    s.storage.mounted = s_mounted;
    s.storage.rec = rs;
    strncpy(s.storage.session_id, (s_session || s_closing) ? s_sp.session_id : "", sizeof(s.storage.session_id) - 1);
    s.storage.segment = s_seg;
    s.storage.session_bytes = s_meta.total_bytes + s_w.file_bytes();
    s.storage.blocks = s_w.blocks_written();
    s.storage.last_write_ms = s_last_write_ok;
    s.storage.write_errors = s_write_err;
    s.storage.remounts = s_remounts;
    s.storage.ring_fill_permille = fill;
    s.storage.ring_peak_permille = sink::peak_permille();
    s.storage.dropped_records = sink::dropped_total();
    s.storage.dropped_low = sink::dropped_low();
    s.storage.prebuf_records = s_pre.count();
    s.storage.prebuf_span_ms = (t1 > t0) ? (uint32_t)((t1 - t0) / 1000) : 0;
    s.storage.prebuf_target_s = s_pre_s;
    s.storage.prebuf_capacity = (uint32_t)s_pre_cap;
    s.storage.max_write_ms = s_max_write;
  });
}

static void task(void*) {
  esp_task_wdt_add(nullptr);
  Cmd* c = (Cmd*)heap_caps_malloc(sizeof(Cmd), MALLOC_CAP_SPIRAM);
  uint32_t last_space = 0;
  for (;;) {
    ulTaskNotifyTake(pdTRUE, pdMS_TO_TICKS(50));
    while (xQueueReceive(s_q, c, 0) == pdTRUE) {
      switch (c->type) {
        case CmdType::START: {
          if (s_session || s_closing) break;  // never two sessions
          cfgstore::get(&s_cfg);
          drain(UINT32_MAX);  // everything that arrived before START goes to the pre-buffer first
          s_sp = c->start;
          s_session = true;
          s_error_mode = false;
          s_opened = false;
          s_dir_created = false;
          s_seg = 0;
          s_meta = SessionMetaFile();
          s_last_write_ok = sys::ms();
          if (!s_mounted) s_mounted = mount();
          if (s_mounted && !open_session_files()) enter_error("open");
          if (!s_mounted) s_error_mode = true;
          break;
        }
        case CmdType::STOP:
          if (!s_session) break;
          drain(UINT32_MAX);
          s_close_metrics = c->metrics;
          s_close_clean = c->clean;
          s_close_rec_done = false;
          s_closing = true;
          s_session = false;
          if (s_opened && !s_error_mode) finish_close();
          break;
        case CmdType::CLOSE_RECOVERED: {
          char dir[96];
          if (s_mounted && session_dir(c->file.session_id, dir, sizeof(dir))) {
            SessionMetaFile m;
            if (session_meta_read(dir, &m)) { m.state = SessionFileState::CLOSED_RECOVERED; session_meta_write(dir, &m); }
          }
          break;
        }
        case CmdType::FLUSH:
          if (s_opened && !s_error_mode && !s_w.flush(true, rtc_ms(), sys::ms())) enter_error("flush");
          break;
        case CmdType::SHUTDOWN:
          drain(UINT32_MAX);
          if (s_opened && !s_error_mode) {
            if (s_closing) finish_close();
            else if (s_w.is_open()) s_w.flush(true, rtc_ms(), sys::ms());
          }
          xSemaphoreGive(s_done);
          break;
        case CmdType::FILE:
          handle_file(c->file);
          break;
      }
    }
    if (s_error_mode || !s_mounted) try_recover_card();
    if (s_closing && s_opened && !s_error_mode) finish_close();
    drain(256 * 1024);
    periodic_flush();
    sha_step();
    uint32_t now = sys::ms();
    if (now - s_last_status >= 250) { s_last_status = now; publish_status(); }
    if (now - last_space >= 30000) { last_space = now; update_card_space(); }
    esp_task_wdt_reset();
  }
}

bool init() {
  s_q = xQueueCreate(16, sizeof(Cmd));
  s_done = xSemaphoreCreateBinary();
  s_block = (uint8_t*)heap_caps_malloc(RAW_BLOCK_HDR + BLOCK_PAYLOAD, MALLOC_CAP_INTERNAL | MALLOC_CAP_DMA);
  if (!s_block) s_block = (uint8_t*)heap_caps_malloc(RAW_BLOCK_HDR + BLOCK_PAYLOAD, MALLOC_CAP_SPIRAM);
  s_scan = (uint8_t*)heap_caps_malloc(SCAN_BUF, MALLOC_CAP_SPIRAM);
  if (!s_q || !s_block || !s_scan) return false;
  s_w.attach_buffer(s_block, BLOCK_PAYLOAD);
  cfgstore::get(&s_cfg);
  alloc_prebuffer();
  s_mounted = mount();
  if (s_mounted) {
    update_card_space();
    scan_interrupted();
  } else {
    bb::log(BbCode::SD_ERROR, 2, 0, 0, "no card at boot");
  }
  publish_status();
  xTaskCreatePinnedToCore(task, "storage", 8192, nullptr, 12, &s_task, 1);
  sink::set_writer_task(s_task);
  return s_mounted;
}

bool recovery_info(RecoveryInfo* out) { *out = s_recovery; return s_recovery.found; }

static bool post(Cmd& c, uint32_t to = 100) {
  bool ok = s_q && xQueueSend(s_q, &c, pdMS_TO_TICKS(to)) == pdTRUE;
  if (ok && s_task) xTaskNotifyGive(s_task);
  return ok;
}

bool start_session(const StartParams& p) {
  Cmd c = Cmd();
  c.type = CmdType::START;
  c.start = p;
  return post(c);
}

bool stop_session(const SessionMetrics& m, bool clean) {
  Cmd c = Cmd();
  c.type = CmdType::STOP;
  c.metrics = m;
  c.clean = clean;
  return post(c, 500);
}

bool close_recovered(const char* id) {
  if (!s_task) {  // during init (called from the storage init path)
    char dir[96];
    if (session_dir(id, dir, sizeof(dir))) {
      SessionMetaFile m;
      if (session_meta_read(dir, &m)) { m.state = SessionFileState::CLOSED_RECOVERED; session_meta_write(dir, &m); }
    }
    return true;
  }
  Cmd c = Cmd();
  c.type = CmdType::CLOSE_RECOVERED;
  strncpy(c.file.session_id, id, sizeof(c.file.session_id) - 1);
  return post(c);
}

bool flush_now() {
  Cmd c = Cmd();
  c.type = CmdType::FLUSH;
  return post(c);
}

bool shutdown(uint32_t timeout_ms) {
  Cmd c = Cmd();
  c.type = CmdType::SHUTDOWN;
  xSemaphoreTake(s_done, 0);
  if (!post(c, timeout_ms)) return false;
  return xSemaphoreTake(s_done, pdMS_TO_TICKS(timeout_ms)) == pdTRUE;
}

bool session_active() { return s_session; }
void set_file_callback(FileRespCb cb) { s_file_cb = cb; }

bool file_request(const FileReq& r) {
  Cmd c = Cmd();
  c.type = CmdType::FILE;
  c.file = r;
  return post(c, 50);
}

}  // namespace storage
