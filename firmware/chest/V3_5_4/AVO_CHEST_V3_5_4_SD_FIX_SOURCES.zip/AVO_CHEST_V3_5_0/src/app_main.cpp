// Boot sequence and task creation.
#include "app_main.h"
#include <Arduino.h>
#include <esp_task_wdt.h>
#include <esp_heap_caps.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "app_state.h"
#include "board_pins.h"
#include "services.h"
#include "sys_util.h"
#include "build_info.h"

using namespace avo;

TaskHandle_t g_task_handles[TID_COUNT] = {nullptr};
bool g_safe_mode = false;

static void boot_log(const char* step, bool ok) {
  Serial.printf("[AVO] %-10s %s\n", step, ok ? "OK" : "FAIL");
}

void app_setup() {
  Serial.begin(115200);  // USB CDC (GPIO19/20), never the link UART
  appstate::init();
  sys::identity_init();

  bool cfg_corrupt = false;
  bool cfg_ok = cfgstore::init(&cfg_corrupt);
  Config* pcfg = new Config();
  cfgstore::get(pcfg);
  const uint32_t uart_baud = pcfg->uart_baud;
  delete pcfg;
  boot_log("config", cfg_ok);

  bool sink_ok = sink::init(2 * 1024 * 1024);
  boot_log("sink", sink_ok);
  bool bb_ok = bb::init();
  boot_log("blackbox", bb_ok);

  // Crash-loop protection: never hide failures behind endless restarts.
  int rr = sys::reset_reason_code();
  bool crash = rr == ESP_RST_PANIC || rr == ESP_RST_INT_WDT || rr == ESP_RST_TASK_WDT || rr == ESP_RST_WDT || rr == ESP_RST_BROWNOUT;
  uint32_t crashes = 0;
  sys::nvs_get_u32("crash", &crashes);
  crashes = crash ? crashes + 1 : 0;
  sys::nvs_set_u32("crash", crashes);
  g_safe_mode = crashes >= 3;
  bb::log(BbCode::BOOT, 0, sys::boot_count(), (uint32_t)rr, sys::reset_reason_str());
  if (rr == ESP_RST_TASK_WDT || rr == ESP_RST_INT_WDT || rr == ESP_RST_WDT) bb::log(BbCode::WATCHDOG, 2, (uint32_t)rr);
  if (rr == ESP_RST_PANIC) bb::log(BbCode::PANIC, 2);
  if (rr == ESP_RST_BROWNOUT) bb::log(BbCode::BROWNOUT, 2);
  if (cfg_corrupt) bb::log(BbCode::CONFIG_CORRUPT, 2, 0, 0, "config defaults");
  appstate::update([&](AppSnapshot& s) {
    s.sys.boot = sys::boot_count();
    s.sys.reset_reason = sys::reset_reason_str();
    s.sys.safe_mode = g_safe_mode;
  });

  bool i2c_ok = board::i2c_init();
  boot_log("i2c", i2c_ok);
  bool pmu_ok = board::pmu_init();
  if (pmu_ok) board::pmu_configure_power_key();
  boot_log("pmu", pmu_ok);
  uint64_t rtc_s = 0;
  bool rtc_valid = false;
  if (board::rtc_read_unix(&rtc_s, &rtc_valid) && rtc_valid) sys::wall_set(rtc_s * 1000ull, sys::TimeSource::RTC);
  boot_log("rtc", rtc_valid);

  bool rtcm_ok = rtcm::init(16 * 1024);
  bool link_ok = uartlink::init(uart_baud);
  boot_log("uart", rtcm_ok && link_ok);

  bool sd_ok = storage::init();
  boot_log("storage", sd_ok);
  // In safe mode (>= 3 consecutive crash resets) ctl::init does not resume an
  // interrupted session automatically: it is closed as recovered instead.

  // V3.3.4: initialize BLE before control/UI allocate their task stacks and
  // graphics resources. Storage and RTCM/UART are already initialized.
  // This is a diagnostic change, not a guaranteed fix for ESP_ERR_NO_MEM.
  Serial.printf("[AVO MEM] before BLE internal=%u largest=%u psram=%u\n",
                (unsigned)heap_caps_get_free_size(MALLOC_CAP_INTERNAL | MALLOC_CAP_8BIT),
                (unsigned)heap_caps_get_largest_free_block(MALLOC_CAP_INTERNAL | MALLOC_CAP_8BIT),
                (unsigned)ESP.getFreePsram());
  char name[24];
  snprintf(name, sizeof(name), "AVO_%04X", sys::device_id16());
  bool ble_ok = ble::init(name);
  boot_log("ble", ble_ok);
  Serial.printf("[AVO MEM] after BLE internal=%u largest=%u psram=%u\n",
                (unsigned)heap_caps_get_free_size(MALLOC_CAP_INTERNAL | MALLOC_CAP_8BIT),
                (unsigned)heap_caps_get_largest_free_block(MALLOC_CAP_INTERNAL | MALLOC_CAP_8BIT),
                (unsigned)ESP.getFreePsram());
  bool ctl_ok = ctl::init();
  boot_log("control", ctl_ok);
  bool ui_ok = ui::init();
  boot_log("ui", ui_ok);

  // SD fsync on a slow card can exceed the default 5 s; 10 s still catches real hangs.
  esp_task_wdt_config_t wdt = {};
  wdt.timeout_ms = 10000;
  wdt.idle_core_mask = 0;
  wdt.trigger_panic = true;
  esp_task_wdt_reconfigure(&wdt);
  Serial.printf("[AVO] build fingerprint %s\n", AVO_BUILD_FINGERPRINT);
  Serial.printf("[AVO] %s %s ready (boot #%lu, reset %s%s)\n", AVO_FW_NAME, AVO_FW_VERSION,
                (unsigned long)sys::boot_count(), sys::reset_reason_str(), g_safe_mode ? ", SAFE MODE" : "");
}

void app_loop() {
  // Every function runs in its own FreeRTOS task; the Arduino loop task is idle.
  vTaskDelay(pdMS_TO_TICKS(1000));
}
