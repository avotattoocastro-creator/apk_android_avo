// BLE GATT server using standalone NimBLE-Arduino 2.5.1 (h2zero).
// AVO BLE PROTOCOL v1: see PROTOCOL_BLE.md.
// V3.4.4: "Just Works" LE Secure Connections bonding (no PIN: the four-band
// display cannot show one) + application-level authorization (CLAIM with the
// BOOT button, then HMAC-SHA256 challenge-response on every connection).
// Telemetry v2 (appended fields), REBOOT command, extended GET_INFO / DIAG.
#include <Arduino.h>
#include <NimBLEDevice.h>
#include <esp_heap_caps.h>
#include <esp_random.h>
#include "freertos/semphr.h"
#include "freertos/FreeRTOS.h"
#include "freertos/message_buffer.h"
#include "freertos/queue.h"
#include "freertos/task.h"
#include "app_state.h"
#include "services.h"
#include "sys_util.h"
#include "build_info.h"

using namespace avo;

extern TaskHandle_t g_task_handles[TID_COUNT];

namespace ble {

#define AVO_SVC_UUID "7a5e0001-4156-4f50-8e1f-3c0de5a1c0a3"
#define AVO_INFO_UUID "7a5e0002-4156-4f50-8e1f-3c0de5a1c0a3"
#define AVO_CTRL_RX_UUID "7a5e0003-4156-4f50-8e1f-3c0de5a1c0a3"
#define AVO_CTRL_TX_UUID "7a5e0004-4156-4f50-8e1f-3c0de5a1c0a3"
#define AVO_TELEM_UUID "7a5e0005-4156-4f50-8e1f-3c0de5a1c0a3"
#define AVO_RTCM_UUID "7a5e0006-4156-4f50-8e1f-3c0de5a1c0a3"
#define AVO_FILE_TX_UUID "7a5e0007-4156-4f50-8e1f-3c0de5a1c0a3"

enum Chan : uint8_t { CH_CTRL = 0, CH_TELEM = 1, CH_FILE = 2 };

static NimBLEServer* s_srv = nullptr;
static NimBLECharacteristic *s_info = nullptr, *s_ctrl_rx = nullptr, *s_ctrl_tx = nullptr, *s_telem = nullptr, *s_rtcm = nullptr, *s_file = nullptr;
static QueueHandle_t s_rxq = nullptr;
static StaticQueue_t s_rxq_meta;
static uint8_t* s_rxq_storage = nullptr;          // raw request fragments
static MessageBufferHandle_t s_txmb = nullptr; // outgoing messages
static volatile bool s_connected = false;
static volatile uint16_t s_conn = 0xFFFF;
static volatile uint16_t s_mtu = 23;
static volatile bool s_encrypted = false;
static volatile int s_notify_rc = 0;
static uint16_t s_tx_msg_id = 0x8000;
static bool s_require_bond = true;
static BleReassembler* s_reasm = nullptr;
static uint32_t s_rtcm_seq_expected = 0;
static bool s_rtcm_have_seq = false;

struct RxFrag { uint16_t len; uint8_t d[512]; };

// ------------------------------------------------------------------ authorization (V3.4.4)
static AuthManager* s_auth = nullptr;
static SemaphoreHandle_t s_auth_mtx = nullptr;
static volatile bool s_authorized = false;   // mirror readable from the NimBLE host task

static void auth_random(uint8_t* out, size_t n) { esp_fill_random(out, n); }
static bool auth_save(const AuthStore& st) {
  uint8_t b[AUTH_STORE_MAX];
  size_t n = auth_store_serialize(st, b, sizeof(b));
  return n && sys::nvs_set_blob("blekeys", b, n);
}
static void auth_lock() { xSemaphoreTake(s_auth_mtx, portMAX_DELAY); }
static void auth_unlock() { xSemaphoreGive(s_auth_mtx); }
static void auth_publish() {
  uint32_t now = sys::ms();
  bool a = s_auth->authorized() || !s_require_bond;
  bool cp = s_auth->claim_pending(now);
  uint8_t k = s_auth->key_count();
  s_authorized = a;
  appstate::update([&](AppSnapshot& x) { x.ble.authorized = a; x.ble.claim_pending = cp; x.ble.auth_keys = k; });
}
static bool is_authorized() { return s_authorized || !s_require_bond; }

bool claim_pending() {
  if (!s_auth) return false;
  auth_lock();
  bool r = s_auth->claim_pending(sys::ms());
  auth_unlock();
  return r;
}
bool claim_confirm() {
  if (!s_auth) return false;
  auth_lock();
  bool r = s_auth->claim_confirm(sys::ms());
  auth_publish();
  auth_unlock();
  return r;
}

// ------------------------------------------------------------------ outgoing
// Message buffer item: chan u8 | type u8 | msg_id u16 | flags u8 | status u8 | payload
static bool queue_msg(Chan ch, BleMsg type, uint16_t msg_id, uint8_t flags, uint8_t status, const uint8_t* p, size_t n, uint32_t to_ms = 50) {
  if (!s_txmb || !s_connected) return false;
  size_t total = 6 + n;
  uint8_t* tmp = (uint8_t*)heap_caps_malloc(total, MALLOC_CAP_SPIRAM);
  if (!tmp) return false;
  tmp[0] = ch; tmp[1] = (uint8_t)type; put_u16(tmp + 2, msg_id); tmp[4] = flags; tmp[5] = status;
  if (n) memcpy(tmp + 6, p, n);
  bool ok = xMessageBufferSend(s_txmb, tmp, total, pdMS_TO_TICKS(to_ms)) == total;
  free(tmp);
  return ok;
}

static void respond(BleMsg type, uint16_t id, BleStatus st, const uint8_t* p = nullptr, size_t n = 0) {
  queue_msg(CH_CTRL, type, id, BF_RESPONSE | (st != BleStatus::OK ? BF_ERROR : 0), (uint8_t)st, p, n);
}

static bool notify_frag(NimBLECharacteristic* c, const uint8_t* d, size_t n) {
  for (int attempt = 0; attempt < 50; attempt++) {
    if (!s_connected) return false;
    c->setValue(d, n);
    if (c->notify()) return true;
    vTaskDelay(pdMS_TO_TICKS(attempt < 10 ? 2 : 10));  // host buffers full: back off
  }
  appstate::update([](AppSnapshot& s) { s.ble.notify_fail++; });
  return false;
}

static void tx_task(void*) {
  uint8_t* msg = (uint8_t*)heap_caps_malloc(20000, MALLOC_CAP_SPIRAM);
  uint8_t frag[520];
  uint32_t last_tel = 0, last_rtcm_ack = 0, last_auth_pub = 0;
  for (;;) {
    size_t n = xMessageBufferReceive(s_txmb, msg, 20000, pdMS_TO_TICKS(50));
    if (n >= 6 && s_connected) {
      Chan ch = (Chan)msg[0];
      BleMsg type = (BleMsg)msg[1];
      uint16_t id = get_u16(msg + 2);
      uint8_t flags = msg[4], status = msg[5];
      const uint8_t* p = msg + 6;
      size_t plen = n - 6;
      size_t att = s_mtu > 3 ? s_mtu - 3 : 20;
      if (att > sizeof(frag)) att = sizeof(frag);
      uint16_t cnt = ble_frag_count(plen, att);
      size_t per = att - BLE_FRAG_OVERHEAD;
      NimBLECharacteristic* c = ch == CH_TELEM ? s_telem : ch == CH_FILE ? s_file : s_ctrl_tx;
      for (uint16_t i = 0; i < cnt; i++) {
        size_t off = (size_t)i * per;
        size_t len = plen - off < per ? plen - off : per;
        size_t fl = ble_frag_build(type, id, i, cnt, flags, status, p + off, len, frag, sizeof(frag));
        if (!fl || !notify_frag(c, frag, fl)) break;
      }
      appstate::update([](AppSnapshot& s) { s.ble.tx_msgs++; });
    }
    uint32_t now = sys::ms();
    if (s_connected && is_authorized() && now - last_tel >= 500) {
      last_tel = now;
      AppSnapshot* s = new AppSnapshot();
      appstate::get(s);
      const GnssSample& g = s->gnss.s;
      Telemetry t;
      t.session_state = (uint8_t)s->session.st; t.gf_state = (uint8_t)s->session.gf; t.rec_status = (uint8_t)s->storage.rec;
      t.fix_type = g.fix_type; t.carr_soln = g.carr_soln(); t.num_sv = g.num_sv; t.hacc_mm = g.hacc_mm;
      t.lat_e7 = g.lat_e7; t.lon_e7 = g.lon_e7; t.gspeed_mm_s = g.gspeed_mm_s;
      t.distance_cm = (uint32_t)(s->session.metrics.distance_m * 100); t.active_ms = s->session.metrics.active_ms;
      t.batt_pct = (int8_t)s->power.pmu.batt_pct; t.link_connected = s->link.connected; t.girth_connected = s->girth.connected;
      t.rtcm_flowing = s->rtcm.flowing; t.ring_fill_permille = (uint16_t)s->storage.ring_fill_permille;
      t.dropped_records = s->storage.dropped_records; t.pending_ms = s->session.pending_ms; t.inhibited = s->session.inhibited;
      // ---- v2 (V3.4.4): appended fields, older apps ignore them
      t.gnss_flags = (uint8_t)((g.gnss_fix_ok() ? 1 : 0) | (g.diff_soln() ? 2 : 0) | (g.invalid_llh() ? 4 : 0) |
                               (s->gnss.have ? 8 : 0) | (s->gnss.quality_ok ? 16 : 0));
      t.corr_age_code = g.corr_age_code(); t.sd_mounted = s->storage.mounted;
      t.pps_state = s->link.status_valid ? s->link.back.pps_state : 0xFF;
      t.back_batt_mv = s->link.status_valid ? s->link.back.back_batt_mv : 0; t.time_source = s->sys.time_source;
      t.back_status_valid = s->link.status_valid; t.rtcm_to_back_bytes = s->rtcm.sent_to_back_bytes;
      t.rxm_rtcm_used = s->link.back.rxm_rtcm_used; t.power_level = (uint8_t)s->power.level; t.vbus = s->power.pmu.vbus;
      t.batt_mv = s->power.pmu.batt_mv; t.gnss_age_ms = s->gnss.have ? (uint32_t)(now - s->gnss.rx_ms) : 0xFFFFFFFFu;
      t.vacc_mm = g.vacc_mm; t.link_age_ms = s->link.last_rx_ms ? now - s->link.last_rx_ms : 0xFFFFFFFFu;
      t.manual = s->session.manual; t.girth_present = s->girth.connected ? 1 : 0; t.girth_lost = s->girth.seq_lost;
      delete s;
      uint8_t b[TELEMETRY_V2_LEN + 8];
      size_t tl = encode_telemetry(t, b, sizeof(b));
      if (tl) queue_msg(CH_TELEM, BleMsg::TELEMETRY, s_tx_msg_id++, 0, 0, b, tl, 0);
    }
    if (s_connected && is_authorized() && now - last_rtcm_ack >= 500) {
      last_rtcm_ack = now;
      // RTCM flow control: free space lets the phone throttle; expected seq reveals loss.
      uint8_t b[12];
      put_u32(b, (uint32_t)rtcm::free_space());
      put_u32(b + 4, s_rtcm_seq_expected);
      AppSnapshot* s = new AppSnapshot();
      appstate::get(s);
      put_u32(b + 8, s->rtcm.dropped_bytes);
      delete s;
      queue_msg(CH_CTRL, BleMsg::RTCM_ACK, s_tx_msg_id++, 0, 0, b, 12, 0);
    }
    if (s_auth && now - last_auth_pub >= 500) {  // claim window expiry -> UI band
      last_auth_pub = now;
      auth_lock(); auth_publish(); auth_unlock();
    }
    if (g_task_handles[TID_BLE_TX] == nullptr) g_task_handles[TID_BLE_TX] = xTaskGetCurrentTaskHandle();
  }
}

// ------------------------------------------------------------------ file responses (from storage task)
static void file_cb(const storage::FileReq& r, uint8_t status, const uint8_t* d, size_t n, bool last) {
  BleMsg t = BleMsg::ACK;
  Chan ch = CH_CTRL;
  switch (r.op) {
    case storage::FileOp::LIST: t = BleMsg::LIST_SESSIONS; break;
    case storage::FileOp::READ: t = BleMsg::FILE_DATA; ch = CH_FILE; break;
    case storage::FileOp::SHA256: t = BleMsg::FILE_SHA256; break;
    case storage::FileOp::MARK_UPLOADED: t = BleMsg::MARK_UPLOADED; break;
    case storage::FileOp::DELETE_PREPARE: t = BleMsg::DELETE_PREPARE; break;
    case storage::FileOp::DELETE_COMMIT: t = BleMsg::DELETE_COMMIT; break;
  }
  (void)last;
  queue_msg(ch, t, r.msg_id, BF_RESPONSE | (status ? BF_ERROR : 0), status, d, n, 500);
}

// ------------------------------------------------------------------ request dispatch
static bool sid(ByteReader& r, char out[24]) {
  r.str(out, 24);
  return r.ok() && out[0];
}

static void blackbox_visit(const BbRecord& rec, void* ctx) {
  ByteWriter* w = (ByteWriter*)ctx;
  w->u32(rec.seq); w->u32(rec.uptime_ms); w->u32(rec.rtc_s); w->u32(rec.boot); w->u16(rec.code); w->u8(rec.severity);
  w->u32(rec.arg0); w->u32(rec.arg1);
}

static bool open_message(BleMsg t) {
  return t == BleMsg::GET_INFO || t == BleMsg::AUTH_HELLO || t == BleMsg::AUTH_PROOF || t == BleMsg::CLAIM_BEGIN ||
         t == BleMsg::CLAIM_RESULT;
}

static void dispatch(BleMsg type, uint16_t id, const uint8_t* p, size_t n) {
  ByteReader r(p, n);
  if (!is_authorized() && !open_message(type)) { respond(type, id, BleStatus::AUTH_REQUIRED); return; }
  switch (type) {
    case BleMsg::GET_INFO: {
      uint8_t b[96];
      ByteWriter w(b, sizeof(b));
      w.u8(BLE_PROTO_VERSION); w.u8(AVO_UART_VERSION); w.u16(RAW_FORMAT_VERSION); w.u16(AVO_CONFIG_SCHEMA);
      w.str(AVO_FW_VERSION, 16); w.str(sys::device_id_hex(), 16); w.u32(sys::boot_count()); w.u16(s_mtu);
      // capabilities: b0..b6 status, sessions, config, fences, rtcm, files, ota;
      // V3.4.4: b7 app authorization, b8 telemetry v2, b9 REBOOT
      // V3.5.0: b10 ESP-NOW back link (BACK_LINK message + extended DIAG)
      w.u32(0x000007FF);
      auth_lock();
      uint8_t keys = s_auth->key_count();
      bool cp = s_auth->claim_pending(sys::ms());
      auth_unlock();
      w.u8(is_authorized() ? 1 : 0); w.u8(keys); w.u8(cp ? 1 : 0); w.u8(s_require_bond ? 1 : 0);
      w.str(AVO_BUILD_FINGERPRINT, 32);
      respond(type, id, BleStatus::OK, b, w.size());
      break;
    }
    case BleMsg::AUTH_HELLO: {
      uint8_t kid[8], pn[16], wn[16], wp[32];
      r.bytes(kid, 8); r.bytes(pn, 16);
      if (!r.ok()) { respond(type, id, BleStatus::BAD_FORMAT); break; }
      auth_lock();
      bool ok = s_auth->hello(kid, pn, wn, wp);
      auth_publish();
      auth_unlock();
      if (!ok) { respond(type, id, BleStatus::NOT_FOUND); break; }
      uint8_t b[48];
      memcpy(b, wn, 16); memcpy(b + 16, wp, 32);
      respond(type, id, BleStatus::OK, b, 48);
      break;
    }
    case BleMsg::AUTH_PROOF: {
      uint8_t pp[32];
      r.bytes(pp, 32);
      if (!r.ok()) { respond(type, id, BleStatus::BAD_FORMAT); break; }
      auth_lock();
      AuthManager::ProofResult pr = s_auth->proof(pp);
      auth_publish();
      auth_unlock();
      if (pr == AuthManager::PROOF_OK) { respond(type, id, BleStatus::OK); bb::log(BbCode::BLE_CONNECT, 0, 0xA0A0, s_conn, "app authorized"); }
      else {
        appstate::update([](AppSnapshot& a) { a.ble.auth_fail++; });
        bb::log(BbCode::BLE_AUTH_FAIL, 1, (uint32_t)pr, s_conn);
        respond(type, id, pr == AuthManager::PROOF_LOCKED ? BleStatus::BUSY : BleStatus::AUTH_REQUIRED);
      }
      break;
    }
    case BleMsg::CLAIM_BEGIN: {
      char name[24];
      r.str(name, 24);
      if (s_require_bond && !s_encrypted) { respond(type, id, BleStatus::AUTH_REQUIRED); break; }  // bond first
      auth_lock();
      bool ok = s_auth->claim_begin(sys::ms(), r.ok() ? name : "");
      auth_publish();
      auth_unlock();
      ui::wake();
      uint8_t b[2];
      put_u16(b, (uint16_t)(AUTH_CLAIM_WINDOW_MS / 1000));
      respond(type, id, ok ? BleStatus::OK : BleStatus::STATE_CONFLICT, b, 2);
      break;
    }
    case BleMsg::CLAIM_RESULT: {
      uint8_t kid[8], key[32];
      auth_lock();
      AuthManager::ClaimResult cr = s_auth->claim_result(sys::ms(), kid, key);
      auth_publish();
      auth_unlock();
      if (cr == AuthManager::CLAIM_DONE) {
        uint8_t b[40];
        memcpy(b, kid, 8); memcpy(b + 8, key, 32);
        respond(type, id, BleStatus::OK, b, 40);
        memset(key, 0, sizeof(key));
        memset(b, 0, sizeof(b));
      } else if (cr == AuthManager::CLAIM_PENDING) respond(type, id, BleStatus::BUSY);
      else if (cr == AuthManager::CLAIM_EXPIRED) respond(type, id, BleStatus::TIMEOUT);
      else if (cr == AuthManager::CLAIM_SAVE_FAILED) respond(type, id, BleStatus::IO_ERROR);
      else respond(type, id, BleStatus::NOT_FOUND);
      break;
    }
    case BleMsg::AUTH_REVOKE: {
      uint8_t kid[8];
      r.bytes(kid, 8);
      if (!r.ok()) { respond(type, id, BleStatus::BAD_FORMAT); break; }
      auth_lock();
      bool ok = s_auth->revoke(kid);
      auth_publish();
      auth_unlock();
      respond(type, id, ok ? BleStatus::OK : BleStatus::NOT_FOUND);
      break;
    }
    case BleMsg::BACK_LINK: {
      uint8_t action = r.u8();
      if (!r.ok() || action < 1 || action > 2) { respond(type, id, BleStatus::BAD_FORMAT); break; }
      bool ok = action == 1 ? uartlink::pair_start(60000) : uartlink::pair_forget();
      respond(type, id, ok ? BleStatus::OK : BleStatus::NOT_ALLOWED);
      break;
    }
    case BleMsg::REBOOT: {
      uint8_t confirm = r.u8(), force = r.remaining() ? r.u8() : 0;
      if (!r.ok() || confirm != 1) { respond(type, id, BleStatus::NOT_ALLOWED); break; }
      if (storage::session_active() && !force) { respond(type, id, BleStatus::STATE_CONFLICT); break; }
      respond(type, id, BleStatus::OK);
      bb::log(BbCode::SHUTDOWN, 0, 2, 0, "app reboot");
      if (storage::session_active()) { ctl::session_cmd(SessionCmd::STOP, CmdSource::APP); vTaskDelay(pdMS_TO_TICKS(500)); }
      vTaskDelay(pdMS_TO_TICKS(800));  // let the response go out
      storage::shutdown(8000);
      esp_restart();
      break;
    }
    case BleMsg::GET_STATUS: {
      AppSnapshot* s = new AppSnapshot();
      appstate::get(s);
      uint8_t b[96];
      ByteWriter w(b, sizeof(b));
      w.u8((uint8_t)s->session.st); w.u8((uint8_t)s->session.gf); w.u8((uint8_t)s->storage.rec); w.u8(s->storage.mounted);
      w.u64(s->storage.free_bytes); w.str(s->storage.session_id, 24); w.u8(s->session.manual); w.u8(s->session.inhibited);
      w.i8((int8_t)s->power.pmu.batt_pct); w.u16(s->power.pmu.batt_mv); w.u8(s->power.pmu.vbus); w.u8((uint8_t)s->power.level);
      w.u8(s->link.connected); w.u8(s->girth.connected); w.u8(s->rtcm.flowing); w.u64(s->sys.wall_ms); w.u8(s->sys.time_source);
      w.u32(s->storage.dropped_records); w.u16((uint16_t)s->storage.ring_fill_permille);
      delete s;
      respond(type, id, BleStatus::OK, b, w.size());
      break;
    }
    case BleMsg::SESSION_CMD: {
      uint8_t c = r.u8();
      uint8_t confirm = r.remaining() ? r.u8() : 0;
      if (!r.ok() || c < 1 || c > 6) { respond(type, id, BleStatus::BAD_FORMAT); break; }
      if ((SessionCmd)c == SessionCmd::STOP && confirm != 1) { respond(type, id, BleStatus::NOT_ALLOWED); break; }
      bool ok = ctl::session_cmd((SessionCmd)c, CmdSource::APP);
      respond(type, id, ok ? BleStatus::OK : BleStatus::BUSY);
      break;
    }
    case BleMsg::GET_CONFIG: {
      Config* c = new Config();
      cfgstore::get(c);
      size_t cap = config_max_size();
      uint8_t* b = (uint8_t*)malloc(cap);
      size_t len = b ? config_serialize(*c, b, cap) : 0;
      delete c;
      respond(type, id, len ? BleStatus::OK : BleStatus::IO_ERROR, b, len);
      free(b);
      break;
    }
    case BleMsg::SET_CONFIG: {
      Config* c = new Config();
      ConfigLoad lr = config_deserialize(p, n, c);
      if (lr == ConfigLoad::OK || lr == ConfigLoad::MIGRATED || lr == ConfigLoad::NEWER_SCHEMA_OK) {
        int fixed = cfgstore::set(*c);
        uint8_t b[2] = {(uint8_t)(fixed < 0 ? 0xFF : fixed), (uint8_t)lr};
        respond(type, id, fixed < 0 ? BleStatus::IO_ERROR : BleStatus::OK, b, 2);
      } else {
        uint8_t b[1] = {(uint8_t)lr};
        respond(type, id, BleStatus::BAD_FORMAT, b, 1);
      }
      delete c;
      break;
    }
    case BleMsg::SET_FENCE: {
      uint8_t slot = r.u8();
      FenceDef f;
      if (!r.ok() || slot >= AVO_MAX_FENCES || !fence_deserialize(r.cur(), r.remaining(), &f)) { respond(type, id, BleStatus::BAD_FORMAT); break; }
      FenceError fe = validate_fence(f);
      if (fe != FenceError::OK && f.type != FenceType::NONE) { uint8_t b = (uint8_t)fe; respond(type, id, BleStatus::BAD_FORMAT, &b, 1); break; }
      Config* c = new Config();
      cfgstore::get(c);
      c->fences[slot] = f;
      c->fences[slot].id = slot;
      if (c->fence_count < slot + 1) c->fence_count = (uint8_t)(slot + 1);
      int fixed = cfgstore::set(*c);
      delete c;
      respond(type, id, fixed < 0 ? BleStatus::IO_ERROR : BleStatus::OK);
      break;
    }
    case BleMsg::GET_FENCE: {
      uint8_t slot = r.u8();
      if (!r.ok() || slot >= AVO_MAX_FENCES) { respond(type, id, BleStatus::BAD_FORMAT); break; }
      Config* c = new Config();
      cfgstore::get(c);
      uint8_t b[256];
      b[0] = slot;
      size_t len = fence_serialize(c->fences[slot], b + 1, sizeof(b) - 1);
      delete c;
      respond(type, id, BleStatus::OK, b, len + 1);
      break;
    }
    case BleMsg::SET_ACTIVE_FENCES: {
      uint8_t mask = r.u8(), aut = r.u8();
      if (!r.ok()) { respond(type, id, BleStatus::BAD_FORMAT); break; }
      Config* c = new Config();
      cfgstore::get(c);
      c->active_mask = mask;
      c->auto_enabled = aut ? 1 : 0;
      int fixed = cfgstore::set(*c);
      delete c;
      respond(type, id, fixed < 0 ? BleStatus::IO_ERROR : BleStatus::OK);
      break;
    }
    case BleMsg::LIST_SESSIONS:
    case BleMsg::READ_FILE:
    case BleMsg::FILE_SHA256:
    case BleMsg::MARK_UPLOADED:
    case BleMsg::DELETE_PREPARE:
    case BleMsg::DELETE_COMMIT: {
      storage::FileReq q = {};
      q.msg_id = id;
      bool ok = true;
      if (type == BleMsg::LIST_SESSIONS) { q.op = storage::FileOp::LIST; q.page = r.u16(); }
      else if (type == BleMsg::READ_FILE) { q.op = storage::FileOp::READ; ok = sid(r, q.session_id); q.segment = r.u16(); q.offset = r.u32(); q.length = r.u32(); }
      else if (type == BleMsg::FILE_SHA256) { q.op = storage::FileOp::SHA256; ok = sid(r, q.session_id); }
      else if (type == BleMsg::MARK_UPLOADED) { q.op = storage::FileOp::MARK_UPLOADED; ok = sid(r, q.session_id); r.bytes(q.sha256, 32); }
      else if (type == BleMsg::DELETE_PREPARE) { q.op = storage::FileOp::DELETE_PREPARE; ok = sid(r, q.session_id); }
      else { q.op = storage::FileOp::DELETE_COMMIT; ok = sid(r, q.session_id); q.token = r.u32(); q.force = r.u8(); }
      if (!ok || !r.ok()) { respond(type, id, BleStatus::BAD_FORMAT); break; }
      if (!storage::file_request(q)) respond(type, id, BleStatus::BUSY);
      break;
    }
    case BleMsg::OTA_BEGIN: {
      uint32_t size = r.u32();
      uint8_t sha[32];
      r.bytes(sha, 32);
      char err[48] = {0};
      if (!r.ok()) { respond(type, id, BleStatus::BAD_FORMAT); break; }
      if (storage::session_active()) { respond(type, id, BleStatus::STATE_CONFLICT); break; }  // never during a session
      bool ok = ota::begin(size, sha, err, sizeof(err));
      respond(type, id, ok ? BleStatus::OK : BleStatus::NOT_ALLOWED, (const uint8_t*)err, strlen(err));
      break;
    }
    case BleMsg::OTA_DATA: {
      uint32_t off = r.u32();
      char err[48] = {0};
      if (!r.ok()) { respond(type, id, BleStatus::BAD_FORMAT); break; }
      bool ok = ota::write(off, r.cur(), r.remaining(), err, sizeof(err));
      uint8_t b[4];
      put_u32(b, off + (uint32_t)r.remaining());
      respond(type, id, ok ? BleStatus::OK : BleStatus::IO_ERROR, b, 4);
      break;
    }
    case BleMsg::OTA_END: {
      char err[48] = {0};
      bool ok = ota::end(err, sizeof(err));
      respond(type, id, ok ? BleStatus::OK : BleStatus::VERIFY_FAILED, (const uint8_t*)err, strlen(err));
      if (ok) {
        bb::log(BbCode::OTA, 0, 1, 0, "ota ok, reboot");
        vTaskDelay(pdMS_TO_TICKS(1500));
        storage::shutdown(5000);
        esp_restart();
      }
      break;
    }
    case BleMsg::OTA_ABORT:
      ota::abort();
      respond(type, id, BleStatus::OK);
      break;
    case BleMsg::DIAG_GET: {
      AppSnapshot* s = new AppSnapshot();
      appstate::get(s);
      char t[1500];
      int len = snprintf(t, sizeof(t),
                         "fw=%s src=%.12s boot=%lu reset=%s up=%lus heap=%lu psram=%lu sd=%d rec=%s ring=%lu%% drop=%lu "
                         "uart=%d ok=%lu crc=%lu lost=%lu rtcm_in=%lu rtcm_out=%lu rtcm_drop=%lu zed_used=%lu "
                         "girth=%d imu=%lu gnss_hz=%.1f batt=%d%% %umV time=%s safe=%d largest=%u psram_min=%lu heap_min=%lu keys=%u auth_fail=%lu mtu=%u",
                         AVO_FW_VERSION, AVO_BUILD_FINGERPRINT, (unsigned long)s->sys.boot, s->sys.reset_reason, (unsigned long)(s->sys.uptime_ms / 1000),
                         (unsigned long)s->sys.heap_free, (unsigned long)s->sys.psram_free, s->storage.mounted,
                         rec_status_str(s->storage.rec), (unsigned long)(s->storage.ring_fill_permille / 10),
                         (unsigned long)s->storage.dropped_records, s->link.connected, (unsigned long)s->link.dec.frames_ok,
                         (unsigned long)s->link.dec.crc_err, (unsigned long)s->link.dec.seq_lost, (unsigned long)s->rtcm.ble_rx_bytes,
                         (unsigned long)s->rtcm.sent_to_back_bytes, (unsigned long)s->rtcm.dropped_bytes,
                         (unsigned long)s->link.back.rxm_rtcm_used, s->girth.connected, (unsigned long)s->girth.samples,
                         s->gnss.rate_hz, s->power.pmu.batt_pct, s->power.pmu.batt_mv,
                         sys::time_source_str((sys::TimeSource)s->sys.time_source), s->sys.safe_mode,
                         (unsigned)heap_caps_get_largest_free_block(MALLOC_CAP_INTERNAL | MALLOC_CAP_8BIT),
                         (unsigned long)s->sys.psram_min, (unsigned long)s->sys.heap_min, (unsigned)s->ble.auth_keys,
                         (unsigned long)s->ble.auth_fail, (unsigned)s_mtu);
      // V3.5.0: chest <-> back radio link and the back's view of the ZED-F9P
      if (len > 0 && len < (int)sizeof(t)) {
        char mac[18];
        now_mac_str(s->link.now_peer, mac);
        const BackStatus& b = s->link.back;
        uint32_t back_age = s->link.status_valid ? (uint32_t)(sys::ms() - s->link.back_status_ms) : 0xFFFFFFFFu;
        int l2 = snprintf(t + len, sizeof(t) - len,
            " link=%s now_paired=%d now_pairing=%d now_peer=%s now_tx_ok=%lu now_tx_fail=%lu now_retry=%lu now_rx=%lu"
            " now_foreign=%lu now_bad=%lu now_rssi=%d rtcm_nolink=%lu ble_rtcm_rejected=%lu back_status_age_ms=%lu",
            s->link.transport ? "espnow" : "uart", s->link.now_paired, s->link.now_pairing, mac,
            (unsigned long)s->link.now_tx_ok, (unsigned long)s->link.now_tx_fail, (unsigned long)s->link.now_retries,
            (unsigned long)s->link.now_rx_pkts, (unsigned long)s->link.now_rx_foreign, (unsigned long)s->link.now_rx_bad,
            (int)s->link.now_rssi, (unsigned long)s->link.rtcm_dropped_nolink, (unsigned long)s->ble.rtcm_rejected_unauth,
            (unsigned long)back_age);
        if (l2 > 0) len += l2;
        if (s->link.status_valid && len < (int)sizeof(t)) {
          l2 = snprintf(t + len, sizeof(t) - len,
              " back_fw=%.15s zed=%s zed_baud=%lu zed_port=%u zed_cfg=%u nav_hz_cfg=%u back_gnss_hz=%.1f"
              " back_rtcm_rx=%lu back_rtcm_zed=%lu back_rtcm_ok=%lu back_rtcm_bad=%lu back_rtcm_gap=%lu back_rtcm_nowr=%lu"
              " zed_used=%lu zed_fail=%lu ubx=%lu nmea=%lu back_tx_fail=%lu back_rssi=%d",
              s->link.caps_valid ? s->link.back_caps.fw_version : "?",
              b.v2 ? ZedManager::state_name((ZedManager::State)b.zed_detail) : "?", (unsigned long)b.zed_baud,
              (unsigned)b.zed_port, (unsigned)b.zed_cfg, (unsigned)b.nav_rate_cfg_hz, b.gnss_rate_hz_x10 / 10.0,
              (unsigned long)b.rtcm_rx_bytes, (unsigned long)b.rtcm_to_zed_bytes, (unsigned long)b.rtcm_frames_ok,
              (unsigned long)b.rtcm_frames_bad, (unsigned long)b.rtcm_gaps_bytes, (unsigned long)b.rtcm_not_written,
              (unsigned long)b.rxm_rtcm_used, (unsigned long)b.rxm_rtcm_failed, (unsigned long)b.ubx_frames,
              (unsigned long)b.nmea_sentences, (unsigned long)b.link_tx_fail, (int)b.link_rssi);
          if (l2 > 0) len += l2;
        }
        if (len >= (int)sizeof(t)) len = (int)sizeof(t) - 1;
      }
      delete s;
      respond(type, id, BleStatus::OK, (const uint8_t*)t, len > 0 ? (size_t)len : 0);
      break;
    }
    case BleMsg::BLACKBOX_READ: {
      uint8_t cnt = r.remaining() ? r.u8() : 32;
      if (cnt > 100) cnt = 100;
      uint8_t* b = (uint8_t*)malloc(2 + 100 * 31);
      ByteWriter w(b, 2 + 100 * 31);
      w.u8(0);
      int got = bb::read_recent(cnt, blackbox_visit, &w);
      b[0] = (uint8_t)got;
      respond(type, id, BleStatus::OK, b, w.size());
      free(b);
      break;
    }
    case BleMsg::TIME_SET: {
      uint64_t ms = r.u64();
      if (!r.ok() || ms < 1700000000000ull) { respond(type, id, BleStatus::BAD_FORMAT); break; }
      CtlMsg m = {};
      m.type = CtlType::TIME_SET;
      m.arg64 = ms;
      respond(type, id, ctl::post(m, 50) ? BleStatus::OK : BleStatus::BUSY);
      break;
    }
    default:
      respond(type, id, BleStatus::UNKNOWN_TYPE);
      break;
  }
}

static void rx_task(void*) {
  RxFrag* f = (RxFrag*)heap_caps_malloc(sizeof(RxFrag), MALLOC_CAP_SPIRAM);
  for (;;) {
    if (xQueueReceive(s_rxq, f, pdMS_TO_TICKS(500)) != pdTRUE) { s_reasm->expire(sys::ms()); continue; }
    BleFragView v;
    if (!ble_frag_parse(f->d, f->len, &v)) {
      appstate::update([](AppSnapshot& s) { s.ble.crc_err++; });
      // Reply with the header we can still read (if any) so the phone retries.
      if (f->len >= BLE_FRAG_HDR) respond((BleMsg)f->d[1], get_u16(f->d + 2), BleStatus::BAD_CRC);
      continue;
    }
    const uint8_t* msg;
    size_t len;
    BleStatus err;
    BleReassembler::Result r = s_reasm->feed(v, sys::ms(), &msg, &len, &err);
    if (r == BleReassembler::NEED_MORE) continue;
    if (r == BleReassembler::DUPLICATE) {
      // Idempotency: an already executed request is not executed again.
      appstate::update([](AppSnapshot& s) { s.ble.dups++; });
      respond(v.type, v.msg_id, BleStatus::DUPLICATE);
      continue;
    }
    if (r == BleReassembler::ERROR) { respond(v.type, v.msg_id, err); continue; }
    appstate::update([](AppSnapshot& s) { s.ble.rx_msgs++; });
    dispatch(v.type, v.msg_id, msg, len);
  }
}

// ------------------------------------------------------------------ callbacks
class CtrlCb : public NimBLECharacteristicCallbacks {
  void onWrite(NimBLECharacteristic* c, NimBLEConnInfo& connInfo) override {
    (void)connInfo;
    RxFrag f;
    size_t n = c->getValue().size();
    if (n > sizeof(f.d)) n = sizeof(f.d);
    f.len = (uint16_t)n;
    memcpy(f.d, c->getValue().data(), n);
    if (xQueueSend(s_rxq, &f, 0) != pdTRUE) appstate::update([](AppSnapshot& s) { s.ble.dups++; });
  }
};

// RTCM fast path: validated and forwarded inside the BLE callback (no extra copy hop).
// Payload: u32 sequence of this RTCM message from the phone + RTCM bytes.
class RtcmCb : public NimBLECharacteristicCallbacks {
  void onWrite(NimBLECharacteristic* c, NimBLEConnInfo& connInfo) override {
    (void)connInfo;
    BleFragView v;
    if (!ble_frag_parse((const uint8_t*)c->getValue().data(), c->getValue().size(), &v) || v.type != BleMsg::RTCM || v.len < 4 || v.frag_cnt != 1) {
      appstate::update([](AppSnapshot& s) { s.ble.crc_err++; });
      return;
    }
    if (!is_authorized()) {  // V3.4.4: corrections only from an authorized phone
      appstate::update([](AppSnapshot& s) { s.ble.rtcm_rejected_unauth++; });
      return;
    }
    uint32_t seq = get_u32(v.payload);
    if (s_rtcm_have_seq && seq != s_rtcm_seq_expected) {
      if ((int32_t)(seq - s_rtcm_seq_expected) < 0) return;  // duplicate / old: never forwarded twice
    }
    s_rtcm_have_seq = true;
    s_rtcm_seq_expected = seq + 1;
    rtcm::push(v.payload + 4, v.len - 4);
  }
};

class SrvCb : public NimBLEServerCallbacks {
  void onConnect(NimBLEServer* server, NimBLEConnInfo& info) override {
    (void)server;
    s_connected = true;
    s_conn = info.getConnHandle();
    s_encrypted = info.isEncrypted();
    s_rtcm_have_seq = false;
    if (s_reasm) s_reasm->reset();
    if (s_auth) { auth_lock(); s_auth->on_connect(s_conn); auth_publish(); auth_unlock(); }
    appstate::update([&](AppSnapshot& a) { a.ble.connected = true; a.ble.encrypted = s_encrypted; });
    bb::log(BbCode::BLE_CONNECT, 0, s_conn);
  }
  void onDisconnect(NimBLEServer* server, NimBLEConnInfo& info, int reason) override {
    (void)server; (void)reason;
    s_connected = false;
    s_conn = 0xFFFF;
    s_mtu = 23;
    if (s_auth) { auth_lock(); s_auth->on_disconnect(); auth_publish(); auth_unlock(); }
    ui::show_passkey(0, false);
    appstate::update([](AppSnapshot& a) { a.ble.connected = false; a.ble.encrypted = false; a.ble.mtu = 23; a.ble.show_passkey = false; });
    bb::log(BbCode::BLE_DISCONNECT, 0, info.getConnHandle());
    NimBLEDevice::startAdvertising();
  }
  void onMTUChange(uint16_t mtu, NimBLEConnInfo& info) override {
    (void)info;
    s_mtu = mtu;
    appstate::update([&](AppSnapshot& a) { a.ble.mtu = mtu; });
  }
    void onAuthenticationComplete(NimBLEConnInfo& info) override {
    ui::show_passkey(0, false);
    s_encrypted = info.isEncrypted();
    bool bonded = info.isBonded();
    appstate::update([&](AppSnapshot& a) { a.ble.show_passkey = false; a.ble.encrypted = s_encrypted; a.ble.bonded = bonded; });
    if (!s_encrypted) bb::log(BbCode::BLE_AUTH_FAIL, 1, info.getConnHandle());
  }
};

bool init(const char* name) {
  Config* c = new Config();
  cfgstore::get(c);
  s_require_bond = c->ble_require_bond != 0;
  delete c;
  // V3.3.5: store the 32 x 514-byte BLE fragment queue in PSRAM.
  // The FreeRTOS queue control structure remains in internal static RAM.
  s_rxq_storage = (uint8_t*)heap_caps_malloc(32 * sizeof(RxFrag), MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
  s_rxq = s_rxq_storage ? xQueueCreateStatic(32, sizeof(RxFrag), s_rxq_storage, &s_rxq_meta) : nullptr;
  Serial.printf("[AVO MEM] BLE RX queue PSRAM=%s bytes=%u\n", s_rxq ? "OK" : "FAIL", (unsigned)(32 * sizeof(RxFrag)));
  s_txmb = psram_message_buffer(48 * 1024);
  s_reasm = (BleReassembler*)heap_caps_malloc(sizeof(BleReassembler), MALLOC_CAP_SPIRAM);
  if (!s_rxq || !s_txmb || !s_reasm) return false;
  new (s_reasm) BleReassembler();
  s_reasm->reset();
  s_auth_mtx = xSemaphoreCreateMutex();
  s_auth = (AuthManager*)heap_caps_malloc(sizeof(AuthManager), MALLOC_CAP_SPIRAM);
  if (!s_auth_mtx || !s_auth) return false;
  new (s_auth) AuthManager();
  {
    AuthStore st;
    uint8_t kb[AUTH_STORE_MAX];
    size_t kn = sizeof(kb);
    if (!(sys::nvs_get_blob("blekeys", kb, &kn) && auth_store_deserialize(kb, kn, &st))) st = AuthStore();
    s_auth->init(st, sys::device_id_hex(), auth_random, auth_save);
    Serial.printf("[AVO BLE] authorized phones: %u\n", (unsigned)st.count);
  }

  Serial.printf("[AVO BLE] NimBLE-Arduino 2.x start: heap=%u internal=%u largest=%u\n",
                (unsigned)ESP.getFreeHeap(),
                (unsigned)heap_caps_get_free_size(MALLOC_CAP_INTERNAL | MALLOC_CAP_8BIT),
                (unsigned)heap_caps_get_largest_free_block(MALLOC_CAP_INTERNAL | MALLOC_CAP_8BIT));
  if (!NimBLEDevice::init(name)) {
    Serial.println("[AVO BLE] FAIL: NimBLEDevice::init() returned false");
    return false;
  }
  Serial.println("[AVO BLE] NimBLEDevice::init OK");
  NimBLEDevice::setMTU(247);
  // V3.4.4: bonding + LE Secure Connections, NO MITM ("Just Works"): the
  // four-band screen cannot display a passkey. Phone authorization is done at
  // application level (CLAIM + BOOT, then HMAC challenge-response).
  NimBLEDevice::setSecurityAuth(s_require_bond, false, s_require_bond);
  NimBLEDevice::setSecurityIOCap(BLE_HS_IO_NO_INPUT_OUTPUT);
  s_srv = NimBLEDevice::createServer();
  if (!s_srv) {
    Serial.println("[AVO BLE] FAIL: createServer returned null; skipping GATT initialization");
    return false;
  }
  s_srv->setCallbacks(new SrvCb());
  NimBLEService* svc = s_srv->createService(AVO_SVC_UUID);
  if (!svc) { Serial.println("[AVO BLE] FAIL: createService returned null"); return false; }
  // Encryption required; authentication (MITM) is not possible without a display, see above.
  uint32_t enc_w = s_require_bond ? NIMBLE_PROPERTY::WRITE_ENC : 0;
  uint32_t enc_r = s_require_bond ? NIMBLE_PROPERTY::READ_ENC : 0;
  s_info = svc->createCharacteristic(AVO_INFO_UUID, NIMBLE_PROPERTY::READ | enc_r);
  s_ctrl_rx = svc->createCharacteristic(AVO_CTRL_RX_UUID, NIMBLE_PROPERTY::WRITE | enc_w);
  s_ctrl_tx = svc->createCharacteristic(AVO_CTRL_TX_UUID, NIMBLE_PROPERTY::NOTIFY);
  s_telem = svc->createCharacteristic(AVO_TELEM_UUID, NIMBLE_PROPERTY::NOTIFY);
  s_rtcm = svc->createCharacteristic(AVO_RTCM_UUID, NIMBLE_PROPERTY::WRITE_NR | enc_w);
  s_file = svc->createCharacteristic(AVO_FILE_TX_UUID, NIMBLE_PROPERTY::NOTIFY);
  if (!s_info || !s_ctrl_rx || !s_ctrl_tx || !s_telem || !s_rtcm || !s_file) {
    Serial.println("[AVO BLE] FAIL: one or more GATT characteristics are null");
    return false;
  }
  s_ctrl_rx->setCallbacks(new CtrlCb());
  s_rtcm->setCallbacks(new RtcmCb());
  char info[48];
  snprintf(info, sizeof(info), "AVO-CHEST %s %s", AVO_FW_VERSION, sys::device_id_hex());
  s_info->setValue((uint8_t*)info, strlen(info));
  // NimBLE-Arduino 2.x starts services together with the server (svc->start() is a deprecated no-op).
  NimBLEAdvertising* adv = NimBLEDevice::getAdvertising();
  if (!adv) { Serial.println("[AVO BLE] FAIL: advertising object null"); return false; }
  // Advertise a human-readable, unique device name for Android BLE scanners.
  // Short name and 128-bit service UUID are placed in separate advertising/scan-response packets.
  adv->setName(name);
  adv->addServiceUUID(AVO_SVC_UUID);
  adv->enableScanResponse(true);
  Serial.printf("[AVO BLE] advertising name=%s\n", name);
  NimBLEDevice::startAdvertising();

  storage::set_file_callback(file_cb);
  BaseType_t rx_created = xTaskCreatePinnedToCore(rx_task, "ble_rx", 6144, nullptr, 7, nullptr, 0);
  BaseType_t tx_created = xTaskCreatePinnedToCore(tx_task, "ble_tx", 6144, nullptr, 6, &g_task_handles[TID_BLE_TX], 0);
  Serial.printf("[AVO MEM] BLE tasks rx=%s tx=%s internal=%u largest=%u\n",
                rx_created == pdPASS ? "OK" : "FAIL", tx_created == pdPASS ? "OK" : "FAIL",
                (unsigned)heap_caps_get_free_size(MALLOC_CAP_INTERNAL | MALLOC_CAP_8BIT),
                (unsigned)heap_caps_get_largest_free_block(MALLOC_CAP_INTERNAL | MALLOC_CAP_8BIT));
  return rx_created == pdPASS && tx_created == pdPASS;
}

void tick() {}

bool notify_event(uint16_t code, const char* text) {
  uint8_t b[40];
  ByteWriter w(b, sizeof(b));
  w.u16(code);
  w.str(text ? text : "", 32);
  return queue_msg(CH_CTRL, BleMsg::EVENT, s_tx_msg_id++, 0, 0, b, w.size(), 0);
}

}  // namespace ble
