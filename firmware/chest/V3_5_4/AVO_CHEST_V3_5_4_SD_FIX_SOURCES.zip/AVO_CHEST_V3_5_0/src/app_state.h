// Shared, mutex-protected snapshot of the whole system. Producers update their
// own section; UI, BLE and developer mode read a copy. No hot path waits on it
// for more than a memcpy.
#pragma once
#include <stdint.h>
#include "avo_core.h"
#include "hal_board.h"

enum class RecStatus : uint8_t { IDLE = 0, RECORDING = 1, TEMP_BUFFER = 2, REC_ERROR = 3 };
const char* rec_status_str(RecStatus s);

struct LinkState {
  bool connected = false;          // valid frame from the back within the last 2 s
  uint32_t last_rx_ms = 0;
  avo::DecoderStats dec;
  bool caps_valid = false;
  avo::Caps back_caps;
  uint8_t proto_ver = 0;           // negotiated
  bool status_valid = false;
  avo::BackStatus back;
  uint32_t back_status_ms = 0;
  bool timesync_valid = false;
  avo::TimeSync ts;
  uint32_t tx_frames = 0, tx_bytes = 0, tx_drop_hi = 0, tx_drop_lo = 0;
  uint32_t baud = 0;
  uint32_t rx_overflow = 0;
  // V3.5.0 ESP-NOW transport (transport: 0 UART cable, 1 ESP-NOW)
  uint8_t transport = 0;
  bool now_paired = false, now_pairing = false;
  uint8_t now_peer[6] = {0};
  uint32_t now_tx_ok = 0, now_tx_fail = 0, now_retries = 0;
  uint32_t now_rx_pkts = 0, now_rx_bad = 0, now_rx_foreign = 0, now_rx_queue_drop = 0;
  int8_t now_rssi = 0;
  uint32_t rtcm_dropped_nolink = 0;  // RTCM discarded because no back was reachable
};

struct GnssState {
  bool have = false;
  avo::GnssSample s;
  uint32_t rx_ms = 0;
  bool quality_ok = false;         // passes the geofence quality gate
  double rate_hz = 0;              // measured at the chest
};

struct GirthState {
  bool connected = false;          // reported by the back
  uint32_t last_batch_ms[3] = {0, 0, 0};
  uint32_t batches = 0, samples = 0;
  uint32_t seq_lost = 0;           // gaps in the original girth sequence numbers
  double rate_hz[3] = {0, 0, 0};
};

struct RtcmState {
  uint32_t ble_rx_bytes = 0;       // received from Android
  uint32_t ble_msgs = 0;
  uint32_t queued_bytes = 0;
  uint32_t sent_to_back_bytes = 0;
  uint32_t dropped_bytes = 0;      // queue saturation
  uint32_t last_rx_ms = 0;
  avo::RtcmStats observed;         // framing statistics (bytes are never altered)
  bool flowing = false;            // RTCM received within the last 5 s
};

struct StorageState {
  bool mounted = false;
  uint64_t card_bytes = 0, free_bytes = 0;
  RecStatus rec = RecStatus::IDLE;
  char session_id[24] = {0};
  uint16_t segment = 0;
  uint64_t session_bytes = 0;
  uint32_t blocks = 0;
  uint32_t last_write_ms = 0;
  uint32_t write_errors = 0;
  uint32_t remounts = 0;
  uint32_t ring_fill_permille = 0;
  uint32_t ring_peak_permille = 0;
  uint32_t dropped_records = 0;    // total records lost to buffer saturation
  uint32_t dropped_low = 0;        // low-priority records shed first
  uint32_t prebuf_records = 0;
  uint32_t prebuf_span_ms = 0;
  uint8_t prebuf_target_s = 0;
  uint32_t prebuf_capacity = 0;
  uint32_t max_write_ms = 0;       // slowest block write
  uint32_t sessions_on_card = 0;
  uint32_t recovered_sessions = 0;
};

struct SessionSnap {
  avo::SessionState st = avo::SessionState::IDLE;
  avo::GfState gf = avo::GfState::AUTO_DISABLED;
  bool manual = false;
  bool inhibited = false;
  bool gnss_lost = false;
  uint32_t pending_ms = 0;
  double sd_m = 0;
  avo::Zone zone = avo::Zone::INVALID;
  avo::SessionMetrics metrics;
  bool summary_valid = false;      // metrics belong to the last finished session
  bool confirm_stop = false;       // UI shows the stop confirmation
  uint32_t confirm_until_ms = 0;
  avo::StartReason reason = avo::StartReason::MANUAL_BUTTON;
};

struct BleState {
  bool connected = false;
  bool encrypted = false;
  bool bonded = false;
  uint16_t mtu = 23;
  bool show_passkey = false;
  uint32_t passkey = 0;
  uint32_t rx_msgs = 0, tx_msgs = 0, crc_err = 0, dups = 0, notify_fail = 0;
  bool ota_active = false;
  uint32_t ota_bytes = 0, ota_total = 0;
  // V3.4.4 application authorization
  bool authorized = false;
  bool claim_pending = false;
  uint8_t auth_keys = 0;
  uint32_t auth_fail = 0;
  uint32_t rtcm_rejected_unauth = 0;
};

struct PowerState {
  board::PmuStatus pmu;
  avo::PowerLevel level = avo::PowerLevel::UNKNOWN;
  bool shutdown_requested = false;
  uint16_t pwr_hold_permille = 0;
};

struct SysState {
  uint32_t uptime_ms = 0;
  uint32_t heap_free = 0, heap_min = 0, psram_free = 0, psram_min = 0;
  uint32_t boot = 0;
  const char* reset_reason = "";
  bool wall_valid = false;
  uint64_t wall_ms = 0;
  uint8_t time_source = 0;
  bool dev_mode = false;
  uint8_t dev_countdown_s = 0;
  uint16_t boot_hold_permille = 0;
  uint32_t i2c_errors = 0;
  uint32_t task_stack_min[8] = {0};  // high-water marks (words) per task id
  float cpu_temp_c = 0;
  bool display_on = true;
  bool safe_mode = false;          // repeated crashes: automatic resume disabled
};

struct AppSnapshot {
  LinkState link;
  GnssState gnss;
  GirthState girth;
  RtcmState rtcm;
  StorageState storage;
  SessionSnap session;
  BleState ble;
  PowerState power;
  SysState sys;
};

namespace appstate {
void init();
// Copies the whole snapshot (UI / BLE / dev mode).
void get(AppSnapshot* out);
// Locked update of a section: appstate::update([&](AppSnapshot& s){ s.link = ...; });
template <typename F>
void update(F f);
void lock();
void unlock();
AppSnapshot& raw();  // only between lock()/unlock()
}  // namespace appstate

template <typename F>
void appstate::update(F f) {
  lock();
  f(raw());
  unlock();
}

enum TaskId : uint8_t { TID_UART_RX = 0, TID_UART_TX, TID_STORAGE, TID_CTRL, TID_UI, TID_BB, TID_BLE_TX, TID_COUNT };
