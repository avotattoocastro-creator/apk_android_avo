// OTA update of the chest from Android over BLE, with SHA-256 verification and
// bootloader rollback (CONFIG_BOOTLOADER_APP_ROLLBACK_ENABLE=y in arduino-esp32 3.3.x).
// Image signing (Secure Boot v2) is NOT enabled: it needs eFuse key provisioning
// that cannot be undone; see KNOWN_LIMITATIONS.md.
#include <Arduino.h>
#include <esp_ota_ops.h>
#include <esp_app_format.h>
#include <mbedtls/sha256.h>
#include "services.h"
#include "sys_util.h"

using namespace avo;

// arduino-esp32 marks the running app valid automatically unless this returns true.
extern "C" bool verifyRollbackLater() { return true; }

namespace ota {

static esp_ota_handle_t s_h = 0;
static const esp_partition_t* s_part = nullptr;
static uint32_t s_size = 0, s_written = 0;
static uint8_t s_sha[32];
static mbedtls_sha256_context s_ctx;
static bool s_active = false;

// Compatibility marker embedded in every AVO chest image. OTA images without it
// (another product, another board) are rejected before the boot partition changes.
static const char kMarker[] = "AVOCHEST-IMG-V1:WS-AMOLED-2.06";
extern "C" __attribute__((used)) const char avo_image_marker[] = "AVOCHEST-IMG-V1:WS-AMOLED-2.06";
static size_t s_match = 0;   // streaming match progress
static bool s_found = false;

static void scan_marker(const uint8_t* d, size_t n) {
  const size_t L = sizeof(kMarker) - 1;
  for (size_t i = 0; i < n && !s_found; i++) {
    if (d[i] == (uint8_t)kMarker[s_match]) {
      if (++s_match == L) s_found = true;
    } else {
      s_match = (d[i] == (uint8_t)kMarker[0]) ? 1 : 0;
    }
  }
}

bool active() { return s_active; }

bool pending_verify() {
  esp_ota_img_states_t st;
  const esp_partition_t* run = esp_ota_get_running_partition();
  return run && esp_ota_get_state_partition(run, &st) == ESP_OK && st == ESP_OTA_IMG_PENDING_VERIFY;
}

void mark_valid_if_healthy(bool healthy) {
  if (!pending_verify()) return;
  if (healthy) {
    esp_ota_mark_app_valid_cancel_rollback();
    bb::log(BbCode::OTA, 0, 2, 0, "new image validated");
  } else {
    bb::log(BbCode::OTA, 2, 3, 0, "self-test failed: rollback");
    esp_ota_mark_app_invalid_rollback_and_reboot();
  }
}

bool begin(uint32_t size, const uint8_t sha[32], char* err, size_t el) {
  if (s_active) { snprintf(err, el, "ota already active"); return false; }
  if (pending_verify()) { snprintf(err, el, "current image not validated yet"); return false; }
  s_part = esp_ota_get_next_update_partition(nullptr);
  if (!s_part) { snprintf(err, el, "no ota partition"); return false; }
  if (size < sizeof(esp_image_header_t) || size > s_part->size) { snprintf(err, el, "bad size"); return false; }
  if (esp_ota_begin(s_part, size, &s_h) != ESP_OK) { snprintf(err, el, "ota_begin failed"); return false; }
  s_size = size;
  s_written = 0;
  memcpy(s_sha, sha, 32);
  s_match = 0;
  s_found = false;
  mbedtls_sha256_init(&s_ctx);
  mbedtls_sha256_starts(&s_ctx, 0);
  s_active = true;
  bb::log(BbCode::OTA, 0, 0, size, "ota begin");
  return true;
}

bool write(uint32_t off, const uint8_t* d, size_t n, char* err, size_t el) {
  if (!s_active) { snprintf(err, el, "no ota"); return false; }
  if (off != s_written) { snprintf(err, el, "expected offset %lu", (unsigned long)s_written); return false; }  // strictly sequential
  if (s_written + n > s_size) { snprintf(err, el, "overflow"); return false; }
  if (off == 0 && n >= 1 && d[0] != ESP_IMAGE_HEADER_MAGIC) { snprintf(err, el, "not an ESP image"); abort(); return false; }
  if (esp_ota_write(s_h, d, n) != ESP_OK) { snprintf(err, el, "flash write"); abort(); return false; }
  mbedtls_sha256_update(&s_ctx, d, n);
  scan_marker(d, n);
  s_written += (uint32_t)n;
  return true;
}

bool end(char* err, size_t el) {
  if (!s_active) { snprintf(err, el, "no ota"); return false; }
  uint8_t h[32];
  mbedtls_sha256_finish(&s_ctx, h);
  mbedtls_sha256_free(&s_ctx);
  s_active = false;
  if (s_written != s_size) { esp_ota_abort(s_h); snprintf(err, el, "incomplete"); return false; }
  if (memcmp(h, s_sha, 32) != 0) { esp_ota_abort(s_h); snprintf(err, el, "sha256 mismatch"); return false; }
  if (!s_found) { esp_ota_abort(s_h); snprintf(err, el, "not an AVO chest image"); return false; }
  // esp_ota_end also validates the image structure and its appended SHA-256/checksum.
  if (esp_ota_end(s_h) != ESP_OK) { snprintf(err, el, "image validation failed"); return false; }
  if (esp_ota_set_boot_partition(s_part) != ESP_OK) { snprintf(err, el, "set boot failed"); return false; }
  return true;
}

void abort() {
  if (s_active) { esp_ota_abort(s_h); mbedtls_sha256_free(&s_ctx); }
  s_active = false;
}

}  // namespace ota
