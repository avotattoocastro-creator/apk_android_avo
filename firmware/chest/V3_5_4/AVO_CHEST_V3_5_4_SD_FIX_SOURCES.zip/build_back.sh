#!/usr/bin/env bash
# Build AVO BACK V3.5.0 for the Heltec Wireless Stick Lite V3 (arduino-cli, arduino-esp32 3.3.x).
# Usage: ./build_back.sh [output_dir]   env: ARDUINO_CLI, ARDUINO_CONFIG, FQBN_VENDOR (esp32 for Board-Manager installs)
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
OUT="${1:-$HERE/firmware_back}"
CLI="${ARDUINO_CLI:-arduino-cli}"
CFG="${ARDUINO_CONFIG:-}"
LIBS="$HERE/.build_libs_back"
FQBN="${FQBN_VENDOR:-espressif}:esp32:heltec_wireless_stick_lite_V3"
rm -rf "$LIBS" && mkdir -p "$LIBS"
cp -r "$HERE/lib/avo_core" "$LIBS/"
export SOURCE_DATE_EPOCH="${SOURCE_DATE_EPOCH:-1792368000}"
BP="$HERE/.arduino_build_back"; rm -rf "$BP"
PMAP="-ffile-prefix-map=$HERE=AVO -ffile-prefix-map=$BP=AVOBUILD"
ARGS=(compile -b "$FQBN" --libraries "$LIBS" --build-path "$BP" --output-dir "$OUT" --warnings all --jobs 0
      --build-property "compiler.c.extra_flags=$PMAP" --build-property "compiler.cpp.extra_flags=$PMAP")
[ -n "$CFG" ] && ARGS=(--config-file "$CFG" "${ARGS[@]}")
mkdir -p "$OUT"
"$CLI" "${ARGS[@]}" "$HERE/AVO_BACK_V3_5_0" 2>&1 | tee "$OUT/build.log"
