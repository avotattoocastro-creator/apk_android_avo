// Host tests for the V3.4.4 additions: SHA-256/HMAC, authorization manager,
// key store. Also emits cross-language vectors (vectors/*.hex) used by the
// Android :core tests so both sides are proven to compute identical proofs.
#include "tiny_test.h"
#include "avo_core.h"
#include <string>

using namespace avo;

static std::string hex(const uint8_t* d, size_t n) {
  static const char* H = "0123456789abcdef";
  std::string s;
  for (size_t i = 0; i < n; i++) { s += H[d[i] >> 4]; s += H[d[i] & 15]; }
  return s;
}

TEST(sha, nist_vectors) {
  uint8_t o[32];
  sha256((const uint8_t*)"abc", 3, o);
  CHECK(hex(o, 32) == "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad");
  sha256((const uint8_t*)"", 0, o);
  CHECK(hex(o, 32) == "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855");
  std::string m = "abcdbcdecdefdefgefghfghighijhijkijkljklmklmnlmnomnopnopq";
  sha256((const uint8_t*)m.data(), m.size(), o);
  CHECK(hex(o, 32) == "248d6a61d20638b8e5c026930c3e6039a33ce45964ff2167f6ecedd419db06c1");
  std::string mil(1000000, 'a');
  sha256((const uint8_t*)mil.data(), mil.size(), o);
  CHECK(hex(o, 32) == "cdc76e5c9914fb9281a1c7e284d73e67f1809a48a497200e046d39ccc7112cd0");
}

TEST(sha, hmac_rfc4231) {
  uint8_t o[32];
  uint8_t k1[20];
  memset(k1, 0x0b, 20);
  hmac_sha256(k1, 20, (const uint8_t*)"Hi There", 8, o);
  CHECK(hex(o, 32) == "b0344c61d8db38535ca8afceaf0bf12b881dc200c9833da726e9376c2e32cff7");
  hmac_sha256((const uint8_t*)"Jefe", 4, (const uint8_t*)"what do ya want for nothing?", 28, o);
  CHECK(hex(o, 32) == "5bdcc146bf60754e6a042426089575c75a003f089d2739839dec58b964ec3843");
  uint8_t k6[131];
  memset(k6, 0xaa, sizeof(k6));
  const char* m6 = "Test Using Larger Than Block-Size Key - Hash Key First";
  hmac_sha256(k6, sizeof(k6), (const uint8_t*)m6, strlen(m6), o);
  CHECK(hex(o, 32) == "60e431591ee0b67f0d8a26aacbf5b77f8e0bc6213728c5140546040f0ee37f54");
}

// deterministic "random" for reproducible vectors
static uint8_t g_ctr = 0;
static void det_random(uint8_t* o, size_t n) { for (size_t i = 0; i < n; i++) o[i] = (uint8_t)(g_ctr++ * 37 + 11); }
static int g_saves = 0;
static AuthStore g_saved;
static bool g_save_ok = true;
static bool save_cb(const AuthStore& s) { g_saves++; if (g_save_ok) g_saved = s; return g_save_ok; }

TEST(auth, claim_then_challenge_response) {
  g_ctr = 0; g_saves = 0; g_save_ok = true;
  AuthManager m;
  m.init(AuthStore(), "A1B2C3D4E5F6", det_random, save_cb);
  m.on_connect(1);
  CHECK(!m.authorized());
  uint8_t id[8], key[32];
  CHECK(m.claim_result(0, id, key) == AuthManager::CLAIM_NONE);
  CHECK(m.claim_begin(1000, "Pixel 8"));
  CHECK(m.claim_pending(5000));
  CHECK(m.claim_result(5000, id, key) == AuthManager::CLAIM_PENDING);
  CHECK(m.claim_confirm(6000));               // BOOT pressed
  CHECK(!m.claim_pending(6000));
  CHECK(m.claim_result(6500, id, key) == AuthManager::CLAIM_DONE);
  CHECK(m.authorized());
  CHECK_EQ(g_saves, 1);
  CHECK_EQ(g_saved.count, 1);
  CHECK(strcmp(g_saved.keys[0].name, "Pixel 8") == 0);
  CHECK(m.claim_result(7000, id, key) == AuthManager::CLAIM_NONE);  // key delivered only once

  // new connection: HELLO / PROOF
  m.on_disconnect();
  m.on_connect(2);
  CHECK(!m.authorized());
  uint8_t pn[16], wn[16], wp[32], pp[32], want_wp[32];
  for (int i = 0; i < 16; i++) pn[i] = (uint8_t)(0xA0 + i);
  CHECK(m.hello(id, pn, wn, wp));
  auth_watch_proof(key, pn, wn, "A1B2C3D4E5F6", want_wp);
  CHECK(memcmp(wp, want_wp, 32) == 0);         // the phone can verify the watch
  auth_phone_proof(key, wn, pn, "A1B2C3D4E5F6", pp);
  CHECK(m.proof(pp) == AuthManager::PROOF_OK);
  CHECK(m.authorized());
  CHECK(m.proof(pp) == AuthManager::PROOF_NO_HELLO);  // nonce single use (replay)

  // vectors for Kotlin
  FILE* f = fopen("vectors_auth.txt", "w");
  if (f) {
    fprintf(f, "dev_id=A1B2C3D4E5F6\nkey=%s\npn=%s\nwn=%s\nwatch_proof=%s\nphone_proof=%s\n", hex(key, 32).c_str(),
            hex(pn, 16).c_str(), hex(wn, 16).c_str(), hex(wp, 32).c_str(), hex(pp, 32).c_str());
    fclose(f);
  }
}

TEST(auth, wrong_key_unknown_id_lockout_expiry) {
  g_ctr = 50; g_save_ok = true;
  AuthManager m;
  m.init(AuthStore(), "000000000001", det_random, save_cb);
  m.on_connect(1);
  uint8_t id[8] = {1, 2, 3, 4, 5, 6, 7, 8}, pn[16] = {0}, wn[16], wp[32];
  CHECK(!m.hello(id, pn, wn, wp));            // unknown id -> must claim
  m.claim_begin(0, "x");
  CHECK(m.claim_result(60001, id, wp) == AuthManager::CLAIM_EXPIRED);
  CHECK(!m.claim_confirm(60001));             // too late
  m.claim_begin(70000, "x");
  m.claim_confirm(71000);
  uint8_t key[32];
  CHECK(m.claim_result(71000, id, key) == AuthManager::CLAIM_DONE);
  m.on_connect(3);
  uint8_t bad[32] = {0};
  for (int i = 0; i < 5; i++) { m.hello(id, pn, wn, wp); CHECK(m.proof(bad) == AuthManager::PROOF_BAD); }
  m.hello(id, pn, wn, wp);
  uint8_t pp[32];
  auth_phone_proof(key, wn, pn, "000000000001", pp);
  CHECK(m.proof(pp) == AuthManager::PROOF_LOCKED);  // 5 failures: locked until reconnect
  m.on_connect(4);
  m.hello(id, pn, wn, wp);
  auth_phone_proof(key, wn, pn, "000000000001", pp);
  CHECK(m.proof(pp) == AuthManager::PROOF_OK);
  // a proof computed for another device id is rejected
  m.on_connect(5);
  m.hello(id, pn, wn, wp);
  auth_phone_proof(key, wn, pn, "000000000002", pp);
  CHECK(m.proof(pp) == AuthManager::PROOF_BAD);
}

TEST(auth, store_full_replaces_oldest_revoke_and_save_failure) {
  g_ctr = 7; g_save_ok = true;
  AuthManager m;
  m.init(AuthStore(), "ABCDEF012345", det_random, save_cb);
  uint8_t ids[5][8], keys[5][32];
  for (int i = 0; i < 5; i++) {
    m.on_connect((uint16_t)i);
    m.claim_begin(0, i == 0 ? "first" : "other");
    m.claim_confirm(1);
    CHECK(m.claim_result(2, ids[i], keys[i]) == AuthManager::CLAIM_DONE);
  }
  CHECK_EQ(m.key_count(), AUTH_MAX_KEYS);
  bool first_present = false;
  for (int i = 0; i < m.key_count(); i++) if (memcmp(m.store().keys[i].id, ids[0], 8) == 0) first_present = true;
  CHECK(!first_present);                      // oldest replaced
  // store roundtrip + corruption
  uint8_t b[AUTH_STORE_MAX];
  size_t n = auth_store_serialize(m.store(), b, sizeof(b));
  AuthStore st;
  CHECK(auth_store_deserialize(b, n, &st));
  CHECK_EQ(st.count, AUTH_MAX_KEYS);
  b[20] ^= 1;
  CHECK(!auth_store_deserialize(b, n, &st));
  CHECK_EQ(st.count, 0);
  // revoke all others (current = last claimed)
  CHECK(m.revoke((const uint8_t*)"\xff\xff\xff\xff\xff\xff\xff\xff"));
  CHECK_EQ(m.key_count(), 1);
  CHECK(m.authorized());
  CHECK(memcmp(m.store().keys[0].id, ids[4], 8) == 0);
  // revoke itself -> deauthorized
  CHECK(m.revoke(ids[4]));
  CHECK(!m.authorized());
  CHECK_EQ(m.key_count(), 0);
  // a failed NVS write never hands out a key that was not stored
  g_save_ok = false;
  m.on_connect(9);
  m.claim_begin(0, "x");
  m.claim_confirm(1);
  uint8_t id[8], key[32];
  CHECK(m.claim_result(2, id, key) == AuthManager::CLAIM_SAVE_FAILED);
  CHECK(!m.authorized());
  g_save_ok = true;
}

TEST(auth, disconnect_cancels_claim) {
  AuthManager m;
  m.init(AuthStore(), "ABCDEF012345", det_random, save_cb);
  m.on_connect(1);
  m.claim_begin(0, "x");
  m.on_disconnect();
  CHECK(!m.claim_pending(1));
  CHECK(!m.claim_confirm(1));
  CHECK(!m.claim_begin(2, "x"));  // not connected
}

int main(int argc, char** argv) { return tt_run_all(argc > 1 ? argv[1] : nullptr); }
