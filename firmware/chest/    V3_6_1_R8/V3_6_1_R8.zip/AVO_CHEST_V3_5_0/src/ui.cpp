// AVO CHEST V3.6.1 CANDIDATE — seven solid AMOLED status bands, no LVGL.
// V3.5.0: band 4 (back) also shows ESP-NOW pairing and a ZED that does not answer.
// V3.4.4: colour constants renamed C_* (Arduino_GFX defines BLACK/RED/... as macros,
// which broke the V3.4.3 build); BLE band shows authorization / 'PULSA BOOT'.
// Arduino_GFX CO5300 QSPI, partial rectangle updates only.
#include <Arduino.h>
#include <Arduino_GFX_Library.h>
#include <esp_heap_caps.h>
#include <new>
#include <cstring>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "app_state.h"
#include "board_pins.h"
#include "services.h"
#include "sys_util.h"

using namespace avo;
extern TaskHandle_t g_task_handles[TID_COUNT];
namespace ui {
static Arduino_DataBus* bus = nullptr;
static Arduino_CO5300* gfx = nullptr;
static volatile bool request_wake = false;
static volatile bool passkey_active = false;
static bool display_on = true;
static uint8_t brightness = 180;
static uint32_t old_state[7] = {UINT32_MAX,UINT32_MAX,UINT32_MAX,UINT32_MAX,UINT32_MAX,UINT32_MAX,UINT32_MAX};

static uint32_t last_touch_ms = 0;
static uint32_t touch_start_ms = 0;
static bool dev_latched = false;
static bool developer_mode = false;
static Config config_cache;  // Avoid large config on UI task stack.

// RGB565, no fonts, images, sprites, framebuffers or LVGL.
static constexpr uint16_t C_GREEN = 0x06E6;
static constexpr uint16_t C_BLUE  = 0x241F;
static constexpr uint16_t C_AMBER = 0xFDC0;
static constexpr uint16_t C_RED   = 0xF986;
static constexpr uint16_t C_BLACK = 0x0000;

void show_passkey(uint32_t, bool on) {
  // No numeric passkey can be displayed in four-band mode.
  // Pairing method must be checked in BLE service / Android app.
  passkey_active = on;
  request_wake = true;
}
void wake() { request_wake = true; }
void next_screen() { request_wake = true; } // No extra screens.
void home_screen() { request_wake = true; }

static void screen_power(bool on) {
  if (on == display_on) return;
  display_on = on;
  if (on) {
    gfx->displayOn();
    gfx->setBrightness(brightness);
    for (auto &p : old_state) p = UINT32_MAX;
  } else gfx->displayOff();
  appstate::update([on](AppSnapshot& a) { a.sys.display_on = on; });
}
// Small built-in 5x7 font, scaled 2x. No LVGL, fonts on SD, or framebuffer.
struct Band { uint16_t color; const char* state; };
static bool old_blink[7] = {false,false,false,false,false,false,false};
static bool shutdown_drawn = false;
// AVO_UI_SEVEN_BANDS_V361: real snapshot data; stale samples never show OK.
static void draw_band(int i, uint16_t color, const char* title, const char* state) {
  const int top = LCD_HEIGHT*i/7;
  const int bottom = LCD_HEIGHT*(i+1)/7;
  gfx->fillRect(0,top,LCD_WIDTH,bottom-top,color);
  gfx->setTextColor(C_BLACK,color);
  // Scale to band height and title width; prevent clipping on 410px AMOLED.
  const int scale = (bottom-top >= 48 && strlen(title)*12 <= LCD_WIDTH-8) ? 2 : 1;
  gfx->setTextSize(scale);
  int x = (LCD_WIDTH - (int)strlen(title)*6*scale)/2;
  gfx->setCursor(x>0?x:0,top+4);
  gfx->print(title);
  const int state_scale = (strlen(state)*12 <= LCD_WIDTH-8 && bottom-top>=48) ? 2 : 1;
  gfx->setTextSize(state_scale);
  x=(LCD_WIDTH-(int)strlen(state)*6*state_scale)/2;
  gfx->setCursor(x>0?x:0,bottom-8*state_scale-4);
  gfx->print(state);
}
static void render(const AppSnapshot& s, uint32_t now) {
  const char* titles[7]={"BLUETOOTH","CHALECO","ESPALDA","CINCHA IMU","GPS / RTK","TARJETA SD","BATERIA"};
  Band b[7];
  b[0] = s.ble.connected && s.ble.authorized ? Band{C_GREEN,"CONECTADO"} :
         s.ble.claim_pending ? Band{C_AMBER,"PULSA BOOT"} : Band{C_RED,"SIN ENLACE"};
  const bool link_ok=s.link.connected && s.link.last_rx_ms && (uint32_t)(now-s.link.last_rx_ms)<2000;
  const bool sd_ok=s.storage.mounted && !s.storage.write_errors && s.storage.rec!=RecStatus::REC_ERROR;
  b[1]=link_ok && sd_ok ? Band{C_GREEN,"SISTEMA OK"} : Band{C_RED,"REVISAR"};
  b[2]=link_ok ? Band{C_GREEN,"CONECTADA"} : Band{C_RED,"SIN ENLACE"};
  const bool imu_ok=s.girth.connected &&
      s.girth.last_batch_ms[0] && s.girth.last_batch_ms[1] && s.girth.last_batch_ms[2] &&
      now-s.girth.last_batch_ms[0]<3000 &&
      now-s.girth.last_batch_ms[1]<3000 &&
      now-s.girth.last_batch_ms[2]<3000;
  b[3]=imu_ok ? Band{C_GREEN,"3 IMU OK"} : Band{C_RED,"IMU SIN DATOS"};
  if(!s.gnss.have || now-s.gnss.rx_ms>3000 || !s.gnss.s.gnss_fix_ok())
    b[4]={C_RED,"SIN GPS"};
  else if(s.gnss.s.carr_soln()==2) b[4]={C_GREEN,"RTK FIX"};
  else if(s.gnss.s.carr_soln()==1) b[4]={C_GREEN,"RTK FLOAT"};
  else if(s.gnss.s.diff_soln()) b[4]={C_GREEN,"DGNSS"};
  else b[4]={C_BLUE,"GNSS"};
  b[5]=!sd_ok ? Band{C_RED,"ERROR"} :
       s.storage.rec==RecStatus::RECORDING || s.storage.rec==RecStatus::TEMP_BUFFER ?
       Band{C_BLUE,"GRABANDO"} : Band{C_GREEN,"DISPONIBLE"};
  static char battery[12];
  const int pct=s.power.pmu.batt_pct;
  if(pct>=0 && pct<=100) snprintf(battery,sizeof(battery),"%d%%",pct);
  else snprintf(battery,sizeof(battery),"--%%");
  b[6]={pct<0?C_RED:pct<=20?C_RED:pct<=50?C_AMBER:C_GREEN,battery};
  const bool blink=((now/500)%2)!=0;
  for(int i=0;i<7;i++){
    // Include text in the cache key: GNSS state changes may retain the same colour.
    uint32_t key=b[i].color;
    for(const char* q=b[i].state;*q;++q) key=(key*33u)^(uint8_t)*q;
    const bool off=b[i].color==C_RED && blink;
    if(old_state[i]==key && old_blink[i]==off) continue;
    draw_band(i,off?C_BLACK:b[i].color,titles[i],b[i].state);
    old_state[i]=key; old_blink[i]=off;
  }
}
// Charging UI: PMIC VBUS detection; no guessed battery percentages.
// Radios remain available for OTA and data safety; see release notes.
static bool charge_screen = false;
static uint32_t charge_last_draw = 0;
// Snapshot the display state at the USB insertion edge, not during charging.
static bool usb_was_connected = false;
static bool display_before_usb = true;
static bool display_preference_during_usb = true;
static bool charging_forced_screen = false;
static void render_charging(const AppSnapshot& s, uint32_t now) {
  static int last_charge_pct = -999;
  const int current_pct = s.power.pmu.batt_pct;
  if (charge_screen && current_pct == last_charge_pct &&
      (uint32_t)(now - charge_last_draw) < 10000) return;
  last_charge_pct = current_pct;
  charge_last_draw = now;
  gfx->fillScreen(C_BLACK);
  gfx->setTextColor(0xFFFF, C_BLACK);
  gfx->setTextSize(3);
  const int pct = s.power.pmu.batt_pct;
  char value[16];
  if (pct >= 0 && pct <= 100) snprintf(value, sizeof(value), "%d%%", pct);
  else snprintf(value, sizeof(value), "--%%");
  const int cx = LCD_WIDTH / 2, cy = LCD_HEIGHT / 2 - 18;
  const int radius = (LCD_WIDTH < LCD_HEIGHT ? LCD_WIDTH : LCD_HEIGHT) / 2 - 54;
  for(int t=0;t<7;t++) gfx->drawCircle(cx,cy,radius-t,0x39E7);
  if (pct >= 0 && pct <= 100) {
    // Progress ring, green arc. Angle starts at 12 o'clock.
    const int steps = pct * 72 / 100;
    for (int i = 0; i < steps; ++i) {
      const float a = (i * 5.0f - 90.0f) * 0.01745329252f;
      const float b = ((i+1) * 5.0f - 90.0f) * 0.01745329252f;
      for(int t=0;t<7;t++) gfx->drawLine(cx + (int)((radius-t)*cosf(a)), cy + (int)((radius-t)*sinf(a)),
                    cx + (int)((radius-t)*cosf(b)), cy + (int)((radius-t)*sinf(b)), C_GREEN);
    }
  }
  gfx->setCursor(cx - (int)strlen(value)*9, cy - 18);
  gfx->print(value);
  gfx->setTextSize(3);
  const char* charging_label = pct == 100 ? "COMPLETA" : "CARGANDO...";
  gfx->setCursor(cx - (int)strlen(charging_label)*9, cy + radius + 12);
  gfx->print(charging_label);
}
static bool pair_latched = false;
static void task(void*) {
  auto* snap = static_cast<AppSnapshot*>(heap_caps_malloc(sizeof(AppSnapshot), MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT));
  if (!snap) {
    Serial.println("[AVO LITE] ERROR: no PSRAM for UI snapshot");
    vTaskDelete(nullptr);
    return;
  }
  new (snap) AppSnapshot();
  uint32_t last_update = 0;
  bool special_screen = false;
  for (;;) {
    const uint32_t now = sys::ms();
    if (request_wake) { request_wake = false; screen_power(true); }
    if (now - last_touch_ms >= 60) {
      last_touch_ms = now;
      bool pressed = false;
      int16_t x=0,y=0;
      if (board::touch_read(&pressed,&x,&y) && pressed) {
        if (!touch_start_ms) { touch_start_ms = now; pair_latched = false; }
        // V3.5.0: touch held 5 s anywhere = look for a back for 60 s (harmless if the own back is
        // alive: it simply answers again). Developer mode stays at 20 s.
        if (!pair_latched && now - touch_start_ms >= 5000) {
          pair_latched = true;
          uartlink::pair_start(60000);
          Serial.println("[AVO LITE] ESP-NOW pairing requested from the touch screen (60 s)");
        }
        if (!dev_latched && now - touch_start_ms >= 20000) {
          dev_latched = true;
          developer_mode = !developer_mode;
          appstate::update([](AppSnapshot& a) { a.sys.dev_mode = developer_mode; });
          Serial.printf("[AVO LITE] developer flag=%d (configuration via Android)\n", developer_mode);
        }
      } else { touch_start_ms = 0; dev_latched = false; }
    }
    if (now - last_update >= 250) {
      last_update = now;
      appstate::get(snap);
      cfgstore::get(&config_cache);
      uint8_t wanted = config_cache.brightness;
      if (config_cache.dim_on_low_batt && snap->power.level == PowerLevel::LOWBAT && wanted > 60) wanted = 60;
      const bool charging_usb = snap->power.pmu.online && snap->power.pmu.vbus;
      if (charging_usb && wanted > 25) wanted = 25;
      if (wanted != brightness) { brightness = wanted; if (display_on) gfx->setBrightness(brightness); }
      // USB insertion: remember whether the user was in normal or power-save
      // display mode. Wake for the charging screen without overwriting that
      // preference. Avoid treating the forced wake as a new user preference.
      if (charging_usb && !usb_was_connected) {
        display_before_usb = snap->sys.display_on;
        display_preference_during_usb = display_before_usb;
        charging_forced_screen = !display_before_usb;
        usb_was_connected = true;
        charge_last_draw = 0;
        screen_power(true);
        Serial.printf("[AVO UI] USB connected; previous display=%s\n",
                      display_before_usb ? "ON" : "SLEEP");
      } else if (!charging_usb && usb_was_connected) {
        usb_was_connected = false;
        // Restore only the display preference. Do not touch BLE, SD or recording.
        const bool restore_on = display_preference_during_usb;
        charging_forced_screen = false;
        charge_screen = false;
        screen_power(restore_on);
        Serial.printf("[AVO UI] USB removed; restored display=%s\n",
                      restore_on ? "ON" : "SLEEP");
      }
      if (!charging_usb) {
        if (!snap->sys.display_on && display_on && !snap->power.shutdown_requested && !passkey_active) screen_power(false);
        if (snap->sys.display_on && !display_on) screen_power(true);
      } else if (!display_on) {
        screen_power(true);
      }
      if (display_on) {
        const bool ota_notice = snap->ble.ota_display_status>=2 && snap->ble.ota_display_since_ms && (uint32_t)(now-snap->ble.ota_display_since_ms)<6000;
        const bool special_now = snap->ble.ota_active || ota_notice || snap->power.shutdown_requested || charging_usb;
        if(special_screen && !special_now) {
          gfx->fillScreen(C_BLACK);
          for(auto &v:old_state)v=UINT32_MAX;
          shutdown_drawn = false; // reset after a failed/cancelled shutdown
          charge_screen = false;
        }
        special_screen=special_now;
        // AVO_UI_OTA_PROGRESS_V361: OTA overrides USB display; real confirmed bytes.
        if (snap->ble.ota_active) {
          static uint32_t last_ota_draw=0;
          if(now-last_ota_draw>=200 || !last_ota_draw){
            last_ota_draw=now;
            gfx->fillScreen(C_BLACK);
            gfx->setTextColor(0xFFFF,C_BLACK);
            gfx->setTextSize(2);
            gfx->setCursor(12,LCD_HEIGHT/2-100);
            gfx->print("ACTUALIZANDO...");
            uint32_t pct=snap->ble.ota_total ?
              (uint32_t)((uint64_t)snap->ble.ota_bytes*99/snap->ble.ota_total):0;
            if(pct>99)pct=99;
            const int x=24,y=LCD_HEIGHT/2-12,w=LCD_WIDTH-48;
            gfx->fillRect(x,y,w,22,0x3186);
            gfx->fillRect(x,y,w*pct/100,22,0x07F0);
            gfx->setTextSize(5);
            char ota_percent[8];
            snprintf(ota_percent,sizeof(ota_percent),"%lu%%",(unsigned long)pct);
            gfx->setCursor((LCD_WIDTH-(int)strlen(ota_percent)*30)/2,y+42);
            gfx->print(ota_percent);
          }
          charge_screen=false;
          for(auto &v:old_state)v=UINT32_MAX;
        } else if (ota_notice && !snap->power.shutdown_requested) {
          // "VERIFICADA" means OTA image validated, not that new firmware has booted.
          // Redraw the notification when entering from the OTA progress screen.
          static uint32_t notice_last_draw = 0;
          static uint8_t last_notice_status = 0;
          if (!notice_last_draw || last_notice_status != snap->ble.ota_display_status ||
              (uint32_t)(now-notice_last_draw)>=1000) {
            last_notice_status = snap->ble.ota_display_status;
            notice_last_draw=now;
            gfx->fillScreen(C_BLACK);
            gfx->setTextColor(snap->ble.ota_display_status==2?C_GREEN:C_RED,C_BLACK);
            gfx->setTextSize(2);
            gfx->setCursor(12,LCD_HEIGHT/2-25);
            gfx->print(snap->ble.ota_display_status==2?"OTA VERIFICADA":"ERROR OTA");
            gfx->setCursor(12,LCD_HEIGHT/2+10);
            gfx->print(snap->ble.ota_display_status==2?"ESPERA REINICIO":"REVISA APP");
          }
          for(auto &v:old_state)v=UINT32_MAX;
        } else if (snap->power.shutdown_requested) {
          // AVO_UI_SAFE_SHUTDOWN_V361: one redraw per shutdown edge.
          if (!shutdown_drawn) {
          shutdown_drawn=true;
          gfx->fillScreen(C_BLACK);
          gfx->setTextColor(0xFFFF,C_BLACK);
          gfx->setTextSize(3);
          gfx->setCursor(20,LCD_HEIGHT/2-45);
          gfx->print("APAGANDO...");
          gfx->setTextSize(2);
          gfx->setCursor(20,LCD_HEIGHT/2+15);
          gfx->print("Guardando datos");
          }
        } else if (charging_usb) {
          if (!charge_screen) { charge_last_draw = 0; }
          render_charging(*snap, now);
          charge_screen = true;
        } else {
          if (charge_screen) { for (auto &p : old_state) p = UINT32_MAX; gfx->fillScreen(C_BLACK); }
          charge_screen = false;
          render(*snap,now);
        }
      }
    }
    vTaskDelay(pdMS_TO_TICKS(25));
  }
}
bool init() {
  bus = new Arduino_ESP32QSPI(PIN_LCD_CS,PIN_LCD_SCLK,PIN_LCD_SDIO0,PIN_LCD_SDIO1,PIN_LCD_SDIO2,PIN_LCD_SDIO3);
  gfx = new Arduino_CO5300(bus,PIN_LCD_RESET,0,LCD_WIDTH,LCD_HEIGHT,LCD_COL_OFFSET,0,0,0);
  if (!gfx || !gfx->begin()) return false;
  // AVO_UI_ROTATE_180_V361: rotate the panel, including OTA/charge/shutdown.
  gfx->setRotation(2);  // touch only uses duration, not X/Y coordinates
  gfx->fillScreen(C_BLACK);
  cfgstore::get(&config_cache);
  brightness = config_cache.brightness;
  gfx->setBrightness(brightness);
  board::touch_init();
  BaseType_t ok = xTaskCreatePinnedToCore(task,"ui_lite",4096,nullptr,2,&g_task_handles[TID_UI],0);
  Serial.printf("[AVO MEM] UI LITE task=%s internal=%u largest=%u psram=%u\n",ok==pdPASS?"OK":"FAIL",
    (unsigned)heap_caps_get_free_size(MALLOC_CAP_INTERNAL | MALLOC_CAP_8BIT),
    (unsigned)heap_caps_get_largest_free_block(MALLOC_CAP_INTERNAL | MALLOC_CAP_8BIT),
    (unsigned)ESP.getFreePsram());
  return ok == pdPASS;
}
} // namespace ui
