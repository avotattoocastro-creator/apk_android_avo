from pathlib import Path
p=Path(__file__).parent/'AVO_CHEST_V3_5_0/src'
ui=p/'ui.cpp'; s=ui.read_text()
old='''  gfx->setTextSize(2);
  int x = (LCD_WIDTH - (int)strlen(title)*12)/2;'''
new='''  // Scale to band height and title width; prevent clipping on 410px AMOLED.
  const int scale = (bottom-top >= 48 && strlen(title)*12 <= LCD_WIDTH-8) ? 2 : 1;
  gfx->setTextSize(scale);
  int x = (LCD_WIDTH - (int)strlen(title)*6*scale)/2;'''
assert s.count(old)==1;s=s.replace(old,new)
s=s.replace('''  x=(LCD_WIDTH-(int)strlen(state)*12)/2;
  gfx->setCursor(x>0?x:0,top+bottom-top-22);''','''  const int state_scale = (strlen(state)*12 <= LCD_WIDTH-8 && bottom-top>=48) ? 2 : 1;
  gfx->setTextSize(state_scale);
  x=(LCD_WIDTH-(int)strlen(state)*6*state_scale)/2;
  gfx->setCursor(x>0?x:0,bottom-8*state_scale-4);''')
old='''        } else if (snap->power.shutdown_requested) {
          // AVO_UI_SAFE_SHUTDOWN_V361: do not invent a percentage.
          gfx->fillScreen(C_BLACK);'''
new='''        } else if (snap->power.shutdown_requested) {
          // AVO_UI_SAFE_SHUTDOWN_V361: one redraw per shutdown edge.
          static bool shutdown_drawn=false;
          if (!shutdown_drawn) {
          shutdown_drawn=true;
          gfx->fillScreen(C_BLACK);'''
assert s.count(old)==1;s=s.replace(old,new)
s=s.replace('''          gfx->print("Guardando datos");
        } else if (charging_usb) {''','''          gfx->print("Guardando datos");
          }
        } else if (charging_usb) {''')
# Stop using overflow-prone arithmetic for link freshness, guard unset timestamps
s=s.replace('''const bool link_ok=s.link.connected && now-s.link.last_rx_ms<2000;''','''const bool link_ok=s.link.connected && s.link.last_rx_ms && (uint32_t)(now-s.link.last_rx_ms)<2000;''')
ui.write_text(s)
ble=p/'ble_service.cpp'; s=ble.read_text();old='''      const uint32_t next = off + (uint32_t)r.remaining();
      bool ok = ota::write(off, r.cur(), r.remaining(), err, sizeof(err));''';new='''      // Reject offset overflow before invoking flash writes.
      if (r.remaining() > UINT32_MAX - off) { respond(type, id, BleStatus::BAD_FORMAT); break; }
      const uint32_t next = off + (uint32_t)r.remaining();
      bool ok = ota::write(off, r.cur(), r.remaining(), err, sizeof(err));''';assert s.count(old)==1;s=s.replace(old,new);ble.write_text(s)
print('Applied UI bounds and OTA overflow fixes')
