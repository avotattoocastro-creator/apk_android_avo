from pathlib import Path
p=Path(__file__).parent/'AVO_CHEST_V3_5_0/src'
f=p/'ble_service.cpp'; s=f.read_text()
old='''      if (ok) {
        bb::log(BbCode::OTA, 0, 1, 0, "ota ok, reboot");
        vTaskDelay(pdMS_TO_TICKS(1500));
        storage::shutdown(5000);
        esp_restart();
      }'''
new='''      if (ok) {
        bb::log(BbCode::OTA, 0, 1, 0, "ota image verified; checking storage");
        vTaskDelay(pdMS_TO_TICKS(1500));
        // Do not reboot after a failed SD close: leave the device powered
        // so a damaged session can be inspected and recovered.
        if (!storage::shutdown(5000)) {
          bb::log(BbCode::SD_ERROR, 2, 0, 0, "OTA reboot deferred: SD close failed");
          appstate::update([](AppSnapshot& a) {
            a.ble.ota_display_status=3;
            a.ble.ota_display_since_ms=sys::ms();
          });
          break;
        }
        esp_restart();
      }'''
assert s.count(old)==1
s=s.replace(old,new)
# OTA_END must not ACK success to Android before ensuring SD is closed;
# original protocol ACK is already sent; preserve protocol for now, but report
# local reboot deferral clearly and never misrepresent it as rebooted.
f.write_text(s)
# Automated deterministic source checks. These are not compiler or hardware tests.
t=p.parent.parent/'tests/test_ota_sd_reboot.py'
t.parent.mkdir(exist_ok=True)
t.write_text('''from pathlib import Path
s=(Path(__file__).resolve().parents[1]/"AVO_CHEST_V3_5_0/src/ble_service.cpp").read_text()
assert "if (!storage::shutdown(5000))" in s
assert "OTA reboot deferred: SD close failed" in s
assert s.index("if (!storage::shutdown(5000))") < s.index("esp_restart();")
print("PASS: OTA reboot SD interlock static check")
''')
print('patched',f)
