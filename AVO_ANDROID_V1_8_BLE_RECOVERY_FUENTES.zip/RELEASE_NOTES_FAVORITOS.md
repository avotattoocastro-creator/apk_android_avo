AVO Android V1.8 — Favoritos de WhatsApp (desarrollo)

- Permite guardar hasta 12 nombres de destinatarios favoritos y marcar uno predeterminado.
- Conserva favoritos en copia JSON de configuración (sin contraseñas).
- Muestra el favorito predeterminado al abrir Android Sharesheet.
- WhatsApp NO garantiza abrir un chat específico con archivo adjunto desde terceros; el usuario selecciona y confirma el envío.
- Pendiente: prueba de interfaz en teléfono físico y asociación por caballo.
