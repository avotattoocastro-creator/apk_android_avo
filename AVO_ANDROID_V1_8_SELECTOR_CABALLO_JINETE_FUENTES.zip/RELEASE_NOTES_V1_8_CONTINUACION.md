# AVO Android V1.8 – Selección al compartir

- Al compartir una sesión sin nombre de caballo o jinete, aparece un diálogo con los registros existentes y la opción de escribir nombres nuevos.
- Los nombres nuevos se registran en el catálogo local, se vinculan a la sesión y se incluyen en el paquete .avo.
- El flujo normal continúa sin diálogo si ambos nombres ya están identificados.
- Importante: la compilación y prueba en dispositivo aún no se han validado en esta revisión.
