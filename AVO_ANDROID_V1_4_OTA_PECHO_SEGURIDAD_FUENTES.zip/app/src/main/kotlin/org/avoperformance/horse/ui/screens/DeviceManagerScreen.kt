package org.avoperformance.horse.ui.screens

import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedButton
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.remember
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import org.avoperformance.horse.core.ble.ChestOtaProtocol
import java.security.MessageDigest
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.compose.ui.Modifier
import org.avoperformance.horse.AppContainer
import org.avoperformance.horse.ui.components.AvoCard
import org.avoperformance.horse.ui.components.KV
import org.avoperformance.horse.ui.components.Note
import org.avoperformance.horse.ui.theme.AvoColors

/** Capability-driven, read-only device inventory. OTA is deliberately not enabled until
 *  firmware supports authenticated images, rollback, and chunked transport end to end. */
@Composable
fun DeviceManagerScreen(c: AppContainer) {
    var inspectedName by remember { mutableStateOf("Ningún firmware seleccionado") }
    var inspection by remember { mutableStateOf<ChestOtaProtocol.Inspection?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            runCatching {
                val bytes = c.app.contentResolver.openInputStream(uri)?.use { input ->
                    val out = java.io.ByteArrayOutputStream()
                    val buf = ByteArray(8192)
                    while (true) {
                        val n = input.read(buf)
                        if (n < 0) break
                        if (out.size() + n > ChestOtaProtocol.MAX_FILE_SIZE) error("Archivo demasiado grande")
                        out.write(buf, 0, n)
                    }
                    out.toByteArray()
                } ?: error("No se puede leer el archivo")
                inspectedName = uri.lastPathSegment ?: "firmware.bin"
                require(inspectedName.endsWith(".bin", ignoreCase = true)) { "Selecciona un .bin" }
                inspection = ChestOtaProtocol.inspect(bytes)
                error = null
            }.onFailure { error = it.message; inspection = null }
        }
    }
    val link by c.watch.state.collectAsStateWithLifecycle()
    val info by c.watch.info.collectAsStateWithLifecycle()
    val sample by c.watch.telemetry.collectAsStateWithLifecycle()
    val now = rememberNow()
    val age = sample?.let { (now - it.receivedMs).coerceAtLeast(0L) }
    val fresh = age != null && age <= 5000L
    val t = sample?.t?.takeIf { fresh }
    LazyColumn(Modifier.fillMaxSize()) {
        item {
            AvoCard("Dispositivos · estado real") {
                KV("Enlace Android ↔ pecho", link.texto)
                KV("Identificador BLE", c.watch.authorizedAddress ?: "No vinculado")
                KV("Firmware pecho", info?.firmware ?: "No comunicado")
                KV("Última telemetría", age?.let { "hace ${it} ms" } ?: "Sin datos")
                KV("Pecho ↔ espalda", t?.let { if (it.backLink) "Conectado" else "Sin enlace" } ?: "No verificado")
                KV("Espalda ↔ cincha", t?.let { if (it.girth) "Conectada" else "Sin datos" } ?: "No verificado")
                KV("Firmware espalda", "No comunicado")
                KV("Firmware cincha", "No comunicado")
                Note("El estado de espalda y cincha procede de la telemetría del pecho, no de conexiones directas al móvil.")
            }
        }
        item {
            AvoCard("Actualización de firmware · PECHO") {
                KV("Dispositivo", info?.deviceId ?: "Sin conectar")
                KV("Versión actual", info?.firmware ?: "Sin comunicar")
                KV("OTA anunciada", if (info?.supportsOta == true) "Sí" else "No verificada")
                KV("Archivo", inspectedName)
                KV("Tamaño", inspection?.let { "${it.size} bytes" } ?: "—")
                KV("Validación de estructura", inspection?.reason ?: "Pendiente de selección")
                KV("SHA-256", inspection?.sha256?.joinToString("") { "%02x".format(it.toInt() and 255) } ?: "—")
                OutlinedButton(onClick = { picker.launch(arrayOf("application/octet-stream", "*/*")) }) { Text("Seleccionar firmware .bin") }
                error?.let { Note("Error al leer archivo: $it") }
                Text("Instalación OTA bloqueada en V3.5.0: el firmware no verifica una firma criptográfica de origen. SHA-256 solo detecta modificaciones o errores de transferencia; no autentica al fabricante.", color = AvoColors.Warn)
                Button(enabled = false, onClick = {}) { Text("Actualizar pecho · pendiente de seguridad") }
                KV("OTA espalda", "No compatible todavía")
                Note("El archivo se inspecciona sin enviarse. No se modifica el reloj ni la microSD. El transporte BLE está implementado en el proyecto, pero no se permite activarlo hasta validar firma, particiones y recuperación en hardware real.")
            }
        }
        item {
            AvoCard("Arquitectura") {
                KV("Actual", "Android ↔ pecho BLE; pecho ↔ espalda ESP-NOW; espalda ↔ cincha ESP-NOW")
                KV("Futura V4", "Módulo único con capacidades anunciadas por firmware")
                Note("La futura arquitectura no debe habilitar funciones hasta que los dispositivos comuniquen sus capacidades reales.")
            }
        }
    }
}
