# AVO Android 1.3 — Entrega incremental

Base: Android 1.2. Actualización no destructiva, misma applicationId.

## Incorporado
- Pantalla «Dispositivos y OTA» accesible desde Inicio con estado BLE, firmware pecho, enlace con espalda y cincha, antigüedad real de telemetría y arquitectura declarada.
- Preparación de UI para actualización OTA, explícitamente deshabilitada hasta validación criptográfica, firma y protocolo de recuperación de pecho/espalda.
- Protección adicional contra una antigüedad de telemetría negativa en Inicio.
- Conserva visor y comparador GNSS de Android 1.2 e icono de caballo azul.

## No disponible aún
- Servidor real: se conserva NotConfiguredServer; no se finge sincronización online.
- OTA efectiva: requiere implementación coordinada en firmware, autorización de imágenes, transferencia y rollback.
- Reconstrucción y métricas avanzadas IMU: requiere especificación binaria y validación.
- Correcciones READ_FILE, RTCM/ESP-NOW, geocercas: requieren pruebas de integración con firmware real.
- Pantallas y métricas se basan en datos efectivamente recibidos, no hay valores simulados.

## Verificación
- El workflow CI ejecuta :core:test y :app:assembleDebug. Las pruebas con hardware se mantienen pendientes.
- APK debug: el certificado puede diferir del APK instalado; no desinstalar sin respaldo.
