package org.avoperformance.horse.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.width
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlinx.coroutines.launch
import org.avoperformance.horse.AppContainer
import org.avoperformance.horse.core.sync.SyncState
import org.avoperformance.horse.data.TrainingEntity
import org.avoperformance.horse.ui.components.AvoCard
import org.avoperformance.horse.ui.components.Fmt
import org.avoperformance.horse.ui.components.KV
import org.avoperformance.horse.ui.components.Note
import org.avoperformance.horse.ui.components.StatusPill
import org.avoperformance.horse.ui.theme.AvoColors

fun syncColor(s: SyncState?) = when (s) {
    SyncState.VERIFICADO_SERVIDOR, SyncState.MARCADO_EN_RELOJ -> AvoColors.Ok
    SyncState.VERIFICADO_LOCAL, SyncState.PENDIENTE_SERVIDOR -> AvoColors.Info
    SyncState.DESCARGANDO, SyncState.DESCARGADO, SyncState.SUBIENDO, SyncState.GRABANDO -> AvoColors.Warn
    SyncState.ERROR_INTEGRIDAD -> AvoColors.Bad
    else -> AvoColors.Unknown
}

@Composable
fun HistoryScreen(c: AppContainer, go: (String) -> Unit) {
    var tab by remember { mutableIntStateOf(0) }
    val all by c.db.trainings().all().collectAsStateWithLifecycle(emptyList())
    val progress by c.sync.progress.collectAsStateWithLifecycle()
    var msg by remember { mutableStateOf<String?>(null) }
    var horseFilter by remember { mutableStateOf("") }
    var compareFirst by remember { mutableStateOf<String?>(null) }
    var compareSecond by remember { mutableStateOf<String?>(null) }
    Column(Modifier.fillMaxSize()) {
        TabRow(selectedTabIndex = tab, containerColor = AvoColors.Bg, contentColor = AvoColors.Gold) {
            Tab(tab == 0, { tab = 0 }, text = { Text("Entrenamientos del chaleco") })
            Tab(tab == 1, { tab = 1 }, text = { Text("Mis entrenamientos") })
        }
        if (tab == 0) {
            Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedButton(enabled = !progress.busy, onClick = { c.scope.launch { msg = c.sync.refresh() } }) { Text("Leer lista del reloj") }
                OutlinedButton(enabled = !progress.busy, onClick = { c.sync.autoSync() }) { Text("Descargar todo") }
            }
            progress.message?.let { Note(it) }
            msg?.let { Note(it, AvoColors.Warn) }
            if (progress.busy && progress.total > 0) LinearProgressIndicator(progress = { (progress.bytes.toFloat() / progress.total).coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp))
            LazyColumn {
                items(all, key = { it.sessionId }) { t -> TrainingRow(t, onOpen = { go("detalle/${t.sessionId}") }, onDownload = { c.scope.launch { msg = c.sync.download(t.sessionId) } }) }
                if (all.isEmpty()) item { Note("Aún no hay entrenamientos. Conecta el chaleco y pulsa «Leer lista del reloj».") }
            }
        } else {
            val mine = all.filter { it.localDir != null && it.downloadedBytes > 0 &&
                (horseFilter.isBlank() || it.horseCode?.contains(horseFilter, ignoreCase = true) == true) }
            LazyColumn {
                item {
                    AvoCard("Análisis y comparación") {
                        TextField(value = horseFilter, onValueChange = { horseFilter = it }, label = { Text("Filtrar por caballo") }, singleLine = true)
                        Note("Abre un entrenamiento para ver velocidad, aceleración, ritmo, tramos y GPS. Para comparar, elige A y B entre las sesiones del mismo caballo.")
                        val eligible = mine.filter { it.horseCode != null }
                        eligible.forEach { t ->
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text((t.horseCode ?: "") + " · " + (Fmt.date(t.startRtcMs) ?: t.sessionId), modifier = Modifier.weight(1f), maxLines = 1)
                                OutlinedButton(onClick = { compareFirst = t.sessionId }) { Text(if (compareFirst == t.sessionId) "A ✓" else "A") }
                                OutlinedButton(onClick = { compareSecond = t.sessionId }) { Text(if (compareSecond == t.sessionId) "B ✓" else "B") }
                            }
                        }
                        val first = all.firstOrNull { it.sessionId == compareFirst }
                        val second = all.firstOrNull { it.sessionId == compareSecond }
                        OutlinedButton(enabled = first != null && second != null && first.sessionId != second.sessionId && first.horseCode == second.horseCode,
                            onClick = { go("comparar/${first?.sessionId}/${second?.sessionId}") }) { Text("Comparar entrenamientos") }
                        if (first != null && second != null && first.horseCode != second.horseCode) Note("La comparación requiere el mismo caballo", AvoColors.Warn)
                    }
                }
                item {
                    AvoCard("Servidor") {
                        Note(if (c.sync.serverConfigured) "Conectado" else "Servidor pendiente de configurar: los entrenamientos se guardan en el teléfono y se subirán cuando exista el servidor.")
                    }
                }
                items(mine, key = { it.sessionId }) { t -> TrainingRow(t, onOpen = { go("detalle/${t.sessionId}") }, onDownload = null) }
                if (mine.isEmpty()) item { Note("No hay entrenamientos descargados en este teléfono.") }
            }
        }
    }
}

@Composable
private fun TrainingRow(t: TrainingEntity, onOpen: () -> Unit, onDownload: (() -> Unit)?) {
    val st = runCatching { SyncState.valueOf(t.state) }.getOrNull()
    AvoCard(onClick = onOpen) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(Fmt.date(t.startRtcMs) ?: "Fecha desconocida", color = AvoColors.Text)
                Text(t.sessionId, color = AvoColors.TextDim, fontSize = 12.sp)
            }
            StatusPill(st?.texto?.substringBefore(" (")?.take(26) ?: t.state, syncColor(st))
        }
        KV("Caballo / jinete", listOfNotNull(t.horseCode, t.riderCode).joinToString(" / ").ifBlank { null })
        KV("Duración activa", Fmt.duration(t.activeMs))
        KV("Tamaño", if (t.downloadedBytes in 1 until t.totalBytes) "${Fmt.bytes(t.downloadedBytes)} de ${Fmt.bytes(t.totalBytes)}" else Fmt.bytes(t.totalBytes))
        t.distanceM?.let { KV("Distancia", "${Fmt.m(it, 0)} m") }
        t.lastError?.let { Note(it, AvoColors.Warn) }
        if (onDownload != null && (st == SyncState.EN_RELOJ || st == SyncState.DESCARGANDO || st == SyncState.ERROR_INTEGRIDAD))
            OutlinedButton(onClick = onDownload) { Text(if (t.downloadedBytes > 0) "Reanudar descarga" else "Descargar") }
    }
}
