package org.avoperformance.horse.ui.screens

import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.compose.ui.Modifier
import org.avoperformance.horse.AppContainer
import org.avoperformance.horse.ui.components.AvoCard
import org.avoperformance.horse.ui.components.KV
import org.avoperformance.horse.ui.components.Note
import org.avoperformance.horse.ui.theme.AvoColors

/** Capability-driven, read-only device inventory. OTA is deliberately not enabled until
 *  firmware supports authenticated images, rollback, and chunked transport end to end. */
@Composable
fun DeviceManagerScreen(c: AppContainer) {
    val link by c.watch.state.collectAsStateWithLifecycle()
    val info by c.watch.info.collectAsStateWithLifecycle()
    val sample by c.watch.telemetry.collectAsStateWithLifecycle()
    val now = rememberNow()
    val age = sample?.let { (now - it.receivedMs).coerceAtLeast(0L) }
    val fresh = age != null && age <= 5000L
    val t = sample?.t?.takeIf { fresh }
    LazyColumn(Modifier.fillMaxSize()) {
        item {
            AvoCard("Dispositivos · estado real") {
                KV("Enlace Android ↔ pecho", link.texto)
                KV("Identificador BLE", c.watch.authorizedAddress ?: "No vinculado")
                KV("Firmware pecho", info?.firmware ?: "No comunicado")
                KV("Última telemetría", age?.let { "hace ${it} ms" } ?: "Sin datos")
                KV("Pecho ↔ espalda", t?.let { if (it.backLink) "Conectado" else "Sin enlace" } ?: "No verificado")
                KV("Espalda ↔ cincha", t?.let { if (it.girth) "Conectada" else "Sin datos" } ?: "No verificado")
                KV("Firmware espalda", "No comunicado")
                KV("Firmware cincha", "No comunicado")
                Note("El estado de espalda y cincha procede de la telemetría del pecho, no de conexiones directas al móvil.")
            }
        }
        item {
            AvoCard("Actualización inalámbrica · OTA") {
                Text("No disponible todavía", color = AvoColors.Warn)
                Note("Por seguridad, el envío OTA permanece desactivado hasta validar el protocolo de ambos firmwares, la firma de imágenes, la integridad, la batería y la recuperación tras fallo.")
                KV("Pecho por BLE", "Pendiente de compatibilidad validada")
                KV("Espalda vía pecho / ESP-NOW", "Pendiente de protocolo OTA extremo a extremo")
            }
        }
        item {
            AvoCard("Arquitectura") {
                KV("Actual", "Android ↔ pecho BLE; pecho ↔ espalda ESP-NOW; espalda ↔ cincha ESP-NOW")
                KV("Futura V4", "Módulo único con capacidades anunciadas por firmware")
                Note("La futura arquitectura no debe habilitar funciones hasta que los dispositivos comuniquen sus capacidades reales.")
            }
        }
    }
}
