package org.avoperformance.horse.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.HorizontalDivider
import androidx.compose.ui.graphics.Color
import kotlin.math.abs
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.avoperformance.horse.AppContainer
import org.avoperformance.horse.core.geo.LocalFrame
import org.avoperformance.horse.core.raw.TrainingAnalysis
import org.avoperformance.horse.core.sync.SyncRules
import org.avoperformance.horse.core.sync.SyncState
import org.avoperformance.horse.ui.components.AvoCard
import org.avoperformance.horse.ui.components.ConfirmDialog
import org.avoperformance.horse.ui.components.Fmt
import org.avoperformance.horse.ui.components.KV
import org.avoperformance.horse.ui.components.Note
import org.avoperformance.horse.ui.components.StatusPill
import org.avoperformance.horse.ui.theme.AvoColors

@Composable
fun TrainingDetailScreen(c: AppContainer, id: String) {
    val t by c.db.trainings().observe(id).collectAsStateWithLifecycle(null)
    var analysis by remember { mutableStateOf<TrainingAnalysis?>(null) }
    var loading by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf<String?>(null) }
    var confirmDelete by remember { mutableStateOf(false) }
    val tt = t
    LaunchedEffect(tt?.localDir, tt?.downloadedBytes, tt?.state) {
        if (tt?.localDir != null && (tt.state == SyncState.VERIFICADO_LOCAL.name || tt.state == SyncState.PENDIENTE_SERVIDOR.name ||
                tt.state == SyncState.VERIFICADO_SERVIDOR.name || tt.state == SyncState.MARCADO_EN_RELOJ.name || tt.state == SyncState.DESCARGADO.name)) {
            loading = true
            analysis = withContext(Dispatchers.IO) { runCatching { c.sync.analysisFor(tt) }.getOrNull() }
            loading = false
        }
    }
    if (tt == null) { Note("Entrenamiento no encontrado"); return }
    val st = runCatching { SyncState.valueOf(tt.state) }.getOrNull()
    val a = analysis

    LazyColumn(Modifier.fillMaxSize()) {
        item {
            AvoCard("Resumen") {
                Row { StatusPill(st?.texto ?: tt.state, syncColor(st)) }
                KV("Inicio", Fmt.date(tt.startRtcMs))
                KV("Sesión", tt.sessionId)
                KV("Caballo", tt.horseCode)
                KV("Jinete", tt.riderCode)
                KV("Tiempo activo (reloj)", Fmt.duration(tt.activeMs))
                KV("Tamaño", Fmt.bytes(tt.totalBytes))
                KV("SHA-256 local", tt.localSha256?.take(16)?.plus("…"))
                KV("SHA-256 del reloj", tt.watchSha256?.take(16)?.plus("…"))
                KV("Servidor", if (tt.serverSha256 != null) "verificado" else if (c.sync.serverConfigured) "pendiente" else "no configurado")
                msg?.let { Note(it, AvoColors.Warn) }
            }
        }
        if (loading) item { Note("Analizando el fichero…") }
        if (a != null) {
            item {
                AvoCard("Análisis (datos del fichero)") {
                    KV("Distancia", "${Fmt.m(a.distanceM, 0)} m")
                    KV("Duración con GNSS", a.durationS?.let { Fmt.duration((it * 1000).toLong()) })
                    KV("Velocidad media", a.avgSpeedMs?.let { "${Fmt.kmh(it)} km/h" })
                    KV("Velocidad máxima", "${Fmt.kmh(a.maxSpeedMs)} km/h")
                    KV("Tiempo en RTK FIX", a.fixTimeS?.let { "${Fmt.m(it, 0)} s (${pct(a.fixEpochs, a.gnssUsable)})" })
                    KV("Tiempo en RTK FLOAT", a.floatTimeS?.let { "${Fmt.m(it, 0)} s (${pct(a.floatEpochs, a.gnssUsable)})" })
                    KV("Épocas sin solución", "${a.noFix}")
                    KV("Muestras GNSS válidas", "${a.gnssUsable} de ${a.gnssSamples}")
                    KV("IMU de la cincha", if (a.imuAvailable) "${a.imuSamples} muestras" else "no disponible en este entrenamiento")
                    KV("Marcadores", "${a.markers}")
                    KV("Cierre del fichero", if (a.scan.cleanClose) "limpio" else "recuperado / sin cierre limpio")
                    if (a.scan.tailGarbage) Note("El último bloque estaba incompleto (corte de alimentación); se ignoró.", AvoColors.Warn)
                }
            }
            if (a.track.size >= 2) {
                item { AvoCard("Recorrido (color = calidad RTK)") { TrackCanvas(a) ; Legend() } }
                item { AvoCard("Velocidad") { SpeedChart(a) } }
                item { AvoCard("Aceleración longitudinal GNSS") {
                    Note("Derivada de la velocidad GNSS; no sustituye a la aceleración de las IMU. Se omiten saltos de tiempo y valores espurios.")
                    val acc = accelerationSeries(a)
                    if (acc.size > 1) {
                        KV("Aceleración máxima", "%.2f m/s²".format(acc.maxOrNull() ?: 0.0))
                        KV("Frenada máxima", "%.2f m/s²".format(acc.minOrNull() ?: 0.0))
                        SeriesChart(acc, AvoColors.Warn, signed = true)
                    } else Note("No hay suficientes muestras GNSS válidas")
                } }
                item { AvoCard("Ritmo y regularidad") {
                    KV("Ritmo medio", a.avgSpeedMs?.takeIf { it > 0.5 }?.let { "%.1f s/100 m".format(100.0 / it) })
                    val speeds = a.track.map { it.speedMs }.filter { it > 0.5 && it.isFinite() }
                    val mean = speeds.average().takeIf { !it.isNaN() && it > 0 } ?: 0.0
                    val variation = if (speeds.size >= 3 && mean > 0) kotlin.math.sqrt(speeds.map { (it-mean)*(it-mean) }.average()) / mean * 100 else null
                    KV("Variación de velocidad", variation?.let { "%.1f %%".format(it) })
                    Note("Menos variación indica velocidad más uniforme; depende del trazado y el tipo de ejercicio.")
                } }
                item { AvoCard("Análisis por tramos") {
                    val points = a.track
                    val first = points.first().itowMs
                    val last = points.last().itowMs
                    val step = 30_000L
                    var start = first
                    while (start < last && step > 0) {
                        val window = points.filter { it.itowMs in start until (start + step) }
                        if (window.isNotEmpty()) {
                            val avg = window.map { it.speedMs }.average()
                            KV("${(start-first)/1000}–${(start-first)/1000+30} s", "%.1f km/h media · %.1f km/h máx".format(avg * 3.6, (window.maxOfOrNull { it.speedMs } ?: 0.0) * 3.6))
                        }
                        start += step
                    }
                } }
            }
        }
        item {
            AvoCard("Acciones") {
                OutlinedButton(enabled = SyncRules.canOfferDelete(org.avoperformance.horse.core.sync.LocalTraining(tt.sessionId, tt.segments, tt.totalBytes,
                    tt.downloadedBytes, tt.localSha256, tt.watchSha256, tt.serverSha256, st ?: SyncState.EN_RELOJ,
                    org.avoperformance.horse.core.ble.WatchFileState.UNKNOWN, tt.startRtcMs, tt.activeMs)), onClick = { confirmDelete = true }) {
                    Text("Borrar del reloj")
                }
                Note("La app nunca borra nada del reloj por su cuenta. Solo se puede borrar un entrenamiento verificado por el servidor, y el propio reloj lo comprueba.")
            }
        }
    }
    if (confirmDelete) ConfirmDialog("Borrar del reloj", "Se borrará ${tt.sessionId} de la tarjeta del chaleco. La copia del teléfono se conserva.", "Borrar", danger = true,
        onConfirm = { c.scope.launch { msg = c.sync.deleteFromWatch(tt.sessionId) ?: "Borrado del reloj" } }, onDismiss = { confirmDelete = false })
}

private fun pct(n: Int, d: Int) = if (d > 0) "${n * 100 / d} %" else "—"

@Composable
private fun TrackCanvas(a: TrainingAnalysis) {
    val pts = a.track
    val fr = LocalFrame(pts.first().p)
    val xy = pts.map { fr.toXY(it.p) }
    val minX = xy.minOf { it.first }; val maxX = xy.maxOf { it.first }
    val minY = xy.minOf { it.second }; val maxY = xy.maxOf { it.second }
    Canvas(Modifier.fillMaxWidth().height(280.dp).background(AvoColors.Surface2)) {
        val span = maxOf(maxX - minX, maxY - minY, 1.0)
        val s = (minOf(size.width, size.height) * 0.9f) / span.toFloat()
        val ox = (size.width - (maxX - minX).toFloat() * s) / 2
        val oy = (size.height - (maxY - minY).toFloat() * s) / 2
        fun o(i: Int) = Offset(ox + ((xy[i].first - minX).toFloat() * s), size.height - (oy + ((xy[i].second - minY).toFloat() * s)))
        for (i in 1 until xy.size) {
            val col = when (pts[i].carrSoln) { 2 -> AvoColors.Ok; 1 -> AvoColors.Warn; else -> AvoColors.TextDim }
            drawLine(col, o(i - 1), o(i), strokeWidth = 4f)
        }
        drawCircle(AvoColors.Gold, 8f, o(0))
    }
}

@Composable
private fun Legend() {
    Row {
        Text("■ FIX  ", color = AvoColors.Ok); Text("■ FLOAT  ", color = AvoColors.Warn); Text("■ otra", color = AvoColors.TextDim)
    }
}

@Composable
private fun SpeedChart(a: TrainingAnalysis) {
    val v = a.track.map { it.speedMs }
    val maxV = (v.maxOrNull() ?: 1.0).coerceAtLeast(0.5)
    Text("Máx. ${Fmt.kmh(maxV)} km/h", color = AvoColors.TextDim)
    Canvas(Modifier.fillMaxWidth().height(160.dp).background(AvoColors.Surface2)) {
        val p = Path()
        v.forEachIndexed { i, s ->
            val x = size.width * i / (v.size - 1).coerceAtLeast(1)
            val y = size.height * (1f - (s / maxV).toFloat())
            if (i == 0) p.moveTo(x, y) else p.lineTo(x, y)
        }
        drawPath(p, AvoColors.Gold, style = Stroke(width = 3f))
    }
}

/** Exclude invalid GPS time jumps, week rollover and noise spikes. */
private fun accelerationSeries(a: TrainingAnalysis): List<Double> = a.track.zipWithNext().mapNotNull { (p, q) ->
    val dt = (q.itowMs - p.itowMs) / 1000.0
    if (dt !in 0.08..10.0 || !p.speedMs.isFinite() || !q.speedMs.isFinite()) null
    else ((q.speedMs-p.speedMs)/dt).takeIf { it.isFinite() && abs(it) <= 12.0 }
}

@Composable
private fun SeriesChart(values: List<Double>, col: Color, signed: Boolean = false) {
    if (values.size < 2) return
    val low = if (signed) minOf(values.minOrNull() ?: 0.0, 0.0) else 0.0
    val high = maxOf(values.maxOrNull() ?: 1.0, 0.0)
    val span = (high-low).coerceAtLeast(0.01)
    Canvas(Modifier.fillMaxWidth().height(165.dp).background(AvoColors.Surface2)) {
        val path = Path()
        values.forEachIndexed { i, v ->
            val x = size.width * i / (values.size-1)
            val y = (size.height * (1 - (v-low)/span)).toFloat().coerceIn(0f,size.height)
            if (i == 0) path.moveTo(x,y) else path.lineTo(x,y)
        }
        if (low < 0 && high > 0) {
            val zeroY = (size.height * high/span).toFloat()
            drawLine(AvoColors.TextDim, Offset(0f,zeroY), Offset(size.width,zeroY), strokeWidth=1f)
        }
        drawPath(path,col,style=Stroke(width=3f))
    }
}
