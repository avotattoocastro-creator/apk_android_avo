package org.avoperformance.horse.data

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import org.avoperformance.horse.core.ntrip.NtripConfig
import org.avoperformance.horse.core.ntrip.NtripVersion
import org.avoperformance.horse.security.SecureStore

/** Non-secret preferences. Secrets go to [SecureStore]. */
class Settings(ctx: Context, private val secure: SecureStore) {
    private val p = ctx.getSharedPreferences("avo_settings", Context.MODE_PRIVATE)

    data class Ntrip(
        val enabled: Boolean = false, val host: String = "", val port: Int = 2101, val mountpoint: String = "",
        val user: String = "", val tls: Boolean = false, val v2: Boolean = true, val sendGga: Boolean = true,
        val ggaIntervalS: Int = 10, val timeoutS: Int = 15, val reconnect: Boolean = true,
    )

    private val _ntrip = MutableStateFlow(loadNtrip())
    val ntrip: StateFlow<Ntrip> = _ntrip

    private fun loadNtrip() = Ntrip(
        p.getBoolean("ntrip.enabled", false), p.getString("ntrip.host", "")!!, p.getInt("ntrip.port", 2101),
        p.getString("ntrip.mount", "")!!, p.getString("ntrip.user", "")!!, p.getBoolean("ntrip.tls", false),
        p.getBoolean("ntrip.v2", true), p.getBoolean("ntrip.gga", true), p.getInt("ntrip.ggaS", 10),
        p.getInt("ntrip.timeoutS", 15), p.getBoolean("ntrip.reconnect", true),
    )

    fun saveNtrip(n: Ntrip, password: String?) {
        p.edit().putBoolean("ntrip.enabled", n.enabled).putString("ntrip.host", n.host.trim()).putInt("ntrip.port", n.port)
            .putString("ntrip.mount", n.mountpoint.trim()).putString("ntrip.user", n.user).putBoolean("ntrip.tls", n.tls)
            .putBoolean("ntrip.v2", n.v2).putBoolean("ntrip.gga", n.sendGga).putInt("ntrip.ggaS", n.ggaIntervalS)
            .putInt("ntrip.timeoutS", n.timeoutS).putBoolean("ntrip.reconnect", n.reconnect).apply()
        if (password != null) secure.ntripPassword = password
        _ntrip.value = n
    }

    fun ntripConfig(): NtripConfig {
        val n = _ntrip.value
        return NtripConfig(n.host, n.port, n.mountpoint, n.user, secure.ntripPassword ?: "", n.tls,
            if (n.v2) NtripVersion.V2 else NtripVersion.V1, n.sendGga, n.ggaIntervalS, 10_000, n.timeoutS * 1000, n.reconnect)
    }

    /** The single watch this phone is allowed to talk to (BLE address). */
    var authorizedWatch: String?
        get() = p.getString("watch.address", null)
        set(v) { p.edit().putString("watch.address", v).apply() }
    var authorizedWatchName: String?
        get() = p.getString("watch.name", null)
        set(v) { p.edit().putString("watch.name", v).apply() }

    var selectedHorseId: Long
        get() = p.getLong("sel.horse", 0)
        set(v) { p.edit().putLong("sel.horse", v).apply() }
    var selectedRiderId: Long
        get() = p.getLong("sel.rider", 0)
        set(v) { p.edit().putLong("sel.rider", v).apply() }

    var autoDownload: Boolean
        get() = p.getBoolean("sync.autoDownload", true)
        set(v) { p.edit().putBoolean("sync.autoDownload", v).apply() }
}
