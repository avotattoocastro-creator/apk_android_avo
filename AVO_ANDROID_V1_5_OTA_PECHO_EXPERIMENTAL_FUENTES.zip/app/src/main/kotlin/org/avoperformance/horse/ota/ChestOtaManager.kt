package org.avoperformance.horse.ota

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.withContext
import org.avoperformance.horse.AppContainer
import org.avoperformance.horse.core.ble.BleStatus
import org.avoperformance.horse.core.ble.ChestOtaProtocol
import org.avoperformance.horse.core.ble.Idempotency
import org.avoperformance.horse.core.ble.MsgType
import org.avoperformance.horse.core.ble.WatchSessionState

/** Transfer engine for V3.5.0. Not exposed for execution until signed firmware
 * authenticity and hardware rollback have been verified on an actual watch.
 * Reconnect/version checking is intentionally not misrepresented as tested. */
class ChestOtaManager(private val container: AppContainer) {
    data class State(val phase: String = "Sin actualización", val confirmed: Int = 0, val total: Int = 0, val error: String? = null)
    private val _state = MutableStateFlow(State())
    val state: StateFlow<State> = _state
    @Volatile private var active = false
    @Volatile private var cancelRequested = false

    /** Experimental, narrowly-scoped trust gate: only the GitHub-built AVO V3.5.4 image.
     *  This digest is pinned from the previously verified build artifact. No generic unsigned OTA.
     */
    private val approvedSha256 = "a483f6b93befb50768f9c7486668891358ba76b0da559dbea29cb994c0a88d20"
    fun isApproved(image: ByteArray): Boolean = ChestOtaProtocol.inspect(image).sha256.joinToString("") { "%02x".format(it.toInt() and 255) } == approvedSha256
    val safeInstallationAvailable: Boolean = true
    fun cancel() { cancelRequested = true }

    suspend fun transfer(image: ByteArray) = withContext(Dispatchers.IO) {
        check(isApproved(image)) { "Imagen no autorizada: solo se admite AVO_CHEST_V3_5_4_SD_FIX.bin con SHA-256 verificado" }
        check(!active) { "Otra actualización ya está activa" }
        active = true
        cancelRequested = false
        var began = false
        try {
            val precheck = ChestOtaProtocol.inspect(image)
            require(precheck.valid) { precheck.reason }
            val watch = container.watch
            check(watch.isReady) { "Pecho sin conexión/autorización" }
            check(watch.info.value?.supportsOta == true) { "Firmware sin capacidad OTA anunciada" }
            val status = watch.client!!.getStatus()
            check(status.session != WatchSessionState.RECORDING && status.rec != org.avoperformance.horse.core.ble.RecStatus.RECORDING) { "Entrenamiento activo" }
            val battery = status.batteryPct
            check(battery != null && battery >= 60) { "Batería no verificable o inferior al 60 %" }
            check(!container.ntrip.running) { "Detén NTRIP antes de actualizar" }
            check(!container.sync.isBusy) { "Descarga de entrenamientos en curso" }
            _state.value = State("Preparando", 0, image.size)
            val client = watch.client!!
            val b = client.request(MsgType.OTA_BEGIN, ChestOtaProtocol.beginPayload(image), Idempotency.STATE_CHANGING, 12000, 0)
            check(b.statusEnum == BleStatus.OK) { "OTA_BEGIN rechazado: ${b.statusEnum.texto}" }
            began = true
            var offset = 0
            while (offset < image.size) {
                if (cancelRequested) throw CancellationException("Cancelada por el usuario")
                val size = minOf(128, image.size - offset)
                val reply = client.request(MsgType.OTA_DATA, ChestOtaProtocol.dataPayload(offset, image, size), Idempotency.STATE_CHANGING, 12000, 0)
                check(reply.statusEnum == BleStatus.OK) { "OTA_DATA ${offset}: ${reply.statusEnum.texto}" }
                val ackOffset = ChestOtaProtocol.confirmedOffset(reply.payload)
                check(ackOffset == (offset + size).toLong()) { "Desplazamiento no confirmado en $offset" }
                offset += size
                _state.value = State("Transfiriendo", offset, image.size)
            }
            _state.value = State("Verificando en el pecho", offset, image.size)
            val end = client.request(MsgType.OTA_END, idem = Idempotency.STATE_CHANGING, timeoutMs = 15000, retries = 0)
            check(end.statusEnum == BleStatus.OK) { "OTA_END: ${end.statusEnum.texto}" }
            _state.value = State("Transferido; esperando reinicio (comprobar versión manualmente)", offset, image.size)
        } catch (t: Throwable) {
            if (began) runCatching { container.watch.client?.request(MsgType.OTA_ABORT, idem = Idempotency.STATE_CHANGING, timeoutMs = 2000, retries = 0) }
            _state.value = _state.value.copy(phase = "Error", error = t.message)
            throw t
        } finally { active = false }
    }
}
