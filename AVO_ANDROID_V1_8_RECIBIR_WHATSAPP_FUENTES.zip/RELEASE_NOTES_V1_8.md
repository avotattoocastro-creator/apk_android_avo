# AVO Android V1.8 — entrega inicial verificable
- Corrige recreación de bienvenida al rotar (rememberSaveable).
- Dashboard LIVE: BLE, ESP, RTK y REC en cuatro indicadores; velocidad, precisión y satélites.
- Resumen de sesión con indicadores y metadatos técnicos al final.
- Botón compartir en historial: descarga si falta, exige SHA-256 coincidente, crea paquete .avo y abre selector de apps/WhatsApp.
- El intercambio depende de la confirmación del usuario en WhatsApp.
- No implementado en este build: favoritos WhatsApp de envío directo, importación .avo, backup/restauración, DND, mapa interactivo, reproducción sincronizada, diseño global de fondo, pruebas físicas BLE/NTRIP.
- Mantiene reconexión BLE de V1.7 sin cambios. OTA experimental sigue sin firma criptográfica.
