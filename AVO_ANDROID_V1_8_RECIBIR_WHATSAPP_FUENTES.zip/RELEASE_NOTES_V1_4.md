# AVO Performance Horse Android V1.4 — OTA de pecho: integración restringida

## Verificación de firmware
Fuente: AVO_V3_5_0_ESPNOW_COMPLETO/FUENTES_FIRMWARE/AVO_CHEST_V3_5_0/src/ble_service.cpp (líneas 454–489) y src/ota.cpp.
* OTA_BEGIN (0x50): payload LE uint32 tamaño + 32 bytes SHA-256; respuesta BleStatus.
* OTA_DATA (0x51): payload LE uint32 offset + datos; respuesta payload uint32 offset confirmado.
* OTA_END (0x52): payload vacío; respuesta OK, después cierre SD y reboot (retraso 1500 ms).
* OTA_ABORT (0x53): payload vacío.
* BLE servicio y canales de control coinciden con AvoGatt de Android.
* Escritura de OTA secuencial, sin reanudación en el reloj. No reintentar OTA_DATA sin resincronización del offset: duplicados devuelven IO_ERROR.
* Marcador de compatibilidad de imagen: AVOCHEST-IMG-V1:WS-AMOLED-2.06.
* Firmware V3.5.0 verifica SHA256, imagen ESP y marcador antes de instalar y anuncia soporte OTA; **no verifica firma de autenticidad** (Secure Boot v2 deshabilitado). El marcador es texto, no una firma.
* Capacidad de partición OTA y versión de destino **no se comunican de manera verificable** mediante GET_INFO. No inferirlas.
* Estado de microSD: firmware llama storage::shutdown(5000) tras OTA_END. No hay prueba física del comportamiento.

## Implementación Android
* Selector de documentos SAF para .bin.
* Inspección preliminar de cabecera ESP, marcador AVO, tamaño y SHA256.
* Motor de transferencia por comandos existentes, fragmentos <=1024, comprobación de offset, estado y aborto.
* Bloqueo de inicio por ausencia de firma criptográfica y falta de validación física. El envío **NO está habilitado**.
* Se conserva la pantalla de dispositivos V1.3 y funciones anteriores.

## Validación pendiente
1. Firmware firmado y comprobación de autenticidad incorporada al propio pecho.
2. Protocolo que informe tamaño de partición, hardware y requisitos de batería.
3. Exclusión simultánea de NTRIP, grabación y descargas en app y reloj.
4. Servicio de Android para mantener una OTA activa en segundo plano.
5. Test real BLE, interrupción, rollback, reconexión y lectura de SD.
6. Confirmación de versión antes de permitir indicar "completado".

No instalar imagen por OTA basándose únicamente en SHA256. No usar el .merged.bin para OTA: seleccionar binario exclusivo de aplicación.
