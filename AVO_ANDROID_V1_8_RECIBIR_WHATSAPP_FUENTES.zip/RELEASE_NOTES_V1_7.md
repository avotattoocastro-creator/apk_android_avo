# AVO Android V1.7 — Diagnóstico OTA
- Registra OTA_BEGIN confirmado, offset total OTA_DATA y resultado exacto de OTA_END.
- Distingue desconexión/reinicio de versión nueva confirmada mediante GET_INFO.
- Espera hasta 90 s después de OTA_END; muestra explícitamente si no se confirma una nueva versión.
- No modifica firmware del pecho ni archivos SD.
- OTA V3.5.4 sigue siendo experimental y no autoriza reintentos automáticos.
- Pendiente prueba de hardware: firmware 3.5.0, timeouts de ACK en reinicio, rollback, coherencia BLE y telemetría.
