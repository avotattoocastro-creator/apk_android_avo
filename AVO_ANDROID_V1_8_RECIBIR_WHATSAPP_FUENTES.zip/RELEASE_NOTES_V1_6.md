# AVO Android V1.6 — Corrección selector OTA SAF

- Corregido el nombre de firmware mediante `OpenableColumns.DISPLAY_NAME` en lugar de `Uri.lastPathSegment` (p. ej. `5657`).
- El contenido se valida con `ChestOtaProtocol.inspect` y SHA-256; no se habilita OTA por extensión sola.
- Se mantiene whitelist de imagen autorizada V3.5.4 y todas las limitaciones OTA experimentales de V1.5.
- Sin modificaciones al firmware ni a los archivos microSD.
- Pendiente: prueba física de instalación OTA sobre Waveshare.
