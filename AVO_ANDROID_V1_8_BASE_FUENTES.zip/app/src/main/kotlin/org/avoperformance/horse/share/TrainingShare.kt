package org.avoperformance.horse.share

import android.content.Context
import android.content.Intent
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.avoperformance.horse.data.TrainingEntity
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/** Export a portable archive using Android's sharesheet; WhatsApp transport never needs our server. */
object TrainingShare {
    suspend fun prepare(context: Context, t: TrainingEntity): Intent = withContext(Dispatchers.IO) {
        val directory = t.localDir?.let(::File) ?: error("Entrenamiento no descargado")
        val files = directory.listFiles()?.filter { it.isFile }?.sortedBy { it.name } ?: emptyList()
        require(files.isNotEmpty()) { "No hay segmentos locales" }
        require(t.localSha256 != null && t.watchSha256 != null && t.localSha256.equals(t.watchSha256, true)) {
            "Es necesario verificar la descarga con el reloj antes de compartir"
        }
        val share = File(context.cacheDir, "share").also { it.mkdirs() }
        val target = File(share, "AVO_${t.sessionId.replace(Regex("[^A-Za-z0-9_-]"), "_")}.avo")
        ZipOutputStream(target.outputStream().buffered()).use { zip ->
            val manifest = org.json.JSONObject().put("format", "AVO-TRAINING-1")
                .put("sessionId", t.sessionId).put("sha256", t.localSha256)
                .put("segments", files.size).toString()
            zip.putNextEntry(ZipEntry("manifest.json")); zip.write(manifest.toByteArray()); zip.closeEntry()
            files.forEach { file ->
                zip.putNextEntry(ZipEntry("segments/${file.name}"))
                file.inputStream().use { it.copyTo(zip) }
                zip.closeEntry()
            }
        }
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.files", target)
        Intent(Intent.ACTION_SEND).apply {
            type = "application/octet-stream"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
    }
}
